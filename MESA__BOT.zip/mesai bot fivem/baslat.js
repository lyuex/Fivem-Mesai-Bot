const bot = require('./Lyuex');
const web = require('./lyuex-web');

console.log(bot, web);