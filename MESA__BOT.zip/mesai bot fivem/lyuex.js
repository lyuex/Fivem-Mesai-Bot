﻿require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');
const Discord = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const Lyuex = require('./lyuex.json');
const eventHandlers = require('./src/handlers/eventHandlers');
const { commandMap } = require('./src/handlers/commandHandler');
const { startAutoBackup } = require('./src/utils/backup');

process.on('unhandledRejection', (error) => {
    console.error('[Lyuex API] Yakalanmamis hata:', error);
});

process.on('uncaughtException', (error) => {
    console.error('[Lyuex API] Kritik hata:', error);
});

const BOT_TOKEN = process.env.BOT_TOKEN || Lyuex.botSettings.token;

const client = new Client({
    intents: Object.keys(GatewayIntentBits).map((key) => GatewayIntentBits[key])
});

client.commands = commandMap;
client.buttons = new Discord.Collection();
client.selectMenus = new Discord.Collection();
client.modals = new Discord.Collection();

eventHandlers(client);

const rest = new REST({ version: '10' }).setToken(BOT_TOKEN);

(async () => {
    try {
        console.log('(/) komutlari baslatildi ve yenilendi!');

        await rest.put(
            Routes.applicationGuildCommands(Lyuex.botSettings.clientID, Lyuex.botSettings.ServerID),
            { body: commandMap.map(cmd => cmd.data.toJSON()) },
        );

        console.log('(/) komutlari basariyla yuklendi!');
    } catch (error) {
        console.error(error);
    }
})();

client
    .login(BOT_TOKEN).then(() => {
    console.clear();
    console.log('[Lyuex API] ' + client.user.username + ' Giris Yaptim.');
    startAutoBackup();
    }).catch((err) => console.log(err)
    );