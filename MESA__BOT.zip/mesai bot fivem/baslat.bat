@echo off
title Mesai Bot FiveM
node baslat.js
pause