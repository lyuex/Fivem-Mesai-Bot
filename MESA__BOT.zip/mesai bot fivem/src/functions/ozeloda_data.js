const { JsonDatabase } = require('for.db');
const db = new JsonDatabase({ databasePath: "./src/database/Lyuex_database.json" });

module.exports.checkDB = async (id, guild) => {
    const key = `ozeloda_${id}_${guild}`;
    if (!db.has(key)) {
        db.set(key, { userId: id, guildId: guild });
    }
    return db.get(key);
}