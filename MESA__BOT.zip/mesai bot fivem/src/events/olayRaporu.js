const { Events, EmbedBuilder } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const { THEME, ansiHeader, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isModalSubmit() || interaction.customId !== 'olay-raporu-modal') return;

        await interaction.deferReply();

        const baslik = interaction.fields.getTextInputValue('olay-baslik');
        const bolge = interaction.fields.getTextInputValue('olay-bolge');
        const ilgililer = interaction.fields.getTextInputValue('olay-ilgililer');
        const detay = interaction.fields.getTextInputValue('olay-detay');
        const sonuc = interaction.fields.getTextInputValue('olay-sonuc');

        const raporlar = policeDb.get('olayRaporlari') || [];
        const kayitNo = raporlar.length + 1;

        const yeniRapor = {
            no: kayitNo,
            memurId: interaction.user.id,
            baslik,
            bolge,
            ilgililer,
            detay,
            sonuc,
            tarih: moment().format('YYYY-MM-DD HH:mm:ss'),
            timestamp: Date.now()
        };

        raporlar.push(yeniRapor);
        policeDb.set('olayRaporlari', raporlar);

        const embed = new EmbedBuilder()
            .setColor(THEME.blue)
            .setAuthor({ name: `${interaction.guild.name} — Olay Raporu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`📄 Olay Raporu #${kayitNo} — ${baslik}`)
            .setDescription([
                ansiHeader('📄  OLAY RAPORU', '34'),
                '',
                `👮 **Raporu Yazan:** <@${interaction.user.id}>`,
                `📅 **Tarih:** \`${moment().format('DD.MM.YYYY HH:mm')}\``,
            ].join('\n'))
            .addFields(
                { name: '📍 Olay Yeri', value: bolge, inline: true },
                { name: '👥 İlgili Kişiler', value: ilgililer, inline: true },
                { name: '📋 Olay Detayı', value: detay.length > 1024 ? detay.slice(0, 1021) + '...' : detay, inline: false },
                { name: '✅ Sonuç / Aksiyonlar', value: sonuc.length > 1024 ? sonuc.slice(0, 1021) + '...' : sonuc, inline: false }
            )
            .setFooter({ text: `Rapor No: #${kayitNo} • Lyuex Olay Raporu Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        // Log kanalına gönder
        const logChannel = findLogChannel(interaction.guild, 'rapor_log', 'polis_log', 'lyuex_log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor(THEME.blue)
                .setTitle(`📄 Olay Raporu #${kayitNo}`)
                .setDescription(ansiHeader('📄  YENİ OLAY RAPORU', '34'))
                .addFields(
                    { name: '📌 Başlık', value: baslik, inline: true },
                    { name: '👮 Memur', value: `<@${interaction.user.id}>`, inline: true },
                    { name: '📍 Bölge', value: bolge, inline: true },
                    { name: '👥 İlgililer', value: ilgililer, inline: false },
                    { name: '📋 Detay', value: detay.length > 1024 ? detay.slice(0, 1021) + '...' : detay, inline: false },
                    { name: '✅ Sonuç', value: sonuc.length > 1024 ? sonuc.slice(0, 1021) + '...' : sonuc, inline: false }
                )
                .setFooter({ text: `#${kayitNo}` })
                .setTimestamp();
            await logChannel.send({ embeds: [logEmbed] });
        }
    }
};
