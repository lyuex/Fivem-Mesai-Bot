﻿const { EmbedBuilder, Events } = require('discord.js');
const Lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajı');

module.exports = {
    name: Events.GuildRoleDelete,
    async execute(role, client) {
        try {
            if (Lyuex.log.rolsilme) {
                const Lyuexinrolsilmelogodasi = client.channels.cache.find(channel => channel.name === 'role_log');
                role.guild.fetchAuditLogs({ type: 32 }).then(audit => {
                    const Lyuexkkk = audit.entries.first();
                    const minis = Lyuexkkk.executor;
                    const Lyuexinrolsilmeembedi = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('Rol Silindi')
                    .setDescription(`Rol: \n >**${role.name}** - ${role.id} \n\n Kişi: \n >${minis.tag} - ${minis.id} - <@${minis.id}>`)
                    .setThumbnail(role.guild.iconURL({ dynamic: true}))
                    .setFooter({ text: Lyuex.reklam.Lyuexisim, iconURL: Lyuex.reklam.Lyuexprofile })
                    .setTimestamp();
                    if (Lyuexinrolsilmelogodasi) {
                    Lyuexinrolsilmelogodasi.send({ embeds: [Lyuexinrolsilmeembedi] })
                }
                })
            }
        }
        catch (error) {
            catchError(client, 'roleDelete.js', error.message)
        }
    }
}