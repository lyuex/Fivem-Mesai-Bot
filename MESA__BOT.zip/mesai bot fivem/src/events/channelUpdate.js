﻿const { EmbedBuilder, Events, AuditLogEvent} = require('discord.js');
const Lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajı');

module.exports = {
    name: Events.ChannelUpdate,
    async execute(oldChannel, newChannel, client) {
    try {
        const Lyuexinupdatelogu = client.channels.cache.find(channel => channel.name === 'channel_log');
    newChannel.guild.fetchAuditLogs( { type: AuditLogEvent.ChannelUpdate }).then(audit => {
    const Lyuexoc = audit.entries.first();
    const Lyuexinupdateembedi = new EmbedBuilder()
    .setColor('#000000')
    .setTitle('Kanal Güncellendi!')
    .setDescription(`kişi: \n <@${Lyuexoc.executor.id}> - (${Lyuexoc.executor.id})\n Eski Kanal: \n > <#${oldChannel.id}> - ${oldChannel.name} \n Yeni Kanal: \n > <#${newChannel.id}> - ${newChannel.name} `)
    .setThumbnail(newChannel.guild.iconURL({ dynamic: true }))
    .setFooter({ text: Lyuex.reklam.Lyuexisim, iconURL: Lyuex.reklam.Lyuexprofile })
    .setTimestamp();
    if (Lyuexinupdatelogu) {
        Lyuexinupdatelogu.send({ embeds: [Lyuexinupdateembedi] });
    }
    });
    }catch (error) {
        catchError(client, 'channelUpdate.js', error.message)
    }
    }
}