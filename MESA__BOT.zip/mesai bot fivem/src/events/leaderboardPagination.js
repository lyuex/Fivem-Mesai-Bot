// ═══════════════════════════════════════════════
//  Liderlik Tablosu Sayfalama Buton Handler
// ═══════════════════════════════════════════════

const { Events, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getMesaiData, buildMesaiEmbeds } = require('./leaderboard');
const { getFarmData, buildFarmEmbeds } = require('./farmLeaderboard');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isButton()) return;
        const id = interaction.customId;

        try {
            // ── Mesai Liderlik Tablosu ──
            if (id.startsWith('mesai_lb_prev_') || id.startsWith('mesai_lb_next_')) {
                const currentPage = parseInt(id.split('_').pop()) || 0;
                const newPage = id.includes('_prev_') ? currentPage - 1 : currentPage + 1;

                const { sortedByEntries, sortedByDuration } = getMesaiData();
                const { mostEntriesEmbed, longestDurationEmbed, totalPages } = buildMesaiEmbeds(sortedByEntries, sortedByDuration, newPage);

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`mesai_lb_prev_${newPage}`).setLabel('◀ Önceki').setStyle(ButtonStyle.Secondary).setDisabled(newPage <= 0),
                    new ButtonBuilder().setCustomId(`mesai_lb_next_${newPage}`).setLabel('Sonraki ▶').setStyle(ButtonStyle.Secondary).setDisabled(newPage >= totalPages - 1),
                );

                await interaction.update({ embeds: [mostEntriesEmbed, longestDurationEmbed], components: [row] });
            }

            // ── Farm Liderlik Tablosu ──
            if (id.startsWith('farm_lb_prev_') || id.startsWith('farm_lb_next_')) {
                const currentPage = parseInt(id.split('_').pop()) || 0;
                const newPage = id.includes('_prev_') ? currentPage - 1 : currentPage + 1;

                const farmData = getFarmData();
                const { topFarmersEmbed, totalPages } = buildFarmEmbeds(farmData, newPage);

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`farm_lb_prev_${newPage}`).setLabel('◀ Önceki').setStyle(ButtonStyle.Secondary).setDisabled(newPage <= 0),
                    new ButtonBuilder().setCustomId(`farm_lb_next_${newPage}`).setLabel('Sonraki ▶').setStyle(ButtonStyle.Secondary).setDisabled(newPage >= totalPages - 1),
                );

                await interaction.update({ embeds: [topFarmersEmbed], components: [row] });
            }
        } catch (error) {
            console.error('[LBPagination] Hata:', error);
            if (!interaction.replied && !interaction.deferred) {
                interaction.reply({ content: '❌ Sayfa değiştirirken bir hata oluştu.', ephemeral: true }).catch(() => {});
            }
        }
    },
};
