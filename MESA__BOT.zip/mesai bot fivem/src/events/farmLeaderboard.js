﻿const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { JsonDatabase } = require('for.db');
const Lyuex = require('../../lyuex.json');
const { LEADERBOARD_PAGE_SIZE } = require('../utils/constants');
const db = new JsonDatabase({
    databasePath: "./src/database/farmdb.json"
});

function getFarmData() {
    const allData = db.get('farm') || {};
    let totalOt = 0, totalKokain = 0, totalMeth = 0, totalKarapara = 0;
    const userTotals = [];

    for (const [userId, userData] of Object.entries(allData)) {
        totalOt += userData.ot || 0;
        totalKokain += userData.kokain || 0;
        totalMeth += userData.meth || 0;
        totalKarapara += userData.karapara || 0;
        userTotals.push({ userId, ot: userData.ot || 0, kokain: userData.kokain || 0, meth: userData.meth || 0, karapara: userData.karapara || 0, eklemeTarihi: userData.eklemeTarihi });
    }

    const sorted = [...userTotals].sort((a, b) => (b.ot + b.kokain + b.meth + b.karapara) - (a.ot + a.kokain + a.meth + a.karapara));
    const recent = [...userTotals].sort((a, b) => new Date(b.eklemeTarihi) - new Date(a.eklemeTarihi));
    return { sorted, recent, totalOt, totalKokain, totalMeth, totalKarapara };
}

function buildFarmEmbeds(farmData, page = 0) {
    const { sorted, recent, totalOt, totalKokain, totalMeth, totalKarapara } = farmData;
    const start = page * LEADERBOARD_PAGE_SIZE;
    const end = start + LEADERBOARD_PAGE_SIZE;
    const totalPages = Math.max(1, Math.ceil(sorted.length / LEADERBOARD_PAGE_SIZE));

    const totalEmbed = new EmbedBuilder()
        .setTitle('Toplam Farm Miktarları')
        .setColor(0x00AE86)
        .setDescription(`**Toplam** \n OT: ${totalOt} \n Kokain: ${totalKokain} \n Meth: ${totalMeth} \n Karapara: ${totalKarapara}`);

    const topSlice = sorted.slice(start, end);
    const topFarmersEmbed = new EmbedBuilder()
        .setTitle('En Çok Farm Yapan Kullanıcılar')
        .setColor(0xFFD700)
        .setDescription(topSlice.map((user, index) => 
            `**${start + index + 1}.** <@${user.userId}>\nOT: ${user.ot} | Kokain: ${user.kokain} | Meth: ${user.meth} | Karapara: ${user.karapara}`
        ).join('\n\n') || 'Veri yok')
        .setFooter({ text: `Sayfa ${page + 1}/${totalPages}` });

    const recentSlice = recent.slice(0, 5);
    const recentDesc = recentSlice.map((user, index) => 
        `${index + 1}. <@${user.userId}>\nOT: ${user.ot} | Kokain: ${user.kokain} | Meth: ${user.meth} | Karapara: ${user.karapara}\nTarih: ${user.eklemeTarihi ? new Date(user.eklemeTarihi).toLocaleString('tr-TR') : '-'}`
    ).join('\n\n') || 'Veri yok';

    const recentEntriesEmbed = new EmbedBuilder()
        .setTitle('En Son Eklenen 5 Kayıt')
        .setColor(0x00FF00)
        .setDescription(recentDesc);

    return { totalEmbed, topFarmersEmbed, recentEntriesEmbed, totalPages };
}

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log('Bot is online!');

        const channelId = Lyuex.leaderboard.farm;

        async function updateEmbeds() {
            const farmData = getFarmData();
            const { totalEmbed, topFarmersEmbed, recentEntriesEmbed, totalPages } = buildFarmEmbeds(farmData, 0);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('farm_lb_prev_0').setLabel('◀ Önceki').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('farm_lb_next_0').setLabel('Sonraki ▶').setStyle(ButtonStyle.Secondary).setDisabled(totalPages <= 1),
            );

            try {
                const channel = await client.channels.fetch(channelId);
                const messages = await channel.messages.fetch({ limit: 10 });
                const botMessages = messages.filter(m => m.author.id === client.user.id);
                const messageArray = Array.from(botMessages.values()).reverse();

                if (messageArray.length >= 3) {
                    await messageArray[0].edit({ embeds: [totalEmbed] });
                    await messageArray[1].edit({ embeds: [topFarmersEmbed], components: [row] });
                    await messageArray[2].edit({ embeds: [recentEntriesEmbed] });
                } else {
                    for (const msg of messageArray) await msg.delete();
                    await channel.send({ embeds: [totalEmbed] });
                    await channel.send({ embeds: [topFarmersEmbed], components: [row] });
                    await channel.send({ embeds: [recentEntriesEmbed] });
                }
            } catch (error) {
                console.error(error);
            }
        }

        updateEmbeds();
        setInterval(updateEmbeds, 900000);
    },
    getFarmData,
    buildFarmEmbeds,
};
