// ═══════════════════════════════════════════════
//  Sesli Kanal Süre Takibi
// ═══════════════════════════════════════════════

const { Events } = require('discord.js');
const { JsonDatabase } = require('for.db');

const db = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const voiceSessions = new Map();

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        try {
            const userId = newState.id;
            const oldChannel = oldState.channel;
            const newChannel = newState.channel;

            // Kanala giriş
            if (!oldChannel && newChannel) {
                voiceSessions.set(userId, { channelId: newChannel.id, joinedAt: Date.now() });
            }

            // Kanaldan çıkış
            if (oldChannel && !newChannel) {
                const session = voiceSessions.get(userId);
                if (session) {
                    const duration = Date.now() - session.joinedAt;
                    if (duration > 10000) { // 10 saniyeden kısa oturumları sayma
                        const current = db.get(`sesli.${userId}`) || { toplamSure: 0, oturumSayisi: 0 };
                        current.toplamSure += duration;
                        current.oturumSayisi += 1;
                        db.set(`sesli.${userId}`, current);
                    }
                    voiceSessions.delete(userId);
                }
            }

            // Kanal değiştirme
            if (oldChannel && newChannel && oldChannel.id !== newChannel.id) {
                const session = voiceSessions.get(userId);
                if (session) {
                    const duration = Date.now() - session.joinedAt;
                    if (duration > 10000) {
                        const current = db.get(`sesli.${userId}`) || { toplamSure: 0, oturumSayisi: 0 };
                        current.toplamSure += duration;
                        current.oturumSayisi += 1;
                        db.set(`sesli.${userId}`, current);
                    }
                }
                voiceSessions.set(userId, { channelId: newChannel.id, joinedAt: Date.now() });
            }
        } catch (error) {
            console.error('[SesliTakip] Hata:', error);
        }
    },
    voiceSessions,
};
