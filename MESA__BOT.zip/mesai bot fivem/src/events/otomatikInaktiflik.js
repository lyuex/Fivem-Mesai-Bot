// ═══════════════════════════════════════════════
//  Otomatik İnaktiflik Tespiti
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const Lyuex = require('../../lyuex.json');
const { THEME } = require('../utils/theme');
const { INACTIVITY_DAYS } = require('../utils/constants');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const izinDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        // Her gün saat 10:00'da kontrol
        scheduleDaily(client, 10);
        console.log(`[İnaktiflik] Otomatik kontrol aktif (${INACTIVITY_DAYS} gün eşiği).`);
    },
};

function scheduleDaily(client, hour) {
    const now = new Date();
    const next = new Date();
    next.setHours(hour, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);

    setTimeout(() => {
        checkInactivity(client);
        setInterval(() => checkInactivity(client), 24 * 60 * 60 * 1000);
    }, next - now);
}

async function checkInactivity(client) {
    try {
        const guild = client.guilds.cache.get(Lyuex.botSettings.ServerID);
        if (!guild) return;

        const inaktifRol = guild.roles.cache.find(r => r.id === Lyuex.rol.inaktif || r.name === Lyuex.rol.inaktif);
        if (!inaktifRol) return;

        const kayitliRol = guild.roles.cache.find(r => r.id === Lyuex.rol.kayıtlı || r.name === Lyuex.rol.kayıtlı);
        if (!kayitliRol) return;

        const allMesai = mesaiDb.toJSON() || {};
        const sinir = moment().subtract(INACTIVITY_DAYS, 'days');
        let inaktifListesi = [];

        // Kayıtlı rolü olan tüm üyeleri kontrol et
        await guild.members.fetch();
        const kayitliUyeler = guild.members.cache.filter(m => m.roles.cache.has(kayitliRol.id) && !m.user.bot);

        for (const [memberId, member] of kayitliUyeler) {
            // İzinli kullanıcıları atla
            const izin = izinDb.get(`izin.${memberId}`);
            if (izin && moment(izin.bitis).isAfter(moment())) continue;

            // Zaten inaktif rolü varsa atla
            if (member.roles.cache.has(inaktifRol.id)) continue;

            const userData = allMesai[memberId];
            if (!userData || !userData.mesailer) {
                inaktifListesi.push(memberId);
                continue;
            }

            // Son mesai tarihini bul
            const mesaiKeys = Object.keys(userData.mesailer);
            if (mesaiKeys.length === 0) {
                inaktifListesi.push(memberId);
                continue;
            }

            const sonMesai = userData.mesailer[mesaiKeys[mesaiKeys.length - 1]];
            const sonTarih = moment(sonMesai['giriş']);
            if (sonTarih.isBefore(sinir)) {
                inaktifListesi.push(memberId);
            }
        }

        // İnaktif rol ata
        for (const id of inaktifListesi) {
            const member = guild.members.cache.get(id);
            if (member) {
                await member.roles.add(inaktifRol).catch(() => {});
            }
        }

        // Log gönder
        if (inaktifListesi.length > 0) {
            const logChannel = guild.channels.cache.find(ch => ch.name === 'lyuex_log');
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setColor(THEME.warning)
                    .setTitle('⚠️ Otomatik İnaktiflik Tespiti')
                    .setDescription(`**${inaktifListesi.length}** kişi ${INACTIVITY_DAYS} gündür mesaiye girmediği için inaktif olarak işaretlendi.\n\n${inaktifListesi.slice(0, 15).map(id => `<@${id}>`).join(', ')}${inaktifListesi.length > 15 ? `\n...ve ${inaktifListesi.length - 15} kişi daha` : ''}`)
                    .setTimestamp();
                logChannel.send({ embeds: [embed] }).catch(() => {});
            }
        }

        console.log(`[İnaktiflik] Kontrol tamamlandı: ${inaktifListesi.length} inaktif tespit edildi.`);
    } catch (error) {
        console.error('[İnaktiflik] Hata:', error);
    }
}
