// ═══════════════════════════════════════════════
//  Haftalık Mesai Raporu
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const Lyuex = require('../../lyuex.json');
const { THEME } = require('../utils/theme');
const { WEEKLY_REPORT_DAY, WEEKLY_REPORT_HOUR } = require('../utils/constants');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const farmDb = new JsonDatabase({ databasePath: "./src/database/farmdb.json" });

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        scheduleWeeklyReport(client);
        console.log('[HaftalıkRapor] Zamanlayıcı aktif.');
    },
};

function scheduleWeeklyReport(client) {
    const now = new Date();
    const next = new Date();
    next.setDate(now.getDate() + ((WEEKLY_REPORT_DAY + 7 - now.getDay()) % 7 || 7));
    next.setHours(WEEKLY_REPORT_HOUR, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 7);

    const delay = next - now;
    setTimeout(() => {
        sendWeeklyReport(client);
        setInterval(() => sendWeeklyReport(client), 7 * 24 * 60 * 60 * 1000);
    }, delay);
}

async function sendWeeklyReport(client) {
    try {
        const channel = await client.channels.fetch(Lyuex.leaderboard.mesai).catch(() => null);
        if (!channel) return;

        const birHaftaOnce = moment().subtract(7, 'days');
        const allMesai = mesaiDb.toJSON() || {};
        const allFarm = farmDb.get('farm') || {};

        // Haftalık mesai verileri
        let haftalikSayi = 0, haftalikSure = 0;
        const userStats = [];

        for (const [userId, data] of Object.entries(allMesai)) {
            let userSure = 0, userSayi = 0;
            if (data.mesailer) {
                for (const m of Object.values(data.mesailer)) {
                    if (!m['giriş']) continue;
                    const giris = moment(m['giriş']);
                    if (giris.isBefore(birHaftaOnce)) continue;
                    userSayi++;
                    haftalikSayi++;
                    if (m['çıkış']) {
                        const sure = moment(m['çıkış']).diff(giris, 'minutes');
                        if (sure > 0) { userSure += sure; haftalikSure += sure; }
                    }
                }
            }
            if (userSayi > 0) userStats.push({ userId, sayi: userSayi, sure: userSure });
        }

        userStats.sort((a, b) => b.sure - a.sure);
        const top5 = userStats.slice(0, 5).map((u, i) => {
            const saat = Math.floor(u.sure / 60);
            const dk = u.sure % 60;
            return `**${i + 1}.** <@${u.userId}> — ${saat}s ${dk}dk (${u.sayi} giriş)`;
        }).join('\n') || 'Veri yok';

        // Haftalık farm toplamı
        let hOt = 0, hKokain = 0, hMeth = 0, hKarapara = 0;
        for (const data of Object.values(allFarm)) {
            hOt += data.ot || 0;
            hKokain += data.kokain || 0;
            hMeth += data.meth || 0;
            hKarapara += data.karapara || 0;
        }

        const toplamSaat = Math.floor(haftalikSure / 60);
        const toplamDk = haftalikSure % 60;

        const embed = new EmbedBuilder()
            .setColor(THEME.gold)
            .setTitle('📊 Haftalık Rapor')
            .setDescription(`**${moment().subtract(7, 'days').format('DD.MM')} — ${moment().format('DD.MM.YYYY')}** dönemi`)
            .addFields(
                { name: '🕐 Mesai Özeti', value: `Toplam: **${haftalikSayi}** giriş — **${toplamSaat}s ${toplamDk}dk**\nAktif personel: **${userStats.length}** kişi`, inline: false },
                { name: '🏆 En Çok Mesai Yapanlar', value: top5, inline: false },
                { name: '🌿 Farm Toplamı', value: `OT: **${hOt}** | Kokain: **${hKokain}** | Meth: **${hMeth}** | Karapara: **${hKarapara}**`, inline: false }
            )
            .setFooter({ text: 'Lyuex Haftalık Rapor Sistemi' })
            .setTimestamp();

        await channel.send({ embeds: [embed] });
        console.log('[HaftalıkRapor] Haftalık rapor gönderildi.');
    } catch (error) {
        console.error('[HaftalıkRapor] Hata:', error);
    }
}
