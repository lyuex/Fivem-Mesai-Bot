// ═══════════════════════════════════════════════
//  Günlük Polis Raporu — Her gece 00:00'da otomatik
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, progressBar, findLogChannel } = require('../utils/theme');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        scheduleDaily(client, 0); // gece 00:00
        console.log('[GünlükRapor] Zamanlayıcı aktif.');
    },
};

function scheduleDaily(client, hour) {
    const now = new Date();
    const next = new Date();
    next.setHours(hour, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);

    const delay = next - now;
    setTimeout(() => {
        sendDailyReport(client);
        setInterval(() => sendDailyReport(client), 24 * 60 * 60 * 1000);
    }, delay);
}

async function sendDailyReport(client) {
    try {
        const logKanalId = config.polis?.raporKanali || config.polis?.logKanali;
        let channel = null;

        if (logKanalId) {
            channel = await client.channels.fetch(logKanalId).catch(() => null);
        }
        if (!channel) {
            const guild = await client.guilds.fetch(config.botSettings.ServerID).catch(() => null);
            if (guild) channel = findLogChannel(guild, 'gunluk_rapor', 'polis_log', 'lyuex_log');
        }
        if (!channel) return;

        const bugun = moment().subtract(1, 'day'); // dünkü gün
        const gunBaslangic = bugun.clone().startOf('day');
        const gunBitis = bugun.clone().endOf('day');
        const tarihStr = bugun.format('DD.MM.YYYY');

        // Mesai istatistikleri
        const allMesai = mesaiDb.toJSON() || {};
        let mesaiSayisi = 0;
        let toplamDk = 0;
        let mesaideKisi = 0;
        const kisiSet = new Set();

        for (const [userId, data] of Object.entries(allMesai)) {
            if (!data?.mesailer) continue;
            for (const m of Object.values(data.mesailer)) {
                if (!m['giriş']) continue;
                const giris = moment(m['giriş']);
                if (giris.isBefore(gunBaslangic) || giris.isAfter(gunBitis)) continue;
                mesaiSayisi++;
                kisiSet.add(userId);
                if (m['çıkış']) {
                    const sure = moment(m['çıkış']).diff(giris, 'minutes');
                    if (sure > 0) toplamDk += sure;
                }
            }
        }
        mesaideKisi = kisiSet.size;

        const ortSure = mesaideKisi > 0 ? Math.round(toplamDk / mesaideKisi) : 0;
        const toplamSaat = Math.floor(toplamDk / 60);
        const kalanDk = toplamDk % 60;

        // Tutuklama istatistikleri
        const tutuklamalar = (policeDb.get('tutuklamalar') || []).filter(t => {
            const tarih = moment(t.tarih);
            return tarih.isBetween(gunBaslangic, gunBitis, null, '[]');
        });

        // Ceza istatistikleri
        const cezalar = (policeDb.get('cezalar') || []).filter(c => {
            const tarih = moment(c.tarih);
            return tarih.isBetween(gunBaslangic, gunBitis, null, '[]');
        });
        const toplamCezaMiktar = cezalar.reduce((t, c) => t + (c.miktar || 0), 0);

        // Devriye istatistikleri
        const devriyeler = (policeDb.get('devriyeler') || []).filter(d => {
            const tarih = moment(d.tarih);
            return tarih.isBetween(gunBaslangic, gunBitis, null, '[]');
        });

        const olayMudahale = devriyeler.filter(d => d.durum === 'Olay Müdahalesi').length;
        const sorunsuz = devriyeler.filter(d => d.durum === 'Sorunsuz').length;

        // Eğitim istatistikleri
        const egitimler = (policeDb.get('egitimler') || []).filter(e => {
            const tarih = moment(e.baslangic);
            return tarih.isBetween(gunBaslangic, gunBitis, null, '[]');
        });

        // Olay raporları
        const raporlar = (policeDb.get('olayRaporlari') || []).filter(r => {
            const tarih = moment(r.tarih);
            return tarih.isBetween(gunBaslangic, gunBitis, null, '[]');
        });

        // Performans skoru (0-100)
        const maxAktivite = 40; // idealde 40 aktivite
        const gunlukAktivite = tutuklamalar.length + cezalar.length + devriyeler.length + raporlar.length;
        const performans = Math.min(100, Math.round((gunlukAktivite / maxAktivite) * 100));

        const embed = new EmbedBuilder()
            .setColor(THEME.primary)
            .setTitle(`📊 Günlük Polis Raporu — ${tarihStr}`)
            .setDescription([
                ansiHeader('📊  GÜNLÜK POLİS RAPORU', '35'),
                '',
                `📅 **Tarih:** \`${tarihStr}\``,
                `📈 **Günlük Performans:** \`${performans}%\``,
                `\`${progressBar(performans, 100, 25)}\``,
            ].join('\n'))
            .addFields(
                { name: '⏱️ Mesai', value: [
                    `👥 Görev Yapan: \`${mesaideKisi}\``,
                    `📊 Mesai Sayısı: \`${mesaiSayisi}\``,
                    `⏰ Toplam: \`${toplamSaat}s ${kalanDk}dk\``,
                    `📏 Ort. Süre: \`${ortSure}dk/kişi\``,
                ].join('\n'), inline: true },
                { name: '🔒 Tutuklamalar', value: [
                    `📊 Adet: \`${tutuklamalar.length}\``,
                    tutuklamalar.length > 0 ? `👮 Son: <@${tutuklamalar[tutuklamalar.length - 1]?.memurId}>` : '`—`',
                ].join('\n'), inline: true },
                { name: '📝 Cezalar', value: [
                    `📊 Adet: \`${cezalar.length}\``,
                    `💰 Toplam: \`${toplamCezaMiktar.toLocaleString('tr-TR')}${config.polis?.maas?.paraBirimi || '₺'}\``,
                ].join('\n'), inline: true },
                { name: '🚓 Devriyeler', value: [
                    `📊 Toplam: \`${devriyeler.length}\``,
                    `✅ Sorunsuz: \`${sorunsuz}\``,
                    `🚨 Müdahale: \`${olayMudahale}\``,
                ].join('\n'), inline: true },
                { name: '📚 Eğitimler', value: [
                    `📊 Adet: \`${egitimler.length}\``,
                    `👥 Katılımcı: \`${egitimler.reduce((t, e) => t + (e.katilimcilar?.length || 0), 0)}\``,
                ].join('\n'), inline: true },
                { name: '📄 Olay Raporları', value: [
                    `📊 Adet: \`${raporlar.length}\``,
                ].join('\n'), inline: true }
            )
            .setFooter({ text: 'Otomatik Günlük Rapor • Lyuex Polis Sistemi' })
            .setTimestamp();

        await channel.send({ embeds: [embed] });
    } catch (err) {
        console.error('[GünlükRapor] Hata:', err.message);
    }
}
