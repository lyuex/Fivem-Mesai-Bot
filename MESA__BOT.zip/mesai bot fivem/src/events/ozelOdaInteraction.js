// ═══════════════════════════════════════════════
//  Özel Oda Sistemi — Interaction Handler
// ═══════════════════════════════════════════════

const { Events, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const Lyuex = require('../../lyuex.json');

const db = new JsonDatabase({ databasePath: "./src/database/Lyuex_database.json" });

const ODA_BUTTON_IDS = ['user-ekle', 'user-cıkar', 'oda-isim', 'oda-sil', 'sesten-at', 'oda-kilit', 'oda-herkes', 'oda-limit', 'oda-bilgi', 'oda-oluştur'];
const ODA_MODAL_IDS = ['oda-create', 'user-add', 'user-substr', 'oda-name', 'user-dis', 'oda-sayı', 'bit-hız'];

function getOdaButtons() {
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('user-ekle').setLabel('User Ekle').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('user-cıkar').setLabel('User Çıkar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-isim').setLabel('Oda Adı Değiştir').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-sil').setLabel('Özel Odanı Sil').setStyle(ButtonStyle.Secondary)
    );
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('oda-kilit').setLabel('Odayı Kilitle').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-limit').setLabel('Oda Limiti Değiştir').setEmoji('👥').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('sesten-at').setLabel('Sesten At').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-herkes').setLabel('Odayı Herkese Aç').setStyle(ButtonStyle.Secondary)
    );
    const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('oda-bilgi').setLabel('Oda Üyeleri').setEmoji('❓').setStyle(ButtonStyle.Primary)
    );
    return [row1, row2, row3];
}

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        try {
            const value = interaction.customId;

            // ── Button Handler ──
            if (interaction.isButton()) {
                if (!ODA_BUTTON_IDS.includes(value)) return;

                if (value === 'oda-oluştur') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    if (data) return interaction.reply({ content: 'Zaten Odanız Bulunmakta!', ephemeral: true });

                    const modal = new ModalBuilder().setCustomId('oda-create').setTitle('Özel Oda Oluştur');
                    modal.addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder().setCustomId('oda-adı').setPlaceholder('Lyuex Secret Room').setLabel('Odanızın Adı Ne Olsun?').setStyle(TextInputStyle.Short).setMinLength(2).setMaxLength(10).setRequired(true)
                        ),
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder().setCustomId('oda-limit').setPlaceholder('(1 - 99)').setLabel('Odanız Kaç Kişilik Olsun?').setStyle(TextInputStyle.Short).setMinLength(1).setMaxLength(2).setRequired(true)
                        )
                    );
                    return interaction.showModal(modal);
                }

                if (value === 'oda-bilgi') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    if (!data) return interaction.reply({ content: 'Odanız Bulunmamakta!', ephemeral: true });
                    const users = db.get(`members_${data}`);
                    const list = users
                        ? users.map((id, n) => {
                            const m = interaction.guild.members.cache.get(id);
                            return `${n + 1}) ${m ? m.user.tag : id}`;
                        }).join(', ')
                        : 'Bulunamadı';
                    return interaction.reply({ content: `\`\`\`fix\n${list}\n\`\`\``, ephemeral: true });
                }

                if (value === 'oda-sil') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    if (!data) return interaction.reply({ content: 'Bir Özel Odan Bulunmamakta!', ephemeral: true });
                    const channel = interaction.guild.channels.cache.get(data);
                    if (channel) channel.delete({ reason: 'Oda Sahibi Tarafından Silindi' });
                    db.delete(`members_${data}`);
                    db.delete(`${data}`);
                    db.delete(`özeloda_${interaction.member.id}`);
                    return interaction.reply({ content: 'Özel Odanız Siliniyor.', ephemeral: true });
                }

                if (value === 'oda-kilit') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    if (!data) return interaction.reply({ content: 'Odanız Bulunmamakta!', ephemeral: true });
                    const channel = interaction.guild.channels.cache.get(data);
                    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { Connect: false, SendMessages: false, ViewChannel: false, Stream: false, Speak: false });
                    return interaction.reply({ content: 'Odanız Başarıyla Herkese Kapatıldı!', ephemeral: true });
                }

                if (value === 'oda-herkes') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    if (!data) return interaction.reply({ content: 'Odanız Bulunmamakta!', ephemeral: true });
                    const channel = interaction.guild.channels.cache.get(data);
                    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { Connect: true, SendMessages: false, ViewChannel: true, Stream: true, Speak: true });
                    return interaction.reply({ content: 'Odanız Başarıyla Herkese Açıldı!', ephemeral: true });
                }

                // Modal gerektiren butonlar
                const modalMap = {
                    'user-ekle': { id: 'user-add', title: 'Özel Oda Sistemi', field: { id: 'kisi', label: "Bir Kullanıcı ID'si Belirtin", placeholder: '1143638421257072661' } },
                    'user-cıkar': { id: 'user-substr', title: 'Özel Oda Sistemi', field: { id: 'kisi', label: "Kullanıcı ID'si Belirtin", placeholder: '1143638421257072661' } },
                    'oda-isim': { id: 'oda-name', title: 'Özel Oda Sistemi', field: { id: 'oda-adı', label: 'Oda Adı Belirtin', placeholder: 'Lyuex Secret Room', min: 2, max: 10 } },
                    'sesten-at': { id: 'user-dis', title: 'Özel Oda Sistemi', field: { id: 'kisi', label: "Kullanıcı ID'si Belirtin", placeholder: '1143638421257072661' } },
                    'oda-limit': { id: 'oda-sayı', title: 'Özel Oda Sistemi', field: { id: 'limit', label: 'Bir Oda Limiti Belirtin', placeholder: 'Limiti Giriniz (1-99)', min: 1, max: 2 } },
                };

                const cfg = modalMap[value];
                if (cfg) {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    if (!data) return interaction.reply({ content: 'Odanız Bulunmamakta!', ephemeral: true });

                    const modal = new ModalBuilder().setCustomId(cfg.id).setTitle(cfg.title);
                    const input = new TextInputBuilder()
                        .setCustomId(cfg.field.id)
                        .setPlaceholder(cfg.field.placeholder)
                        .setLabel(cfg.field.label)
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(cfg.field.min || 5)
                        .setMaxLength(cfg.field.max || 25)
                        .setRequired(true);
                    modal.addComponents(new ActionRowBuilder().addComponents(input));
                    return interaction.showModal(modal);
                }
            }

            // ── Modal Submit Handler ──
            if (interaction.isModalSubmit()) {
                if (!ODA_MODAL_IDS.includes(value)) return;

                if (value === 'oda-create') {
                    const name = interaction.fields.getTextInputValue('oda-adı');
                    let limit = parseInt(interaction.fields.getTextInputValue('oda-limit'), 10);
                    if (isNaN(limit)) limit = 1;
                    if (limit < 0) limit = 0;
                    if (limit > 99) limit = 99;

                    const channel = await interaction.guild.channels.create({
                        name,
                        type: ChannelType.GuildVoice,
                        parent: Lyuex.kanal.ozelodakategori,
                        userLimit: limit,
                        permissionOverwrites: [
                            { id: interaction.member.id, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ViewChannel, PermissionFlagsBits.MuteMembers, PermissionFlagsBits.DeafenMembers, PermissionFlagsBits.Stream, PermissionFlagsBits.Speak], deny: [PermissionFlagsBits.SendMessages] },
                            { id: interaction.guild.id, deny: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.ViewChannel, PermissionFlagsBits.MuteMembers, PermissionFlagsBits.DeafenMembers, PermissionFlagsBits.Stream, PermissionFlagsBits.Speak] }
                        ]
                    });

                    db.set(`özeloda_${interaction.member.id}`, channel.id);
                    db.set(`${channel.id}`, `${interaction.member.id}`);
                    db.push(`members_${channel.id}`, interaction.member.id);

                    await channel.send({ content: `<@${interaction.member.id}> Selam, özel odanı bu butonlardan yönetebilirsin.`, components: getOdaButtons() });
                    return interaction.reply({ content: 'Odanız Başarıyla Açıldı!', ephemeral: true });
                }

                if (value === 'user-add') {
                    const userID = interaction.fields.getTextInputValue('kisi');
                    const member = interaction.guild.members.cache.get(userID);
                    if (!member) return interaction.reply({ content: '> **Sunucuda Böyle Bir Kullanıcı Bulunmamakta!**', ephemeral: true });
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    const channel = interaction.guild.channels.cache.get(data);
                    await channel.permissionOverwrites.edit(member, { Connect: true, ViewChannel: true, Stream: true, Speak: true });
                    const invite = await channel.createInvite({ maxUses: 1 });
                    member.user.send({ content: `> **${interaction.user.username} Kullanıcısı Seni Özel Odasına Ekledi!**\n> **Odaya Katıl;** ${invite.url}` }).catch(() => {});
                    db.push(`members_${data}`, member.id);
                    return interaction.reply({ content: `> **${member} Kullanıcısı Kanala Başarıyla Eklendi!**`, ephemeral: true });
                }

                if (value === 'user-substr') {
                    const userID = interaction.fields.getTextInputValue('kisi');
                    const member = interaction.guild.members.cache.get(userID);
                    if (!member) return interaction.reply({ content: '> **Sunucuda Böyle Bir Kullanıcı Bulunmamakta!**', ephemeral: true });
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    const channel = interaction.guild.channels.cache.get(data);
                    await channel.permissionOverwrites.edit(member, { Connect: false, ViewChannel: false, Stream: false, Speak: false });
                    db.pull(`members_${data}`, (element) => element == member.id, true);
                    return interaction.reply({ content: `> **${member} Kullanıcısı Kanaldan Başarıyla Çıkartıldı!**`, ephemeral: true });
                }

                if (value === 'oda-name') {
                    const isim = interaction.fields.getTextInputValue('oda-adı');
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    await interaction.guild.channels.edit(data, { name: `#${isim}` });
                    return interaction.reply({ content: `> **Oda Adı Başarıyla \`${isim}\` Olarak Değiştirildi!**`, ephemeral: true });
                }

                if (value === 'user-dis') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    const kisi = interaction.fields.getTextInputValue('kisi');
                    const channel = interaction.guild.channels.cache.get(data);
                    try {
                        const member = await interaction.guild.members.fetch(kisi);
                        if (!member.voice.channel || member.voice.channel.id !== channel.id) {
                            return interaction.reply({ content: '> **Belirtilen Üye Özel Oda Kanalında Bulunmamakta!**', ephemeral: true });
                        }
                        await member.voice.disconnect();
                        return interaction.reply({ content: `> **${member} Ses Kanalından Başarıyla Atıldı!**`, ephemeral: true });
                    } catch {
                        return interaction.reply({ content: '> **Böyle Bir Kullanıcı Bulunmamakta!**', ephemeral: true });
                    }
                }

                if (value === 'bit-hız') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    let bit = parseInt(interaction.fields.getTextInputValue('bit'), 10);
                    if (isNaN(bit)) bit = 96;
                    if (bit > 96) bit = 96;
                    if (bit < 8) bit = 8;
                    const channel = interaction.guild.channels.cache.get(data);
                    await channel.setBitrate(bit * 1000);
                    return interaction.reply({ content: `> **Özel Odanın Bit Hızı Başarıyla \`${bit}\` Olarak Ayarlandı!**`, ephemeral: true });
                }

                if (value === 'oda-sayı') {
                    const data = db.get(`özeloda_${interaction.member.id}`);
                    let sayı = parseInt(interaction.fields.getTextInputValue('limit'), 10);
                    if (isNaN(sayı)) sayı = 99;
                    if (sayı > 99) sayı = 99;
                    if (sayı < 0) sayı = 0;
                    const channel = interaction.guild.channels.cache.get(data);
                    await channel.setUserLimit(sayı);
                    return interaction.reply({ content: `> **Özel Odanın Kişi Sayısı Başarıyla \`${sayı === 0 ? 'Sınırsız' : sayı}\` Olarak Ayarlandı!**`, ephemeral: true });
                }
            }
        } catch (error) {
            console.error('[ÖzelOda] Interaction hatası:', error);
        }
    },
};
