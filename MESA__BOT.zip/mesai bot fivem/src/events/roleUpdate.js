﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const Lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajı');

module.exports = {
    name: Events.GuildRoleUpdate,
    async execute(oldRole, newRole, client) {
        try {
            if (Lyuex.log.rolguncelleme) {
                const Lyuexinguncelrolu = client.channels.cache.find(channel => channel.name === 'role_log');
                oldRole.guild.fetchAuditLogs({ type: AuditLogEvent.RoleUpdate }).then(audit => {
                    const Lyuexinallahiyok = audit.entries.first();
                    const minis = Lyuexinallahiyok.executor;
                    if (oldRole.id === Lyuexinallahiyok.target.id || newRole.id === Lyuexinallahiyok.target.id) {
                        const Lyuexinrolguncellemeembedi = new EmbedBuilder()
                            .setColor('#ff0000')
                            .setTitle('Rol Güncellendi')
                            .setDescription(`Eski Rol bilgileri: \n > **${oldRole.name}** - ${oldRole.id} - <@&${oldRole.id}> \nYeni rol bilgileri: \n >**${newRole.name}** - ${newRole.id} - <@&${newRole.id}> \n\n Kişi: ${minis.tag} - ${minis.id} - <@${minis.id}> `)
                            .setThumbnail(newRole.guild.iconURL({ dynamic: true}))
                            .setFooter({ text: Lyuex.reklam.Lyuexisim, iconURL: Lyuex.reklam.Lyuexprofile })
                            .setTimestamp();
                        if (Lyuexinguncelrolu) {
                            Lyuexinguncelrolu.send({ embeds: [Lyuexinrolguncellemeembedi]});
                        }
                    }
                });
            }
        }
        catch (error) {
            catchError(client, 'roleUpdate.js', error.message);
        }
    }
};
