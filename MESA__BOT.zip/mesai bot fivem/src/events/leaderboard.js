﻿const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const Lyuex = require('../../lyuex.json');
const { LEADERBOARD_PAGE_SIZE } = require('../utils/constants');
const db = new JsonDatabase({
    databasePath: "./src/database/fordb.json"
  });

function getMesaiData() {
    const allData = db.all();
    
    const sortedByEntries = allData
        .map(entry => ({ ID: entry.ID, count: Object.keys(entry.data.mesailer).length }))
        .sort((a, b) => b.count - a.count);
    
    const sortedByDuration = allData
        .map(entry => {
            const mesailer = entry.data.mesailer;
            let totalDuration = 0;
            for (const key in mesailer) {
                const mesaiBilgisi = mesailer[key];
                if (!mesaiBilgisi.giriş) continue;
                const giriş = moment(mesaiBilgisi.giriş);
                const çıkış = mesaiBilgisi.çıkış ? moment(mesaiBilgisi.çıkış) : moment();
                if (!giriş.isValid() || !çıkış.isValid()) continue;
                totalDuration += çıkış.diff(giriş, 'minutes');
            }
            return { ID: entry.ID, duration: totalDuration };
        })
        .sort((a, b) => b.duration - a.duration);

    return { sortedByEntries, sortedByDuration };
}

function buildMesaiEmbeds(sortedByEntries, sortedByDuration, page = 0) {
    const start = page * LEADERBOARD_PAGE_SIZE;
    const end = start + LEADERBOARD_PAGE_SIZE;
    const totalPages = Math.max(1, Math.ceil(Math.max(sortedByEntries.length, sortedByDuration.length) / LEADERBOARD_PAGE_SIZE));

    const topSlice = sortedByEntries.slice(start, end);
    const durSlice = sortedByDuration.slice(start, end);

    const topEntries = topSlice.map((entry, i) => `**${start + i + 1}.** <@${entry.ID}> (${entry.count} giriş)`).join('\n');
    const longestEntries = durSlice.map((entry, i) => `**${start + i + 1}.** <@${entry.ID}> (${entry.duration} dakika)`).join('\n');

    const mostEntriesEmbed = new EmbedBuilder()
        .setTitle('En Çok Mesaiye Giren Kişiler')
        .setDescription(topEntries || 'Veri yok')
        .setFooter({ text: `Sayfa ${page + 1}/${totalPages}` });

    const longestDurationEmbed = new EmbedBuilder()
        .setTitle('En Uzun Mesai Süresine Sahip Kişiler')
        .setDescription(longestEntries || 'Veri yok')
        .setFooter({ text: `Sayfa ${page + 1}/${totalPages}` });

    return { mostEntriesEmbed, longestDurationEmbed, totalPages };
}

async function updateMesaiLeaderboard(client) {
    const channel = await client.channels.fetch(Lyuex.leaderboard.mesai);
    if (!channel) return;

    const { sortedByEntries, sortedByDuration } = getMesaiData();
    const { mostEntriesEmbed, longestDurationEmbed, totalPages } = buildMesaiEmbeds(sortedByEntries, sortedByDuration, 0);

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('mesai_lb_prev_0').setLabel('◀ Önceki').setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId('mesai_lb_next_0').setLabel('Sonraki ▶').setStyle(ButtonStyle.Secondary).setDisabled(totalPages <= 1),
    );

    const messages = await channel.messages.fetch({ limit: 10 });
    const botMessage = messages.find(m => m.author.id === client.user.id);

    if (botMessage) {
        await botMessage.edit({ embeds: [mostEntriesEmbed, longestDurationEmbed], components: [row] });
    } else {
        await channel.send({ embeds: [mostEntriesEmbed, longestDurationEmbed], components: [row] });
    }
}

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        updateMesaiLeaderboard(client);
        setInterval(() => updateMesaiLeaderboard(client), 900000);
    },
    updateMesaiLeaderboard,
    getMesaiData,
    buildMesaiEmbeds,
};
