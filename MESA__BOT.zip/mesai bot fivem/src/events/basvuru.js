﻿const { Events, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, EmbedBuilder, ButtonStyle, ButtonBuilder, ChannelType, ButtonInteraction, ButtonComponent } = require('discord.js');
const Lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (interaction.isButton() && interaction.customId === 'Lyuexinmodali') {
            const Lyuexinyetkilimodali = new ModalBuilder()
                .setCustomId('Lyuexinmodali')
                .setTitle(interaction.guild.name);

            const Lyuexinsordugusorular1 = new TextInputBuilder()
                .setCustomId('Lyuexinsordugusorular1')
                .setLabel(Lyuex.basvuru.birincisoru)
                .setPlaceholder(Lyuex.basvuru.birincisoruplace)
                .setMinLength(10)
                .setStyle(TextInputStyle.Short);

            const Lyuexinsordugusorular2 = new TextInputBuilder()
                .setCustomId('Lyuexinsordugusorular2')
                .setLabel(Lyuex.basvuru.ikincisoru)
                .setPlaceholder(Lyuex.basvuru.ikincisorusoruplace)
                .setStyle(TextInputStyle.Short);

            const Lyuexinsordugusorular3 = new TextInputBuilder()
                .setCustomId('Lyuexinsordugusorular3')
                .setLabel(Lyuex.basvuru.ucuncusoru)
                .setPlaceholder(Lyuex.basvuru.ucuncusoruplace)
                .setMinLength(5)
                .setRequired(false)
                .setStyle(TextInputStyle.Short);

            const Lyuexinsordugusorular4 = new TextInputBuilder()
                .setCustomId('Lyuexinsordugusorular4')
                .setLabel(Lyuex.basvuru.dorduncusoru)
                .setPlaceholder(Lyuex.basvuru.dorduncusoruplace)
                .setMinLength(35)
                .setStyle(TextInputStyle.Paragraph);
                
            const Lyuexinsordugusorular5 = new TextInputBuilder()
            .setCustomId('Lyuexinsordugusorular5')
            .setLabel(Lyuex.basvuru.besincisoru)
            .setPlaceholder(Lyuex.basvuru.besincisoruplace)
            .setMinLength(35)
            .setStyle(TextInputStyle.Paragraph);

            const birincisoru = new ActionRowBuilder().addComponents(Lyuexinsordugusorular1);
            const ikincisoru = new ActionRowBuilder().addComponents(Lyuexinsordugusorular2);
            const ucuncusoru = new ActionRowBuilder().addComponents(Lyuexinsordugusorular3);
            const dorduncusoru = new ActionRowBuilder().addComponents(Lyuexinsordugusorular4);
            const besincisoru = new ActionRowBuilder().addComponents(Lyuexinsordugusorular5);

            Lyuexinyetkilimodali.addComponents(birincisoru, ikincisoru, ucuncusoru, dorduncusoru, besincisoru);
            await interaction.showModal(Lyuexinyetkilimodali);
 } else if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'Lyuexinmodali') {
            const Lyuexinsordugusorular1 = interaction.fields.getTextInputValue('Lyuexinsordugusorular1');
            const Lyuexinsordugusorular2 = interaction.fields.getTextInputValue('Lyuexinsordugusorular2');
            const Lyuexinsordugusorular3 = interaction.fields.getTextInputValue('Lyuexinsordugusorular3');
            const Lyuexinsordugusorular4 = interaction.fields.getTextInputValue('Lyuexinsordugusorular4');
            const Lyuexinsordugusorular5 = interaction.fields.getTextInputValue('Lyuexinsordugusorular5');
            const Lyuexinyetkililogodasi = interaction.guild.channels.cache.find(channel => channel.name === 'Lyuex_log');
            const Lyuexinyetkiliembedi = new EmbedBuilder()
            .setTitle(`Başvuru Geldi!`)
            .setDescription(`${Lyuex.basvuru.birincisoru} \n > ${Lyuexinsordugusorular1}  \n\n ${Lyuex.basvuru.ikincisoru} \n > ${Lyuexinsordugusorular2} \n\n ${Lyuex.basvuru.ucuncusoru} : \n > ${Lyuexinsordugusorular3} \n\n ${Lyuex.basvuru.dorduncusoru}: \n > ${Lyuexinsordugusorular4} \n\n ${Lyuex.basvuru.besincisoru} \n > ${Lyuexinsordugusorular5}`)
            .setImage(Lyuex.mesai.ekip.photograph);
            const Lyuexinyetkilikabulactionu = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('Lyuexinyetkilikabulbuttonu')
                    .setLabel('Kabul Et')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('Lyuexinyetkiliredbutonu')
                    .setLabel('Reddet')
                    .setStyle(ButtonStyle.Danger)
            );
            const collector_channel = interaction.guild.channels.cache.find(channel => channel.name === 'Lyuex_log');
            if (!collector_channel || collector_channel.type !== ChannelType.GuildText) {
                console.error('Kanal bulunamad\u0131 veya ge\u00e7ersiz kanal tipi.');
                return;
            }

            const sentMessage = await collector_channel.send( { content: `<@&${Lyuex.rol.yonetici}>, <@${interaction.member.id}> ba\u015fvuru att\u0131!`, embeds: [Lyuexinyetkiliembedi], components: [Lyuexinyetkilikabulactionu]} );
            const collector = sentMessage.createMessageComponentCollector();
            const Lyuexinyetkilirolleri = Lyuex.rol.kay\u0131tl\u0131;
            const Lyuexinkayitsizrolu = Lyuex.rol.kay\u0131ts\u0131z;
            const Lyuexinyetkikbasvurusuatanmali = interaction.member;
            collector.on('collect', async btnInteraction => {
                if (btnInteraction.customId === 'Lyuexinyetkilikabulbuttonu') {
                    await btnInteraction.update({ content: `Ekip Başvurusu <@${btnInteraction.user.id}> - (${btnInteraction.user.id}) tarafından kabul edildi. Roller veriliyor...`, components: [] });
                    Lyuexinyetkikbasvurusuatanmali.roles.add(Lyuexinyetkilirolleri);
                    Lyuexinyetkikbasvurusuatanmali.roles.remove(Lyuexinkayitsizrolu);
                } else if (btnInteraction.customId === 'Lyuexinyetkiliredbutonu') {
                    await btnInteraction.update({ content: `Ekip Başvurusu <@${btnInteraction.user.id}> - (${btnInteraction.user.id}) tarafından reddedildi.`, components: [] });
                }
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    sentMessage.edit({ content: 'Başvuru zaman aşımına uğradı.', components: [] }).catch(console.error);
                }
            });
            
            await interaction.reply({ content: `# BAŞVURUNUZ BAŞARIYLA GÖNDERİLDİ! \n\n ${Lyuex.basvuru.birincisoru} \n > ${Lyuexinsordugusorular1}  \n\n ${Lyuex.basvuru.ikincisoru} \n > ${Lyuexinsordugusorular2} \n\n ${Lyuex.basvuru.ucuncusoru} : \n > ${Lyuexinsordugusorular3} \n\n ${Lyuex.basvuru.dorduncusoru}: \n > ${Lyuexinsordugusorular4} \n\n ${Lyuex.basvuru.besincisoru} \n > ${Lyuexinsordugusorular5}`, ephemeral: true });
        }
    }
};
