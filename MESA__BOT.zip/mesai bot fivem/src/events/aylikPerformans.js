// ═══════════════════════════════════════════════
//  Aylık Performans Raporu — Her ayın 1'inde 09:00'da
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, progressBar, findLogChannel } = require('../utils/theme');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        scheduleMonthly(client);
        console.log('[AylıkPerformans] Zamanlayıcı aktif.');
    },
};

function scheduleMonthly(client) {
    // Her gün saat 09:00'da kontrol et, ayın 1'inde rapor gönder
    const now = new Date();
    const next = new Date();
    next.setHours(9, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);

    const delay = next - now;
    setTimeout(() => {
        if (new Date().getDate() === 1) sendMonthlyReport(client);
        setInterval(() => {
            if (new Date().getDate() === 1) sendMonthlyReport(client);
        }, 24 * 60 * 60 * 1000);
    }, delay);
}

async function sendMonthlyReport(client) {
    try {
        const logKanalId = config.polis?.raporKanali || config.polis?.logKanali;
        let channel = null;

        if (logKanalId) {
            channel = await client.channels.fetch(logKanalId).catch(() => null);
        }
        if (!channel) {
            const guild = await client.guilds.fetch(config.botSettings.ServerID).catch(() => null);
            if (guild) channel = findLogChannel(guild, 'performans_log', 'polis_log', 'lyuex_log');
        }
        if (!channel) return;

        const gecenAy = moment().subtract(1, 'month');
        const ayBaslangic = gecenAy.clone().startOf('month');
        const ayBitis = gecenAy.clone().endOf('month');
        const ayAdi = gecenAy.format('MMMM YYYY');

        const maasConfig = config.polis?.maas || { saatlikUcret: 500, paraBirimi: '₺' };

        // Tüm personel verilerini topla
        const allMesai = mesaiDb.toJSON() || {};
        const tutuklamalar = policeDb.get('tutuklamalar') || [];
        const cezalar = policeDb.get('cezalar') || [];
        const devriyeler = policeDb.get('devriyeler') || [];
        const egitimler = policeDb.get('egitimler') || [];

        const personelStats = {};

        // Mesai verileri
        for (const [userId, data] of Object.entries(allMesai)) {
            if (!data?.mesailer) continue;
            if (!personelStats[userId]) personelStats[userId] = { mesaiDk: 0, mesaiSayi: 0, tutuklama: 0, ceza: 0, devriye: 0, egitim: 0, egitimPuan: 0 };

            for (const m of Object.values(data.mesailer)) {
                if (!m['giriş']) continue;
                const giris = moment(m['giriş']);
                if (giris.isBefore(ayBaslangic) || giris.isAfter(ayBitis)) continue;
                personelStats[userId].mesaiSayi++;
                if (m['çıkış']) {
                    const sure = moment(m['çıkış']).diff(giris, 'minutes');
                    if (sure > 0) personelStats[userId].mesaiDk += sure;
                }
            }
        }

        // Tutuklama verileri
        for (const t of tutuklamalar) {
            if (!moment(t.tarih).isBetween(ayBaslangic, ayBitis, null, '[]')) continue;
            if (!personelStats[t.memurId]) personelStats[t.memurId] = { mesaiDk: 0, mesaiSayi: 0, tutuklama: 0, ceza: 0, devriye: 0, egitim: 0, egitimPuan: 0 };
            personelStats[t.memurId].tutuklama++;
        }

        // Ceza verileri
        for (const c of cezalar) {
            if (!moment(c.tarih).isBetween(ayBaslangic, ayBitis, null, '[]')) continue;
            if (!personelStats[c.memurId]) personelStats[c.memurId] = { mesaiDk: 0, mesaiSayi: 0, tutuklama: 0, ceza: 0, devriye: 0, egitim: 0, egitimPuan: 0 };
            personelStats[c.memurId].ceza++;
        }

        // Devriye verileri
        for (const d of devriyeler) {
            if (!moment(d.tarih).isBetween(ayBaslangic, ayBitis, null, '[]')) continue;
            if (!personelStats[d.memurId]) personelStats[d.memurId] = { mesaiDk: 0, mesaiSayi: 0, tutuklama: 0, ceza: 0, devriye: 0, egitim: 0, egitimPuan: 0 };
            personelStats[d.memurId].devriye++;
        }

        // Eğitim verileri
        for (const e of egitimler) {
            if (!moment(e.baslangic).isBetween(ayBaslangic, ayBitis, null, '[]')) continue;
            for (const k of (e.katilimcilar || [])) {
                if (!personelStats[k.id]) personelStats[k.id] = { mesaiDk: 0, mesaiSayi: 0, tutuklama: 0, ceza: 0, devriye: 0, egitim: 0, egitimPuan: 0 };
                personelStats[k.id].egitim++;
                personelStats[k.id].egitimPuan += k.puan || 0;
            }
        }

        // Performans skoru hesapla ve sırala
        const skor = (s) => {
            const mesaiPuan = Math.min(40, (s.mesaiDk / 60) * 2); // max 40 puan (20 saat)
            const aktivitePuan = Math.min(30, (s.tutuklama * 5 + s.ceza * 3 + s.devriye * 4)); // max 30 puan
            const egitimPuanı = Math.min(20, s.egitim * 10); // max 20 puan
            const bonus = s.egitimPuan > 0 ? Math.min(10, (s.egitimPuan / Math.max(1, s.egitim)) / 10) : 0;
            return Math.round(mesaiPuan + aktivitePuan + egitimPuanı + bonus);
        };

        const sirali = Object.entries(personelStats)
            .map(([userId, stats]) => ({ userId, ...stats, skor: skor(stats) }))
            .sort((a, b) => b.skor - a.skor);

        const toplamKisi = sirali.length;
        const toplamMesaiSaat = Math.round(sirali.reduce((t, s) => t + s.mesaiDk, 0) / 60);
        const toplamTutuklama = sirali.reduce((t, s) => t + s.tutuklama, 0);
        const toplamCeza = sirali.reduce((t, s) => t + s.ceza, 0);
        const toplamDevriye = sirali.reduce((t, s) => t + s.devriye, 0);
        const ortSkor = toplamKisi > 0 ? Math.round(sirali.reduce((t, s) => t + s.skor, 0) / toplamKisi) : 0;

        const medals = ['🥇', '🥈', '🥉'];
        const top10 = sirali.slice(0, 10).map((p, i) => {
            const medal = medals[i] || `\`${i + 1}.\``;
            const saat = (p.mesaiDk / 60).toFixed(1);
            return `${medal} <@${p.userId}> — ⭐ **${p.skor}** • ⏰ ${saat}s • 🔒${p.tutuklama} • 🚓${p.devriye}`;
        });

        // En aktif, en çok tutuklama, en çok devriye
        const enAktif = sirali[0];

        const embed = new EmbedBuilder()
            .setColor(THEME.gold)
            .setTitle(`📊 Aylık Performans Raporu — ${ayAdi}`)
            .setDescription([
                ansiHeader('📊  AYLIK PERFORMANS RAPORU', '33'),
                '',
                `📅 **Dönem:** \`${ayAdi}\``,
                `📈 **Ortalama Skor:** \`${ortSkor}/100\``,
                `\`${progressBar(ortSkor, 100, 25)}\``,
            ].join('\n'))
            .addFields(
                { name: '📊 Genel İstatistikler', value: [
                    `👥 Aktif Personel: \`${toplamKisi}\``,
                    `⏰ Toplam Mesai: \`${toplamMesaiSaat} saat\``,
                    `🔒 Tutuklamalar: \`${toplamTutuklama}\``,
                    `📝 Cezalar: \`${toplamCeza}\``,
                    `🚓 Devriyeler: \`${toplamDevriye}\``,
                ].join('\n'), inline: true },
                { name: '🏆 Ayın Yıldızları', value: [
                    enAktif ? `⭐ **Ayın Polisi:** <@${enAktif.userId}> (${enAktif.skor} puan)` : '`—`',
                    sirali.find(s => s.tutuklama > 0) ? `🔒 **En Çok Tutuklama:** <@${sirali.sort((a, b) => b.tutuklama - a.tutuklama)[0].userId}>` : '`—`',
                    sirali.find(s => s.devriye > 0) ? `🚓 **En Çok Devriye:** <@${sirali.sort((a, b) => b.devriye - a.devriye)[0].userId}>` : '`—`',
                ].join('\n'), inline: true }
            )
            .addFields(
                { name: '🏅 Performans Sıralaması (Top 10)', value: top10.join('\n') || '`Veri bulunamadı.`' }
            )
            .setFooter({ text: 'Otomatik Aylık Rapor • Lyuex Polis Sistemi • Skor: Mesai(40) + Aktivite(30) + Eğitim(20) + Bonus(10)' })
            .setTimestamp();

        await channel.send({ embeds: [embed] });
    } catch (err) {
        console.error('[AylıkPerformans] Hata:', err.message);
    }
}
