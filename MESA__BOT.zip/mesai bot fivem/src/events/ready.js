﻿const { ActivityType, Events } = require("discord.js");
const Lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {


        console.log(`${client.user.tag} aktif!`);
        setPresence(client);



    },
};

function setPresence(client) {
    client.user.setPresence({
        activities: [
            {
                name: Lyuex.botSettings.oynuyor,
                type: ActivityType.Competing,
            },
        ],
        status: Lyuex.botSettings.durum,
    });
}