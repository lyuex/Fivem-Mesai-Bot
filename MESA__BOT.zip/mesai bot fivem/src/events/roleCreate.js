﻿const { EmbedBuilder, Events } = require('discord.js');
const Lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajı');

module.exports = {
   name: Events.GuildRoleCreate,
    async execute(role, client) {
    try {
        if (Lyuex.log.rolguncelleme) {
            const Lyuexinrollogu = client.channels.cache.find(channel => channel.name === 'role_log');
            role.guild.fetchAuditLogs({ type: 30 }).then(audit => {
                 const Lyuexkk = audit.entries.first();
                 const oc = Lyuexkk.executor;
                 const roleCreateEmbed = new EmbedBuilder()
                .setColor('#00ff1a')
                .setTitle('Rol Oluşturuldu!')
                .setDescription(`Rol: \n >**${role.name}** - ${role.id} - <@&${role.id}> \n\n Kişi: \n >${oc.tag} - ${oc.id} - <@${oc.id}> `)
                .setThumbnail(role.guild.iconURL({ dynamic: true}))
                .setFooter({ text: Lyuex.reklam.Lyuexisim, iconURL: Lyuex.reklam.Lyuexprofile })
                .setTimestamp();
            if (Lyuexinrollogu) {
                Lyuexinrollogu.send({ embeds: [roleCreateEmbed] });
                    } else {
                             console.log('Role log kanalı bulunamadı.');
                      }
                  });
                }
                } 
           catch (error) {
              catchError(client,'roleCreate.js', error.message)
         }
     },
};
