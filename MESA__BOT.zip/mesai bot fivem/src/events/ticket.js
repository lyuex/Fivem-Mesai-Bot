// ═══════════════════════════════════════════════
//  Ticket / Destek Sistemi
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const Lyuex = require('../../lyuex.json');
const { THEME } = require('../utils/theme');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        try {
            // ── Destek Oluştur Butonu ──
            if (interaction.isButton() && interaction.customId === 'ticket_olustur') {
                const existing = interaction.guild.channels.cache.find(
                    ch => ch.name === `destek-${interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '')}`
                );
                if (existing) {
                    return interaction.reply({ content: `❌ Zaten açık bir destek talebiniz var: ${existing}`, ephemeral: true });
                }

                const kategori = Lyuex.ticket?.kategori;
                const channel = await interaction.guild.channels.create({
                    name: `destek-${interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
                    type: ChannelType.GuildText,
                    parent: kategori || null,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
                    ],
                });

                const embed = new EmbedBuilder()
                    .setColor(THEME.primary)
                    .setTitle('🎫 Destek Talebi')
                    .setDescription(`Merhaba ${interaction.user}, destek ekibi en kısa sürede yardımcı olacaktır.\n\nSorununuzu detaylıca açıklayınız.`)
                    .setFooter({ text: `Talep: ${interaction.user.tag}` })
                    .setTimestamp();

                const closeRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('ticket_kapat').setLabel('Talebi Kapat').setEmoji('🔒').setStyle(ButtonStyle.Danger)
                );

                await channel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [closeRow] });
                await interaction.reply({ content: `✅ Destek talebiniz oluşturuldu: ${channel}`, ephemeral: true });

                // Log
                const logChannel = interaction.guild.channels.cache.find(ch => ch.name === 'ticket_log');
                if (logChannel) {
                    logChannel.send({
                        embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`🎫 **Yeni Destek Talebi**\nKullanıcı: ${interaction.user}\nKanal: ${channel}`).setTimestamp()]
                    }).catch(() => {});
                }
            }

            // ── Destek Kapat Butonu ──
            if (interaction.isButton() && interaction.customId === 'ticket_kapat') {
                if (!interaction.channel.name.startsWith('destek-')) return;

                await interaction.reply({ content: '🔒 Bu destek talebi 5 saniye içinde kapatılacak...' });

                // Transcript oluştur
                const messages = await interaction.channel.messages.fetch({ limit: 100 });
                let transcript = `Destek Talebi Kaydı — ${interaction.channel.name}\nKapatan: ${interaction.user.tag}\nTarih: ${new Date().toLocaleString('tr-TR')}\n${'═'.repeat(50)}\n\n`;
                messages.reverse().forEach(msg => {
                    transcript += `[${msg.createdAt.toLocaleString('tr-TR')}] ${msg.author.tag}: ${msg.content || '(embed/dosya)'}\n`;
                });

                const logChannel = interaction.guild.channels.cache.find(ch => ch.name === 'ticket_log');
                if (logChannel) {
                    const buf = Buffer.from(transcript, 'utf-8');
                    logChannel.send({
                        embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`🔒 **Destek Talebi Kapatıldı**\nKanal: ${interaction.channel.name}\nKapatan: ${interaction.user}`).setTimestamp()],
                        files: [{ attachment: buf, name: `${interaction.channel.name}-transcript.txt` }]
                    }).catch(() => {});
                }

                setTimeout(() => {
                    interaction.channel.delete('Destek talebi kapatıldı').catch(() => {});
                }, 5000);
            }
        } catch (error) {
            console.error('[Ticket] Hata:', error);
        }
    },
};
