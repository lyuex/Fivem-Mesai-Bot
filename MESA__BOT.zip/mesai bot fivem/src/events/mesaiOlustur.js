const { Events } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const fs = require('fs');
const { updateMesaiLeaderboard } = require('./leaderboard');

const db = new JsonDatabase({
    databasePath: "./src/database/fordb.json"
  });

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (interaction.isStringSelectMenu() && interaction.customId === 'mesai-olustur') {
            const selectedValue = interaction.values[0];
            const userId = interaction.user.id;

            if (!db.has(userId)) {
                db.set(userId, {
                    status: 'none',
                    mesailer: {}
                });
            }

            const userData = db.get(userId);

            if (!userData.mesailer) {
                userData.mesailer = {};
                db.set(userId, userData);
            }

            const mesaiKeys = Object.keys(userData.mesailer);
            const mesaiNumarası = mesaiKeys.length;

            switch (selectedValue) {
                case 'mesaigir':
                    if (userData.status === 'in') {
                        const aktifMesai = userData.mesailer[mesaiKeys[mesaiKeys.length - 1]];
                        const girişTimestamp = Math.floor(new Date(aktifMesai.giriş).getTime() / 1000);
                        await interaction.reply({ content: `<@${userId}> zaten mesaide! Giriş: <t:${girişTimestamp}:f> (<t:${girişTimestamp}:R>)`, ephemeral: true });
                        return;
                    }

                    const yeniMesaiNo = mesaiNumarası + 1;
                    const girişZamanıStr = moment().format('YYYY-MM-DD HH:mm:ss');
                    db.set(`${userId}.status`, 'in');
                    db.set(`${userId}.mesailer.${yeniMesaiNo}`, {
                        giriş: girişZamanıStr,
                        çıkış: null
                    });
                    const girişTs = Math.floor(new Date(girişZamanıStr).getTime() / 1000);
                    await interaction.reply({ content: `<@${userId}> mesaiye girdi! Giriş: <t:${girişTs}:f>`, ephemeral: true });
                    updateMesaiLeaderboard(interaction.client).catch(console.error);
                    break;

                case 'mesaicheck':
                    const currentStatus = db.get(`${userId}.status`);
                    const mesailer = db.get(`${userId}.mesailer`);
                    const mesailerKeys = Object.keys(mesailer);
                    const sonMesaiKey = mesailerKeys[mesailerKeys.length - 1];

                    if (!sonMesaiKey || !mesailer[sonMesaiKey]) {
                        await interaction.reply({ content: `<@${userId}> için mesai kaydı bulunamadı.`, ephemeral: true });
                        break;
                    }

                    const sonMesai = mesailer[sonMesaiKey];
                    const girişZamanii = sonMesai.giriş ? moment(sonMesai.giriş) : null;
                    const çıkışZamanii = sonMesai.çıkış ? moment(sonMesai.çıkış) : null;

                    let mesaiBilgisi = '';
                    if (currentStatus === 'in' && girişZamanii) {
                        const şuAnki = moment();
                        const aktifSüre = moment.duration(şuAnki.diff(girişZamanii));
                        const aHours = Math.floor(aktifSüre.asHours());
                        const aMinutes = Math.floor(aktifSüre.asMinutes()) % 60;
                        const aSeconds = Math.floor(aktifSüre.asSeconds()) % 60;
                        const girişTs = Math.floor(new Date(sonMesai.giriş).getTime() / 1000);
                        mesaiBilgisi = `<@${userId}> şu anda mesaide.\nGiriş: <t:${girişTs}:f> (<t:${girişTs}:R>)\nGeçen Süre: ${aHours} saat, ${aMinutes} dakika, ${aSeconds} saniye`;
                    } else if (girişZamanii && çıkışZamanii) {
                        const mesaiSüresi = moment.duration(çıkışZamanii.diff(girişZamanii));
                        const hours = Math.floor(mesaiSüresi.asHours());
                        const minutes = Math.floor(mesaiSüresi.asMinutes()) % 60;
                        const seconds = Math.floor(mesaiSüresi.asSeconds()) % 60;
                        const gTs = Math.floor(new Date(sonMesai.giriş).getTime() / 1000);
                        const cTs = Math.floor(new Date(sonMesai.çıkış).getTime() / 1000);
                        mesaiBilgisi = `<@${userId}> mesaide değil.\nSon Giriş: <t:${gTs}:f>\nSon Çıkış: <t:${cTs}:f>\nSüre: ${hours} saat, ${minutes} dakika, ${seconds} saniye`;
                    } else {
                        mesaiBilgisi = `<@${userId}> mesaide değil. Geçerli bir mesai kaydı bulunamadı.`;
                    }

                    mesaiBilgisi += `\nToplam Mesai Sayısı: ${mesailerKeys.length}`;

                    await interaction.reply({ content: mesaiBilgisi, ephemeral: true });
                    break;

                case 'mesaicik':
                    if (userData.status !== 'in') {
                        await interaction.reply({ content: `<@${userId}> zaten mesaide değil.`, ephemeral: true });
                        return;
                    }

                    const şuAn = moment();
                    const sonMesaiKeyForCik = mesaiKeys[mesaiKeys.length - 1];
                    const mevcutMesai = sonMesaiKeyForCik ? userData.mesailer[sonMesaiKeyForCik] : null;
                    if (!mevcutMesai || mevcutMesai.çıkış) {
                        await interaction.reply({ content: `<@${userId}> geçerli bir mesai kaydı bulunmamaktadır.`, ephemeral: true });
                        return;
                    }

                    db.set(`${userId}.status`, 'out');
                    db.set(`${userId}.mesailer.${sonMesaiKeyForCik}.çıkış`, şuAn.format('YYYY-MM-DD HH:mm:ss'));

                    const girişZamani = moment(mevcutMesai.giriş);
                    const çıkışZamani = şuAn;
                    const mesaiSüresi = moment.duration(çıkışZamani.diff(girişZamani));
                    const hours = Math.floor(mesaiSüresi.asHours());
                    const minutes = Math.floor(mesaiSüresi.asMinutes()) % 60;
                    const seconds = Math.floor(mesaiSüresi.asSeconds()) % 60;

                    await interaction.reply({ content: `<@${userId}> mesaiden çıkıldı.\nToplam Mesai Süresi: ${hours} saat, ${minutes} dakika, ${seconds} saniye, `, ephemeral: true });
                    updateMesaiLeaderboard(interaction.client).catch(console.error);
                    break;

                case 'mesailerim':
                    const tümMesailer = db.get(`${userId}.mesailer`);
                    if (Object.keys(tümMesailer).length === 0) {
                        await interaction.reply({ content: `<@${userId}> için herhangi bir mesai kaydı bulunmamaktadır.`, ephemeral: true });
                        return;
                    }

                    let mesaiBilgisiForAll = 'Geçmiş Mesai Kayıtları:\n';
                    for (const [key, value] of Object.entries(tümMesailer)) {
                        const girişZamani = moment(value.giriş);
                        const çıkışZamani = value.çıkış ? moment(value.çıkış) : null;
                        const mesaiSüresi = çıkışZamani ? moment.duration(çıkışZamani.diff(girişZamani)) : null;
                        const hours = mesaiSüresi ? Math.floor(mesaiSüresi.asHours()) : 0;
                        const minutes = mesaiSüresi ? Math.floor(mesaiSüresi.asMinutes()) % 60 : 0;
                        const seconds = mesaiSüresi ? Math.floor(mesaiSüresi.asSeconds()) % 60 : 0;

                        mesaiBilgisiForAll += `**${key}. Mesai**\nGiriş: ${girişZamani.format('YYYY-MM-DD HH:mm:ss')} \nÇıkış: ${value.çıkış ? çıkışZamani.format('YYYY-MM-DD HH:mm:ss') : 'Henüz çıkış yapılmamış'}\nToplam Mesai Süresi: ${hours} saat, ${minutes} dakika, ${seconds} saniye\n\n`;
                    }

                    const filePathForAll = `./mesai_kayitlari_${userId}.txt`;
                    try {
                        fs.writeFileSync(filePathForAll, mesaiBilgisiForAll);
                        await interaction.reply({ content: 'Geçmiş mesai kayıtlarınız gönderildi.', files: [filePathForAll], ephemeral: true });
                    } finally {
                        try { fs.unlinkSync(filePathForAll); } catch {}
                    }
                    break;

                case 'sifirla':
                    await interaction.reply({ content: `Seçenek sıfırlandı.`, ephemeral: true });
                    break;

                default:
                    await interaction.reply({ content: 'Geçersiz seçenek!', ephemeral: true });
                    break;
            }
        }
    },
};
