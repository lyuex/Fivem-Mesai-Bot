// ═══════════════════════════════════════════════
//  Özel Oda Sistemi — Voice Handler
// ═══════════════════════════════════════════════

const { Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const Lyuex = require('../../lyuex.json');

const db = new JsonDatabase({ databasePath: "./src/database/Lyuex_database.json" });

function getOdaButtons() {
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('user-ekle').setLabel('User Ekle').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('user-cıkar').setLabel('User Çıkar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-isim').setLabel('Oda Adı Değiştir').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-sil').setLabel('Özel Odanı Sil').setStyle(ButtonStyle.Secondary)
    );
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('oda-kilit').setLabel('Odayı Kilitle').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-limit').setLabel('Oda Limiti Değiştir').setEmoji('👥').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('sesten-at').setLabel('Sesten At').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('oda-herkes').setLabel('Odayı Herkese Aç').setStyle(ButtonStyle.Secondary)
    );
    const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('oda-bilgi').setLabel('Oda Bilgisi').setEmoji('❓').setStyle(ButtonStyle.Primary)
    );
    return [row1, row2, row3];
}

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        try {
            if (!newState.member || !newState.channelId) return;
            if (newState.channelId !== Lyuex.kanal.ozeloda) return;

            const data = db.get(`özeloda_${newState.member.id}`);

            if (!data) {
                let odaisim = newState.member.displayName.length > 10
                    ? newState.member.displayName.substring(0, 10).trim() + '..'
                    : newState.member.displayName;

                const channel = await newState.guild.channels.create({
                    name: odaisim,
                    type: ChannelType.GuildVoice,
                    parent: Lyuex.kanal.ozelodakategori,
                    userLimit: 1,
                    permissionOverwrites: [
                        {
                            id: newState.member.id,
                            allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ViewChannel, PermissionFlagsBits.MuteMembers, PermissionFlagsBits.DeafenMembers, PermissionFlagsBits.Stream, PermissionFlagsBits.Speak],
                            deny: [PermissionFlagsBits.SendMessages]
                        },
                        {
                            id: newState.guild.id,
                            deny: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.ViewChannel, PermissionFlagsBits.MuteMembers, PermissionFlagsBits.DeafenMembers, PermissionFlagsBits.Stream, PermissionFlagsBits.Speak]
                        }
                    ]
                });

                await newState.member.voice.setChannel(channel.id);
                db.set(`özeloda_${newState.member.id}`, channel.id);
                db.set(`${channel.id}`, `${newState.member.id}`);
                db.push(`members_${channel.id}`, newState.member.id);

                await channel.send({
                    content: `<@${newState.member.id}> Selam, özel odanı bu butonlardan yönetebilirsin.`,
                    components: getOdaButtons()
                });
            } else {
                const channel = newState.guild.channels.cache.get(data);
                if (channel) {
                    await newState.member.voice.setChannel(channel.id);
                }
            }
        } catch (error) {
            console.error('[ÖzelOda] voiceStateUpdate hatası:', error);
        }
    },
    db,
    getOdaButtons,
};
