﻿const { EmbedBuilder, Events } = require('discord.js');
const Lyuex = require('../../lyuex.json');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        const member = newState.member;
        const guild = member.guild;
        const logChannel = guild.channels.cache.find(channel => channel.name === 'voice_log');
        if (!logChannel) return;

        const oldChannel = oldState.channel;
        const newChannel = newState.channel;

        // Ses kanalına giriş/çıkış
        if (oldChannel !== newChannel) {
            if (!oldChannel && newChannel) {
                logChannel.send({ embeds: [createEmbed(member, newChannel, 'Kanala Katıldı', guild.iconURL())] }).catch(console.error);
            } else if (oldChannel && !newChannel) {
                logChannel.send({ embeds: [createEmbed(member, oldChannel, 'Kanaldan Ayrıldı', guild.iconURL())] }).catch(console.error);
            }
        }

        // Sağırlaştırma durumu
        if (oldState.deaf !== newState.deaf) {
            const action = newState.deaf ? 'Sağıra Alındı' : 'Sağırdan Çıktı';
            logChannel.send({ embeds: [createEmbed(member, newChannel || oldChannel, action, guild.iconURL())] }).catch(console.error);
        }
        // Susturma durumu (sağırlaştırma yoksa)
        else if (oldState.mute !== newState.mute) {
            const action = newState.mute ? 'Susturuldu' : 'Susturulmayı Kaldırdı';
            logChannel.send({ embeds: [createEmbed(member, newChannel || oldChannel, action, guild.iconURL())] }).catch(console.error);
        }

        // Yayın durumu
        if (oldState.streaming !== newState.streaming) {
            const action = newState.streaming ? 'Yayını Açtı' : 'Yayını Kapattı';
            logChannel.send({ embeds: [createEmbed(member, newChannel, action, guild.iconURL())] }).catch(console.error);
        }
    },
};

function createEmbed(member, channel, action, iconURL) {
    return new EmbedBuilder()
        .setColor('#fff700')
        .setTitle(action)
        .setDescription(`**Kullanıcı:**\n<@${member.id}> - ${member.id}\n**Kanal:**\n> ${channel ? `<#${channel.id}> (${channel.id})` : 'Bilinmiyor'}\n**Kanal Üyeleri:**\n${getMemberList(channel)}`)
        .setThumbnail(iconURL)
        .setFooter({ text: Lyuex.reklam.Lyuexisim, iconURL: Lyuex.reklam.Lyuexprofile })
        .setTimestamp();
}

function getMemberList(channel) {
    if (!channel || !channel.members) return 'Kanalda başka üye bulunmuyor.';
    let list = '';
    channel.members.forEach(member => { list += `\n> <@${member.id}> - ${member.id}`; });
    return list || 'Kanalda başka üye bulunmuyor.';
}