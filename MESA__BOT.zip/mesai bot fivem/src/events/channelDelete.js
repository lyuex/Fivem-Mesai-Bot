﻿const { EmbedBuilder, Events, AuditLogEvent } = require('discord.js');
const Lyuex = require('../../lyuex.json');
const { catchError } = require('../functions/hatamesajı');

module.exports = {
   name: Events.ChannelDelete,
    async execute(channel, client) {
            if (client) {
            const Lyuexinchannellogkanali = client.channels.cache.find(channel => channel.name === 'channel_log');
            if (!Lyuexinchannellogkanali) {
                const LyuexinKullanici = await client.users.fetch(Lyuex.reklam.Lyuexdcid);
                if (LyuexinKullanici) {
                    LyuexinKullanici.send("Kanalı bulamadım.");
                }
                return;
            }
            channel.guild.fetchAuditLogs({type: AuditLogEvent.ChannelDelete }).then(audit => {
                const oc = audit.entries.first();
                const Lyuexinchannellogembedi = new EmbedBuilder()
                .setColor('#00ff1a')
                .setTitle('Kanal Silindi!')
                .setDescription(`Kişi:\n > <@${oc.executor.id}> - (${oc.executor.id}) \n\n Kanal: \n > **${channel.name}** - ${channel.id} - <#${channel.id}>`) 
                .setThumbnail(channel.guild.iconURL({ dynamic: true }))
                .setFooter({ text: Lyuex.reklam.Lyuexisim, iconURL: Lyuex.reklam.Lyuexprofile })
                .setTimestamp();
                try {
                    if (Lyuexinchannellogkanali) {
                        Lyuexinchannellogkanali.send({ embeds: [Lyuexinchannellogembedi] });
                    }
                }catch (error) {
                    catchError(client, 'channelDelete.js', error.message)
               }
           })
        }
    }
}
