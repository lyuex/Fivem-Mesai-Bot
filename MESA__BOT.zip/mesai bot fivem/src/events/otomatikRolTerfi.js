// ═══════════════════════════════════════════════
//  Otomatik Rol Terfi Sistemi
// ═══════════════════════════════════════════════

const { Events, EmbedBuilder } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const Lyuex = require('../../lyuex.json');
const { THEME } = require('../utils/theme');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        if (!Lyuex.otomatikTerfi?.aktif) return;
        // Her 6 saatte kontrol
        setInterval(() => checkPromotions(client), 6 * 60 * 60 * 1000);
        setTimeout(() => checkPromotions(client), 30000); // İlk kontrol 30sn sonra
        console.log('[OtoTerfi] Otomatik terfi sistemi aktif.');
    },
};

async function checkPromotions(client) {
    try {
        const guild = client.guilds.cache.get(Lyuex.botSettings.ServerID);
        if (!guild) return;

        const roller = Lyuex.otomatikTerfi?.roller;
        if (!roller || !Array.isArray(roller) || roller.length === 0) return;

        const allMesai = mesaiDb.toJSON() || {};
        let terfiSayisi = 0;

        for (const [userId, data] of Object.entries(allMesai)) {
            if (!data.mesailer) continue;

            // Toplam mesai süresini hesapla (saat)
            let toplamDakika = 0;
            for (const m of Object.values(data.mesailer)) {
                if (m['giriş'] && m['çıkış']) {
                    const diff = moment(m['çıkış']).diff(moment(m['giriş']), 'minutes');
                    if (diff > 0) toplamDakika += diff;
                }
            }
            const toplamSaat = toplamDakika / 60;

            // Roller kontrol et (en yüksekten en düşüğe)
            const sortedRoller = [...roller].sort((a, b) => b.saat - a.saat);
            const member = guild.members.cache.get(userId);
            if (!member) continue;

            for (const kural of sortedRoller) {
                if (toplamSaat >= kural.saat) {
                    const rol = guild.roles.cache.get(kural.rol);
                    if (rol && !member.roles.cache.has(rol.id)) {
                        await member.roles.add(rol).catch(() => {});
                        terfiSayisi++;

                        // Log gönder
                        const logChannel = guild.channels.cache.find(ch => ch.name === 'lyuex_log');
                        if (logChannel) {
                            logChannel.send({
                                embeds: [new EmbedBuilder()
                                    .setColor(THEME.success)
                                    .setDescription(`🎖️ **Otomatik Terfi**\n${member} → ${rol}\nToplam mesai: **${Math.floor(toplamSaat)}** saat`)
                                    .setTimestamp()]
                            }).catch(() => {});
                        }
                    }
                    break; // En yüksek uygun rolü verdikten sonra dur
                }
            }
        }

        if (terfiSayisi > 0) console.log(`[OtoTerfi] ${terfiSayisi} kişi terfi etti.`);
    } catch (error) {
        console.error('[OtoTerfi] Hata:', error);
    }
}
