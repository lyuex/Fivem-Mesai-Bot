const { Collection, EmbedBuilder } = require('discord.js');
const fs = require('fs'); 
const commandFiles = fs.readdirSync('./src/commands/').filter(file => file.endsWith('.js'));
const commandMap = new Collection();

for (const file of commandFiles) {
    const command = require(`../commands/${file}`);
    if (command.data) {
        commandMap.set(command.data.name, command);
        console.log(`[Lyuex API] Yüklendi: ${command.data.name}`);
    } else {
        console.log(`Hata: ${file} dosyasında komut bilgileri eksik.`);
    }
}



module.exports = {
    commandMap: commandMap,
    handleCommand: async (interaction) => {
        if (!interaction.isCommand()) return;
        const { commandName } = interaction;
        const command = commandMap.get(commandName);
        try {
            if (command) {
                await command.execute(interaction);
            } else {
                await interaction.reply({ content: 'Bilinmeyen komut!', ephemeral: true });
            }
        } catch (error) {
            console.error(`[Lyuex API] Komut hatası (${commandName}):`, error);
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: 'Komut çalıştırılırken bir hata oluştu!', ephemeral: true }).catch(() => {});
            } else {
                await interaction.reply({ content: 'Komut çalıştırılırken bir hata oluştu!', ephemeral: true }).catch(() => {});
            }
        }
    }
};
