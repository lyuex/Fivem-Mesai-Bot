const fs = require('fs');

module.exports = (client) => {
    const eventFiles = fs.readdirSync('./src/events').filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        try {
            const event = require(`../events/${file}`);
            if (!event.name) {
                console.log(`[Lyuex API] Uyarı: ${file} dosyasında event adı eksik.`);
                continue;
            }
            if (event.once) {
                client.once(event.name, (...args) => {
                    event.execute(...args, client);
                });
            } else {
                client.on(event.name, (...args) => {
                    event.execute(...args, client);
                });
            }
            console.log(`[Lyuex API] Event yüklendi: ${event.name} (${file})`);
        } catch (error) {
            console.error(`[Lyuex API] ${file} yüklenirken hata:`, error.message);
        }
    }
};