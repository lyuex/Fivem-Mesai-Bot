﻿const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, PermissionFlagsBits, ActionRowBuilder } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('farm-mesaj')
        .setDescription('🌿 Farm yönetim menüsünü gönderir — Kullanıcı paneli.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'farm-mesaj', 30);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const farmEmbed = new EmbedBuilder()
            .setColor(THEME.emerald)
            .setAuthor({ name: `${interaction.guild.name} — Farm Yönetim Sistemi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('🌿 Farm Kayıt Paneli')
            .setDescription([
                ansiHeader('🌿  FARM YÖNETİM MENÜSÜ', '32'),
                '',
                config.farm.menuayarlari.mesaj,
                '',
                '📋 **Kullanılabilir İşlemler:**',
                '┣ 🔍 **Farm Kontrol** — Mevcut farmlarınızı kontrol edin',
                '┣ 🌿 **Ot Ekle** — Database\'e ot kaydı yapın',
                '┣ 💎 **Kokain Ekle** — Database\'e kokain kaydı yapın',
                '┣ 🧪 **Meth Ekle** — Database\'e meth kaydı yapın',
                '┣ 💰 **Karapara Ekle** — Database\'e karapara kaydı yapın',
                '┗ 🔄 **Sıfırla** — Seçiminizi sıfırlayın'
            ].join('\n'))
            .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 512 }))
            .setImage(config.mesai.ekip.photograph)
            .setFooter({ text: 'Lyuex Farm Sistemi • Tüm işlemler kayıt altındadır', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const farmMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('farm-olustur')
                .setPlaceholder('🌿 Farm işlemi seçiniz...')
                .addOptions([
                    { label: config.farm.menuayarlari.birseceneklabel, emoji: config.farm.menuayarlari.birsecenekemoji, description: config.farm.menuayarlari.birsecenekaciklama, value: 'farmkontrol' },
                    { label: config.farm.farmlar.Otlabel, emoji: config.farm.farmlar.otemoji, description: config.farm.farmlar.otaciklama, value: 'otekle' },
                    { label: config.farm.farmlar.kokainlabel, emoji: config.farm.farmlar.kokainemoji, description: config.farm.farmlar.kokainaciklama, value: 'kokainekle' },
                    { label: config.farm.farmlar.methlabel, emoji: config.farm.farmlar.methemoji, description: config.farm.farmlar.methaciklama, value: 'methekle' },
                    { label: config.farm.farmlar.karaparalabel, emoji: config.farm.farmlar.karaparaemoji, description: config.farm.farmlar.karaparaaciklama, value: 'karaparaekle' },
                    { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
                ])
        );

        await interaction.channel.send({ content: '||@everyone|| & ||@here||', embeds: [farmEmbed], components: [farmMenu] });

        await interaction.editReply({
            embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ Farm menüsü başarıyla gönderildi!\n📍 Kanal: <#${interaction.channel.id}>`)]
        });
    }
};
