const { SlashCommandBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('olay-raporu')
        .setDescription('📄 Detaylı olay raporu oluştur (modal form)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'olay-raporu', 15);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        const modal = new ModalBuilder()
            .setCustomId('olay-raporu-modal')
            .setTitle('📄 Olay Raporu Formu');

        const baslikInput = new TextInputBuilder()
            .setCustomId('olay-baslik')
            .setLabel('Olay Başlığı')
            .setPlaceholder('Örn: Banka Soygunu Müdahalesi')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(100);

        const bolgeInput = new TextInputBuilder()
            .setCustomId('olay-bolge')
            .setLabel('Olay Yeri / Bölge')
            .setPlaceholder('Örn: Fleeca Bank - Şehir Merkezi')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(100);

        const ilgililerInput = new TextInputBuilder()
            .setCustomId('olay-ilgililer')
            .setLabel('İlgili Kişiler / Şüpheliler')
            .setPlaceholder('İsimleri virgülle ayırın')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(200);

        const detayInput = new TextInputBuilder()
            .setCustomId('olay-detay')
            .setLabel('Olay Detayı')
            .setPlaceholder('Olayın ayrıntılı açıklamasını yazın...')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(2000);

        const sonucInput = new TextInputBuilder()
            .setCustomId('olay-sonuc')
            .setLabel('Sonuç / Alınan Aksiyonlar')
            .setPlaceholder('Tutuklama, serbest bırakma, kovalamaca, vb.')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000);

        modal.addComponents(
            new ActionRowBuilder().addComponents(baslikInput),
            new ActionRowBuilder().addComponents(bolgeInput),
            new ActionRowBuilder().addComponents(ilgililerInput),
            new ActionRowBuilder().addComponents(detayInput),
            new ActionRowBuilder().addComponents(sonucInput)
        );

        await interaction.showModal(modal);
    }
};
