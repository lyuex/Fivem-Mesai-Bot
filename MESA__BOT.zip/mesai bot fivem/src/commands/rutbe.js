const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rutbe')
        .setDescription('⭐ Personel rütbe yönetimi')
        .addSubcommand(sub =>
            sub.setName('ver')
                .setDescription('Personele rütbe ata')
                .addUserOption(opt => opt.setName('kisi').setDescription('Rütbe verilecek personel').setRequired(true))
                .addIntegerOption(opt => opt.setName('seviye').setDescription('Rütbe seviyesi (1-6)').setRequired(true).setMinValue(1).setMaxValue(6))
        )
        .addSubcommand(sub =>
            sub.setName('goruntule')
                .setDescription('Personelin rütbesini görüntüle')
                .addUserOption(opt => opt.setName('kisi').setDescription('Personel').setRequired(true))
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'rutbe', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        const sub = interaction.options.getSubcommand();

        if (sub === 'ver') {
            if (!checkPermission(interaction, config)) {
                return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
            }

            await interaction.deferReply();

            const user = interaction.options.getUser('kisi');
            const seviye = interaction.options.getInteger('seviye');
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            if (!member) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Kullanıcı bulunamadı.')] });

            const rutbeler = config.polis?.rutbeler || [];
            const yeniRutbe = rutbeler.find(r => r.seviye === seviye);
            if (!yeniRutbe) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Geçersiz rütbe seviyesi.')] });

            const personel = policeDb.get(`personel.${user.id}`) || {};
            const eskiSeviye = personel.rutbe || 0;
            const eskiRutbe = rutbeler.find(r => r.seviye === eskiSeviye);

            // Personel bilgilerini güncelle
            policeDb.set(`personel.${user.id}`, {
                ...personel,
                rutbe: seviye,
                rutbeGecmisi: [...(personel.rutbeGecmisi || []), {
                    eski: eskiSeviye,
                    yeni: seviye,
                    tarih: moment().format('YYYY-MM-DD HH:mm:ss'),
                    yetkili: interaction.user.id
                }]
            });

            // Rol değişimi — eski rütbe rolünü kaldır, yenisini ekle
            for (const r of rutbeler) {
                const role = interaction.guild.roles.cache.get(r.rol);
                if (role && member.roles.cache.has(role.id)) {
                    await member.roles.remove(role).catch(() => {});
                }
            }
            const yeniRol = interaction.guild.roles.cache.get(yeniRutbe.rol);
            if (yeniRol) await member.roles.add(yeniRol).catch(() => {});

            const terfimi = seviye > eskiSeviye;
            const emoji = terfimi ? '⬆️' : seviye < eskiSeviye ? '⬇️' : '↔️';

            const embed = new EmbedBuilder()
                .setColor(terfimi ? THEME.success : seviye < eskiSeviye ? THEME.danger : THEME.primary)
                .setAuthor({ name: `${interaction.guild.name} — Rütbe Değişikliği`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle(`${emoji} Rütbe ${terfimi ? 'Terfi' : seviye < eskiSeviye ? 'Düşürme' : 'Güncelleme'}`)
                .setDescription([
                    ansiHeader(`${emoji}  RÜTBE DEĞİŞİKLİĞİ`, terfimi ? '32' : '31'),
                    '',
                    `👤 **Personel:** <@${user.id}>`,
                    `👮 **Yetkili:** <@${interaction.user.id}>`,
                    '',
                    `📉 **Eski Rütbe:** \`${eskiRutbe ? eskiRutbe.isim : 'Atanmamış'}\` (Seviye ${eskiSeviye})`,
                    `📈 **Yeni Rütbe:** \`${yeniRutbe.isim}\` (Seviye ${seviye})`,
                ].join('\n'))
                .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ text: 'Lyuex Rütbe Sistemi' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            // DM bildirim
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor(terfimi ? THEME.success : THEME.danger)
                    .setTitle(`${emoji} Rütbe ${terfimi ? 'Terfi' : 'Değişikliği'}!`)
                    .setDescription(`${interaction.guild.name} sunucusunda rütbeniz değiştirildi.\n\n**Yeni Rütbe:** \`${yeniRutbe.isim}\``)
                    .setFooter({ text: interaction.guild.name })
                    .setTimestamp();
                await user.send({ embeds: [dmEmbed] });
            } catch {}

            // Log
            const logChannel = findLogChannel(interaction.guild, 'rutbe_log', 'polis_log', 'lyuex_log');
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(terfimi ? THEME.success : THEME.danger)
                    .setDescription(ansiHeader(`${emoji}  RÜTBE DEĞİŞİKLİĞİ`, terfimi ? '32' : '31'))
                    .addFields(
                        { name: '👤 Personel', value: `<@${user.id}>`, inline: true },
                        { name: '👮 Yetkili', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '📋 Değişiklik', value: `\`${eskiRutbe?.isim || 'Yok'}\` → \`${yeniRutbe.isim}\``, inline: true }
                    )
                    .setTimestamp();
                await logChannel.send({ embeds: [logEmbed] });
            }
        }

        if (sub === 'goruntule') {
            const user = interaction.options.getUser('kisi');
            const personel = policeDb.get(`personel.${user.id}`) || {};
            const rutbeler = config.polis?.rutbeler || [];
            const rutbe = rutbeler.find(r => r.seviye === (personel.rutbe || 0));
            const gecmis = (personel.rutbeGecmisi || []).slice(-5).reverse();

            const gecmisStr = gecmis.length > 0
                ? gecmis.map(g => {
                    const eskiR = rutbeler.find(r => r.seviye === g.eski);
                    const yeniR = rutbeler.find(r => r.seviye === g.yeni);
                    return `\`${eskiR?.isim || 'Yok'}\` → \`${yeniR?.isim || '?'}\` — ${moment(g.tarih).format('DD.MM.YYYY')}`;
                }).join('\n')
                : 'Geçmiş yok';

            const embed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle(`⭐ ${user.displayName} — Rütbe Bilgisi`)
                .addFields(
                    { name: 'Mevcut Rütbe', value: `\`${rutbe?.isim || 'Atanmamış'}\` (Seviye ${personel.rutbe || 0}/6)`, inline: true },
                    { name: 'Departman', value: `\`${personel.departman || 'Atanmamış'}\``, inline: true },
                    { name: 'Son 5 Rütbe Geçmişi', value: gecmisStr, inline: false }
                )
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    }
};
