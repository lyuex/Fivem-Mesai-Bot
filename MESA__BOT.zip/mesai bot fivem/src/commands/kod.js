const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { THEME, ansiHeader, checkCooldown } = require('../utils/theme');

const KODLAR = {
    'genel': {
        baslik: '📻 Genel Telsiz Kodları',
        emoji: '📻',
        kodlar: [
            ['10-1', 'Zayıf sinyal / Duyamıyorum'],
            ['10-4', 'Anlaşıldı / Tamam'],
            ['10-6', 'Meşgulüm, bekleyin'],
            ['10-7', 'Hizmet dışı (mola/bitiş)'],
            ['10-8', 'Hizmette / Aktif'],
            ['10-9', 'Tekrar edin'],
            ['10-10', 'Negatif / Hayır'],
            ['10-12', 'Konumu bekleyin'],
            ['10-20', 'Konumunuz nedir?'],
            ['10-23', 'Olay yerine varıldı'],
        ]
    },
    'acil': {
        baslik: '🚨 Acil Durum Kodları',
        emoji: '🚨',
        kodlar: [
            ['10-0', 'DİKKAT! Tüm birimler dinlesin'],
            ['10-13', 'Takviye istiyorum!'],
            ['10-33', 'ACİL DURUM — Tüm trafik kesilsin'],
            ['10-34', 'Tehlike ortadan kalktı'],
            ['10-71', 'Silahlı olay bildirimi'],
            ['10-78', 'Ambulans ihtiyacı'],
            ['10-99', 'ACİL! Memur tehlikede'],
            ['Code Blue', 'Bomba tehdidi'],
            ['Code Red', 'Ateşli silah aktif'],
            ['Signal 100', 'Tüm birimler bölgeye'],
        ]
    },
    'trafik': {
        baslik: '🚗 Trafik Kodları',
        emoji: '🚗',
        kodlar: [
            ['10-28', 'Araç plaka sorgulaması'],
            ['10-29', 'Çalıntı araç kaydı var'],
            ['10-38', 'Trafik durduruluyor'],
            ['10-50', 'Trafik kazası'],
            ['10-51', 'Çekici istenmekte'],
            ['10-55', 'Alkollü sürücü'],
            ['10-80', 'Takip devam ediyor'],
            ['10-81', 'Takip bitti / durdu'],
            ['Code 5', 'Araç durumu riskli'],
            ['Code 6', 'Araç kontrolü yapılıyor'],
        ]
    },
    'suc': {
        baslik: '⚖️ Suç & Olay Kodları',
        emoji: '⚖️',
        kodlar: [
            ['187', 'Cinayet'],
            ['211', 'Soygun / Gasp'],
            ['245', 'Silahlı saldırı'],
            ['261', 'Cinsel saldırı'],
            ['459', 'Hırsızlık (bina)'],
            ['484', 'Hırsızlık (kişi)'],
            ['487', 'Büyük hırsızlık'],
            ['503', 'Araç hırsızlığı'],
            ['647', 'Uyuşturucu kullanımı'],
            ['10-15', 'Şüpheli gözaltına alındı'],
        ]
    },
    'durum': {
        baslik: '📊 Durum Kodları',
        emoji: '📊',
        kodlar: [
            ['Code 1', 'Acil değil — normal seyir'],
            ['Code 2', 'Acil — sirensiz hızlı git'],
            ['Code 3', 'ACİL — sirenli ve ışıklı'],
            ['Code 4', 'Olay kontrol altında'],
            ['Code 5', 'Gözetleme / gizli takip'],
            ['Code 7', 'Yemek molası'],
            ['Code 8', 'İstasyon ihtiyacı var'],
            ['Code 10', 'SWAT gerekli'],
            ['Code 30', 'Hava desteği isteniyor'],
            ['Code 99', 'Tüm personel toplanma'],
        ]
    }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kod')
        .setDescription('📻 Polis telsiz kodları rehberi')
        .addStringOption(opt => opt.setName('kategori').setDescription('Kod kategorisi').setRequired(false)
            .addChoices(
                { name: '📻 Genel Kodlar', value: 'genel' },
                { name: '🚨 Acil Durum', value: 'acil' },
                { name: '🚗 Trafik', value: 'trafik' },
                { name: '⚖️ Suç & Olay', value: 'suc' },
                { name: '📊 Durum Kodları', value: 'durum' }
            ))
        .addStringOption(opt => opt.setName('ara').setDescription('Kod arama (ör: 10-4)').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'kod', 3);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const kategori = interaction.options.getString('kategori');
        const arama = interaction.options.getString('ara');

        // Arama modu
        if (arama) {
            const searchTerm = arama.toLowerCase();
            const sonuclar = [];

            for (const [katKey, katData] of Object.entries(KODLAR)) {
                for (const [kod, aciklama] of katData.kodlar) {
                    if (kod.toLowerCase().includes(searchTerm) || aciklama.toLowerCase().includes(searchTerm)) {
                        sonuclar.push({ kod, aciklama, kategori: katData.baslik });
                    }
                }
            }

            if (sonuclar.length === 0) {
                return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ **"${arama}"** için sonuç bulunamadı.`)] });
            }

            const satirlar = sonuclar.slice(0, 15).map(s => `\`${s.kod}\` — ${s.aciklama} *(${s.kategori})*`);

            const embed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle(`🔍 Kod Arama Sonuçları — "${arama}"`)
                .setDescription([
                    ansiHeader('🔍  KOD ARAMA', '35'),
                    '',
                    satirlar.join('\n'),
                    '',
                    `> 📊 **${sonuclar.length}** sonuç bulundu`
                ].join('\n'))
                .setFooter({ text: 'Lyuex Polis Kod Rehberi' })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed] });
        }

        // Belirli kategori
        if (kategori) {
            const kat = KODLAR[kategori];
            const satirlar = kat.kodlar.map(([kod, aciklama]) => `> \`${kod.padEnd(12)}\` — ${aciklama}`);

            const embed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle(`${kat.emoji} ${kat.baslik}`)
                .setDescription([
                    ansiHeader(`${kat.emoji}  ${kat.baslik.toUpperCase()}`, '35'),
                    '',
                    satirlar.join('\n'),
                ].join('\n'))
                .setFooter({ text: 'Lyuex Polis Kod Rehberi • /kod ara:ARANACAK' })
                .setTimestamp();

            return interaction.editReply({ embeds: [embed] });
        }

        // Tüm kategorileri göster (özet)
        const embed = new EmbedBuilder()
            .setColor(THEME.primary)
            .setAuthor({ name: `${interaction.guild.name} — Polis Telsiz Kodları`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('📻 Polis Telsiz Kod Rehberi')
            .setDescription(ansiHeader('📻  TELSİZ KOD REHBERİ', '35'));

        for (const [key, kat] of Object.entries(KODLAR)) {
            const ilkUc = kat.kodlar.slice(0, 3).map(([k, a]) => `\`${k}\` ${a}`).join('\n');
            embed.addFields({
                name: `${kat.emoji} ${kat.baslik}`,
                value: `${ilkUc}\n*...ve ${kat.kodlar.length - 3} kod daha*\n> \`/kod kategori:${key}\``,
                inline: true
            });
        }

        embed.setFooter({ text: 'Lyuex Polis Kod Rehberi • /kod kategori: veya /kod ara:' });
        embed.setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};
