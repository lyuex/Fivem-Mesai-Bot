const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, progressBar, formatDuration, errorEmbed } = require('../utils/theme');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('maas')
        .setDescription('💰 Maaş hesaplama — mesai saatine göre ödeme bilgisi')
        .addSubcommand(sub => sub
            .setName('hesapla')
            .setDescription('💰 Bir personelin maaşını hesapla')
            .addUserOption(opt => opt.setName('kisi').setDescription('Maaşını hesaplanacak kişi (boş = kendin)').setRequired(false))
            .addStringOption(opt => opt.setName('donem').setDescription('Hesaplama dönemi').setRequired(false)
                .addChoices(
                    { name: '📅 Bu Hafta', value: 'hafta' },
                    { name: '📅 Bu Ay', value: 'ay' },
                    { name: '📅 Tüm Zamanlar', value: 'toplam' }
                ))
        )
        .addSubcommand(sub => sub
            .setName('tablo')
            .setDescription('📊 Tüm personelin maaş tablosunu görüntüle')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'maas', 5);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        const sub = interaction.options.getSubcommand();
        if (sub === 'hesapla') return this.hesapla(interaction);
        if (sub === 'tablo') return this.tablo(interaction);
    },

    async hesapla(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetUser = interaction.options.getUser('kisi') || interaction.user;
        const donem = interaction.options.getString('donem') || 'ay';
        const maasConfig = config.polis?.maas || { saatlikUcret: 500, paraBirimi: '₺' };

        const mesaiData = mesaiDb.get(targetUser.id) || {};
        const mesailer = mesaiData.mesailer || {};
        const personel = policeDb.get(`personel.${targetUser.id}`) || {};
        const rutbeSeviye = personel.rutbe || 1;
        const rutbeObj = (config.polis?.rutbeler || []).find(r => r.seviye === rutbeSeviye);
        const rutbeIsim = rutbeObj ? rutbeObj.isim : 'Polis Memuru';

        // Rütbe çarpanı (her seviye %15 artış)
        const rutbeCarpani = 1 + ((rutbeSeviye - 1) * 0.15);

        // Dönem filtreleme
        const now = moment();
        let donemBaslangic;
        let donemAdi;

        if (donem === 'hafta') {
            donemBaslangic = moment().startOf('isoWeek');
            donemAdi = `Bu Hafta (${donemBaslangic.format('DD.MM')} - ${now.format('DD.MM')})`;
        } else if (donem === 'ay') {
            donemBaslangic = moment().startOf('month');
            donemAdi = `Bu Ay (${now.format('MMMM YYYY')})`;
        } else {
            donemBaslangic = moment(0);
            donemAdi = 'Tüm Zamanlar';
        }

        let toplamMs = 0;
        let mesaiSayisi = 0;

        for (const m of Object.values(mesailer)) {
            if (m['giriş'] && m['çıkış']) {
                const giris = moment(m['giriş']);
                const cikis = moment(m['çıkış']);
                if (giris.isAfter(donemBaslangic)) {
                    const diff = cikis.diff(giris);
                    if (diff > 0) {
                        toplamMs += diff;
                        mesaiSayisi++;
                    }
                }
            }
        }

        const toplamSaat = toplamMs / (1000 * 60 * 60);
        const tabanMaas = toplamSaat * maasConfig.saatlikUcret;
        const rutbeEk = tabanMaas * (rutbeCarpani - 1);
        const toplamMaas = tabanMaas * rutbeCarpani;

        // Tutuklama & ceza bonusu
        const tutuklamalar = (policeDb.get('tutuklamalar') || []).filter(t =>
            t.memurId === targetUser.id && moment(t.tarih).isAfter(donemBaslangic)
        );
        const cezalar = (policeDb.get('cezalar') || []).filter(c =>
            c.memurId === targetUser.id && moment(c.tarih).isAfter(donemBaslangic)
        );
        const devriyeler = (policeDb.get('devriyeler') || []).filter(d =>
            d.memurId === targetUser.id && moment(d.tarih).isAfter(donemBaslangic)
        );

        const tutuklamaBonus = tutuklamalar.length * 250;
        const cezaBonus = cezalar.length * 100;
        const devriyeBonus = devriyeler.length * 150;
        const aktiviteBonus = tutuklamaBonus + cezaBonus + devriyeBonus;
        const genelToplam = toplamMaas + aktiviteBonus;

        const embed = new EmbedBuilder()
            .setColor(THEME.gold)
            .setAuthor({ name: `${interaction.guild.name} — Maaş Hesaplama`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`💰 Maaş Bordrosu — ${targetUser.displayName}`)
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
            .setDescription([
                ansiHeader('💰  MAAŞ BORDROSU', '33'),
                '',
                `👤 **Personel:** <@${targetUser.id}>`,
                `👮 **Rütbe:** \`${rutbeIsim}\` (Seviye ${rutbeSeviye})`,
                `📅 **Dönem:** \`${donemAdi}\``,
            ].join('\n'))
            .addFields(
                { name: '⏱️ Mesai Bilgileri', value: [
                    `📊 Mesai Sayısı: \`${mesaiSayisi}\``,
                    `⏰ Toplam Süre: \`${toplamSaat.toFixed(1)} saat\``,
                    `💵 Saatlik Ücret: \`${maasConfig.saatlikUcret}${maasConfig.paraBirimi}\``,
                ].join('\n'), inline: true },
                { name: '📈 Aktivite', value: [
                    `🔒 Tutuklama: \`${tutuklamalar.length}\` (${tutuklamaBonus}${maasConfig.paraBirimi})`,
                    `📝 Ceza: \`${cezalar.length}\` (${cezaBonus}${maasConfig.paraBirimi})`,
                    `🚓 Devriye: \`${devriyeler.length}\` (${devriyeBonus}${maasConfig.paraBirimi})`,
                ].join('\n'), inline: true },
                { name: '💰 Maaş Dökümü', value: [
                    `> 💵 Taban Maaş: \`${Math.round(tabanMaas).toLocaleString('tr-TR')}${maasConfig.paraBirimi}\``,
                    `> ⭐ Rütbe Eki (x${rutbeCarpani.toFixed(2)}): \`+${Math.round(rutbeEk).toLocaleString('tr-TR')}${maasConfig.paraBirimi}\``,
                    `> 🎯 Aktivite Bonusu: \`+${aktiviteBonus.toLocaleString('tr-TR')}${maasConfig.paraBirimi}\``,
                    `> ───────────────────`,
                    `> 🏦 **TOPLAM: \`${Math.round(genelToplam).toLocaleString('tr-TR')}${maasConfig.paraBirimi}\`**`,
                ].join('\n'), inline: false }
            )
            .setFooter({ text: `Rütbe çarpanı: Seviye başına +%15 • Lyuex Maaş Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async tablo(interaction) {
        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [errorEmbed('Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const maasConfig = config.polis?.maas || { saatlikUcret: 500, paraBirimi: '₺' };
        const ayBaslangic = moment().startOf('month');
        const allKeys = mesaiDb.all() || [];

        const personelMaas = [];

        for (const entry of allKeys) {
            const userId = entry.ID;
            if (!userId || userId.length < 15) continue;

            const mesailer = entry.data?.mesailer || {};
            let toplamMs = 0;
            let mesaiSayisi = 0;

            for (const m of Object.values(mesailer)) {
                if (m['giriş'] && m['çıkış']) {
                    const giris = moment(m['giriş']);
                    const cikis = moment(m['çıkış']);
                    if (giris.isAfter(ayBaslangic)) {
                        const diff = cikis.diff(giris);
                        if (diff > 0) { toplamMs += diff; mesaiSayisi++; }
                    }
                }
            }

            if (toplamMs === 0) continue;

            const personel = policeDb.get(`personel.${userId}`) || {};
            const rutbeSeviye = personel.rutbe || 1;
            const rutbeCarpani = 1 + ((rutbeSeviye - 1) * 0.15);
            const saat = toplamMs / (1000 * 60 * 60);
            const maas = Math.round(saat * maasConfig.saatlikUcret * rutbeCarpani);

            personelMaas.push({ userId, saat, mesaiSayisi, rutbeSeviye, maas });
        }

        personelMaas.sort((a, b) => b.maas - a.maas);
        const top15 = personelMaas.slice(0, 15);
        const toplamOdeme = personelMaas.reduce((t, p) => t + p.maas, 0);
        const medals = ['🥇', '🥈', '🥉'];

        const satirlar = top15.map((p, i) => {
            const medal = medals[i] || `\`${i + 1}.\``;
            return `${medal} <@${p.userId}> — \`${p.saat.toFixed(1)}s\` • \`${p.mesaiSayisi} mesai\` • **${p.maas.toLocaleString('tr-TR')}${maasConfig.paraBirimi}**`;
        });

        const embed = new EmbedBuilder()
            .setColor(THEME.gold)
            .setAuthor({ name: `${interaction.guild.name} — Maaş Tablosu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`💰 Aylık Maaş Tablosu — ${moment().format('MMMM YYYY')}`)
            .setDescription([
                ansiHeader('💰  MAAŞ TABLOSU', '33'),
                '',
                satirlar.join('\n') || '`Bu ay mesai kaydı bulunamadı.`',
                '',
                `> 💳 **Toplam Ödeme:** \`${toplamOdeme.toLocaleString('tr-TR')}${maasConfig.paraBirimi}\``,
                `> 👥 **Personel Sayısı:** \`${personelMaas.length}\``
            ].join('\n'))
            .setFooter({ text: `Bu ay verisi • Lyuex Maaş Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};
