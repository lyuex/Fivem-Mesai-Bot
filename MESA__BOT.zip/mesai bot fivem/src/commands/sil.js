﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel, progressBar } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sil')
        .setDescription('🗑️ Gelişmiş mesaj silme sistemi — Onay mekanizması & detaylı log.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addIntegerOption(opt => opt.setName('sayı').setDescription('Silinecek mesaj sayısı (1-100)').setMinValue(1).setMaxValue(100))
        .addUserOption(opt => opt.setName('kullanici').setDescription('Sadece bu kullanıcının mesajlarını sil (opsiyonel)'))
        .addStringOption(opt => opt.setName('filtre').setDescription('Mesaj filtresi').addChoices(
            { name: '🤖 Bot Mesajları', value: 'bot' },
            { name: '📎 Eklentili Mesajlar', value: 'attachment' },
            { name: '🔗 Linkli Mesajlar', value: 'link' }
        )),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'sil', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok!')], ephemeral: true });
        }

        let amount = interaction.options.getInteger('sayı') || 10;
        const hedefKullanici = interaction.options.getUser('kullanici');
        const filtre = interaction.options.getString('filtre');

        await interaction.deferReply({ ephemeral: true });

        try {
            let fetched = await interaction.channel.messages.fetch({ limit: amount });

            if (hedefKullanici) fetched = fetched.filter(m => m.author.id === hedefKullanici.id);
            if (filtre === 'bot') fetched = fetched.filter(m => m.author.bot);
            if (filtre === 'attachment') fetched = fetched.filter(m => m.attachments.size > 0);
            if (filtre === 'link') fetched = fetched.filter(m => /https?:\/\//.test(m.content));

            const ikiHaftaÖnce = Date.now() - 14 * 24 * 60 * 60 * 1000;
            fetched = fetched.filter(m => m.createdTimestamp > ikiHaftaÖnce);

            if (fetched.size === 0) {
                return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('⚠️ Silinecek mesaj bulunamadı.')] });
            }

            // 50'den fazla mesaj silme onayı
            if (fetched.size > 50) {
                const confirmEmbed = new EmbedBuilder()
                    .setColor(THEME.warning)
                    .setTitle('⚠️ Toplu Silme Onayı')
                    .setDescription(`**${fetched.size}** mesaj silinmek üzere.\nBu işlem geri alınamaz. Devam etmek istiyor musunuz?`);

                const confirmRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('sil_onayla').setLabel(`${fetched.size} Mesaj Sil`).setEmoji('🗑️').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('sil_iptal').setLabel('İptal').setEmoji('❌').setStyle(ButtonStyle.Secondary)
                );

                await interaction.editReply({ embeds: [confirmEmbed], components: [confirmRow] });

                try {
                    const btn = await interaction.channel.awaitMessageComponent({ filter: i => i.user.id === interaction.user.id && ['sil_onayla', 'sil_iptal'].includes(i.customId), time: 15_000 });
                    await btn.deferUpdate();
                    if (btn.customId === 'sil_iptal') {
                        return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.dark).setDescription('❌ Silme işlemi iptal edildi.')], components: [] });
                    }
                } catch {
                    return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.dark).setDescription('⏰ Onay süresi doldu, işlem iptal edildi.')], components: [] });
                }
            }

            const silinen = await interaction.channel.bulkDelete(fetched, true);

            const sonuçEmbed = new EmbedBuilder()
                .setColor(THEME.success)
                .setTitle('🗑️ Mesajlar Başarıyla Silindi')
                .setDescription([
                    ansiHeader('🗑️  MESAJ SİLME TAMAMLANDI', '32'),
                    '',
                    `📊 **Silme Detayları:**`,
                    `┣ 🗑️ Silinen: **${silinen.size}** mesaj`,
                    `┣ 📍 Kanal: <#${interaction.channel.id}>`,
                    hedefKullanici ? `┣ 👤 Filtre: <@${hedefKullanici.id}>` : '',
                    filtre ? `┣ 🔍 Tür Filtresi: \`${filtre}\`` : '',
                    `┗ 👮 Yetkili: <@${interaction.user.id}>`
                ].filter(Boolean).join('\n'))
                .setFooter({ text: 'Lyuex Mesaj Yönetimi' })
                .setTimestamp();

            await interaction.editReply({ embeds: [sonuçEmbed], components: [] });

            // Log
            const logChannel = findLogChannel(interaction.guild, 'message_log', 'lyuex_log');
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(THEME.danger)
                    .setAuthor({ name: `${interaction.guild.name} — Toplu Mesaj Silme`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setDescription(ansiHeader('🗑️  TOPLU MESAJ SİLME', '31'))
                    .addFields(
                        { name: '👮 Yetkili', value: `> <@${interaction.user.id}>`, inline: true },
                        { name: '📍 Kanal', value: `> <#${interaction.channel.id}>`, inline: true },
                        { name: '🗑️ Silinen', value: `> \`${silinen.size}\` mesaj`, inline: true }
                    )
                    .setFooter({ text: 'Lyuex Mesaj Silme Sistemi' })
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Mesaj silme hatası:', error);
            await interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ Mesaj silme hatası: \`${error.message}\``)] });
        }
    }
};

