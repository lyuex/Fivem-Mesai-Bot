const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, progressBar, checkCooldown, checkPermission } = require('../utils/theme');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const farmDb = new JsonDatabase({ databasePath: "./src/database/farmdb.json" });
const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dashboard')
        .setDescription('📊 Gerçek zamanlı sunucu dashboard — tüm veriler tek panelde')
        .addStringOption(opt => opt.setName('goruntule').setDescription('Dashboard bölümü').setRequired(false)
            .addChoices(
                { name: '📊 Genel Özet', value: 'genel' },
                { name: '⏰ Mesai İstatistikleri', value: 'mesai' },
                { name: '🌿 Farm İstatistikleri', value: 'farm' },
                { name: '👮 Polis İstatistikleri', value: 'polis' }
            ))
        .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'dashboard', 5);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const section = interaction.options.getString('goruntule') || 'genel';
        const guild = interaction.guild;

        if (section === 'genel') {
            const embeds = await this.buildGenelDashboard(guild, interaction.client);
            const row = this.buildNavRow('genel');
            const reply = await interaction.editReply({ embeds, components: [row] });
            this.setupCollector(interaction, reply);
        } else if (section === 'mesai') {
            const embed = this.buildMesaiDashboard(guild);
            const row = this.buildNavRow('mesai');
            const reply = await interaction.editReply({ embeds: [embed], components: [row] });
            this.setupCollector(interaction, reply);
        } else if (section === 'farm') {
            const embed = this.buildFarmDashboard(guild);
            const row = this.buildNavRow('farm');
            const reply = await interaction.editReply({ embeds: [embed], components: [row] });
            this.setupCollector(interaction, reply);
        } else if (section === 'polis') {
            const embeds = this.buildPolisDashboard(guild);
            const row = this.buildNavRow('polis');
            const reply = await interaction.editReply({ embeds, components: [row] });
            this.setupCollector(interaction, reply);
        }
    },

    buildNavRow(active) {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('dash_genel').setLabel('📊 Genel').setStyle(active === 'genel' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dash_mesai').setLabel('⏰ Mesai').setStyle(active === 'mesai' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dash_farm').setLabel('🌿 Farm').setStyle(active === 'farm' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dash_polis').setLabel('👮 Polis').setStyle(active === 'polis' ? ButtonStyle.Primary : ButtonStyle.Secondary),
            new ButtonBuilder().setLabel('🌐 Web Panel').setStyle(ButtonStyle.Link).setURL('http://localhost:8080')
        );
    },

    setupCollector(interaction, reply) {
        const collector = reply.createMessageComponentCollector({ time: 180_000 });
        collector.on('collect', async (btn) => {
            if (btn.user.id !== interaction.user.id) return btn.reply({ content: '❌ Bu panel size ait değil.', ephemeral: true });
            await btn.deferUpdate();

            const section = btn.customId.replace('dash_', '');
            const row = this.buildNavRow(section);

            if (section === 'genel') {
                const embeds = await this.buildGenelDashboard(interaction.guild, interaction.client);
                await interaction.editReply({ embeds, components: [row] });
            } else if (section === 'mesai') {
                const embed = this.buildMesaiDashboard(interaction.guild);
                await interaction.editReply({ embeds: [embed], components: [row] });
            } else if (section === 'farm') {
                const embed = this.buildFarmDashboard(interaction.guild);
                await interaction.editReply({ embeds: [embed], components: [row] });
            } else if (section === 'polis') {
                const embeds = this.buildPolisDashboard(interaction.guild);
                await interaction.editReply({ embeds, components: [row] });
            }
        });
        collector.on('end', () => {
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('dash_x1').setLabel('📊 Genel').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('dash_x2').setLabel('⏰ Mesai').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('dash_x3').setLabel('🌿 Farm').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('dash_x4').setLabel('👮 Polis').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setLabel('🌐 Web Panel').setStyle(ButtonStyle.Link).setURL('http://localhost:8080')
            );
            interaction.editReply({ components: [row] }).catch(() => {});
        });
    },

    async buildGenelDashboard(guild, client) {
        // ── Mesai verileri ──
        const mesaiRaw = mesaiDb.toJSON() || {};
        let mesaiKullanici = 0, aktivMesai = 0, toplamMesaiMs = 0, toplamMesaiGiris = 0;
        for (const [userId, userData] of Object.entries(mesaiRaw)) {
            if (userId.length < 15) continue;
            mesaiKullanici++;
            if (userData.status === 'in') aktivMesai++;
            if (userData.mesailer) {
                for (const m of Object.values(userData.mesailer)) {
                    toplamMesaiGiris++;
                    if (m['giriş'] && m['çıkış']) {
                        const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                        if (diff > 0) toplamMesaiMs += diff;
                    }
                }
            }
        }
        const toplamMesaiSaat = Math.floor(toplamMesaiMs / 3600000);

        // ── Farm verileri ──
        const farmData = farmDb.get('farm') || {};
        let farmKullanici = 0, toplamOt = 0, toplamKokain = 0, toplamMeth = 0, toplamKarapara = 0;
        for (const u of Object.values(farmData)) {
            farmKullanici++;
            toplamOt += u.ot || 0;
            toplamKokain += u.kokain || 0;
            toplamMeth += u.meth || 0;
            toplamKarapara += u.karapara || 0;
        }
        const toplamFarm = toplamOt + toplamKokain + toplamMeth + toplamKarapara;

        // ── Polis verileri ──
        const personel = policeDb.get('personel') || {};
        const tutuklamalar = policeDb.get('tutuklamalar') || [];
        const cezalar = policeDb.get('cezalar') || [];
        const devriyeler = policeDb.get('devriyeler') || [];
        const egitimler = policeDb.get('egitimler') || [];
        const raporlar = policeDb.get('olayRaporlari') || [];
        const toplamCezaMiktar = cezalar.reduce((s, c) => s + (c.miktar || 0), 0);
        const paraBirimi = config.polis?.maas?.paraBirimi || '₺';

        // ── Bugünkü aktivite ──
        const bugun = moment().format('YYYY-MM-DD');
        const bugunTutuklama = tutuklamalar.filter(t => t.tarih?.startsWith(bugun)).length;
        const bugunCeza = cezalar.filter(c => c.tarih?.startsWith(bugun)).length;
        const bugunDevriye = devriyeler.filter(d => d.tarih?.startsWith(bugun)).length;

        // Main embed
        const mainEmbed = new EmbedBuilder()
            .setColor(THEME.primary)
            .setAuthor({ name: `${guild.name} — Canlı Dashboard`, iconURL: guild.iconURL({ dynamic: true }) })
            .setTitle('📊 Sunucu Dashboard')
            .setDescription([
                ansiHeader('📊  CANLI DASHBOARD', '36'),
                '',
                `🏠 **Sunucu:** \`${guild.name}\``,
                `👥 **Üye:** \`${guild.memberCount}\` • **Kanal:** \`${guild.channels.cache.size}\``,
                `🤖 **Bot Ping:** \`${client.ws.ping}ms\` • **Durum:** ${client.ws.status === 0 ? '🟢 Online' : '🔴 Offline'}`,
            ].join('\n'))
            .addFields(
                { name: '⏰ Mesai Sistemi', value: [
                    `👥 Personel: **${mesaiKullanici}**`,
                    `🟢 Aktif Mesai: **${aktivMesai}**`,
                    `📋 Toplam Giriş: **${toplamMesaiGiris}**`,
                    `⏱️ Toplam Süre: **${toplamMesaiSaat}s**`,
                ].join('\n'), inline: true },
                { name: '🌿 Farm Sistemi', value: [
                    `👥 Kullanıcı: **${farmKullanici}**`,
                    `🌿 Ot: **${toplamOt}** • 💊 Kokain: **${toplamKokain}**`,
                    `🧪 Meth: **${toplamMeth}** • 💰 Karapara: **${toplamKarapara}**`,
                    `📦 Toplam: **${toplamFarm}**`,
                ].join('\n'), inline: true },
                { name: '👮 Polis Sistemi', value: [
                    `👮 Personel: **${Object.keys(personel).length}**`,
                    `🚔 Tutuklama: **${tutuklamalar.length}** • 📝 Ceza: **${cezalar.length}**`,
                    `🚓 Devriye: **${devriyeler.length}** • 📚 Eğitim: **${egitimler.length}**`,
                    `💰 Toplam Ceza: **${toplamCezaMiktar.toLocaleString('tr-TR')}${paraBirimi}**`,
                ].join('\n'), inline: false },
                { name: '📅 Bugünkü Aktivite', value: [
                    `🚔 Tutuklama: **${bugunTutuklama}** • 📝 Ceza: **${bugunCeza}** • 🚓 Devriye: **${bugunDevriye}**`,
                ].join('\n'), inline: false }
            )
            .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
            .setFooter({ text: `Son güncelleme: ${moment().format('DD.MM.YYYY HH:mm:ss')} • Lyuex Dashboard` })
            .setTimestamp();

        return [mainEmbed];
    },

    buildMesaiDashboard(guild) {
        const mesaiRaw = mesaiDb.toJSON() || {};

        // Top 10 mesai
        const users = [];
        for (const [userId, userData] of Object.entries(mesaiRaw)) {
            if (userId.length < 15) continue;
            let toplamMs = 0, mesaiSayi = 0;
            if (userData.mesailer) {
                for (const m of Object.values(userData.mesailer)) {
                    mesaiSayi++;
                    if (m['giriş'] && m['çıkış']) {
                        const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                        if (diff > 0) toplamMs += diff;
                    }
                }
            }
            if (toplamMs > 0) {
                users.push({ userId, toplamMs, mesaiSayi, status: userData.status || 'out' });
            }
        }
        users.sort((a, b) => b.toplamMs - a.toplamMs);

        const aktivler = users.filter(u => u.status === 'in');
        const toplamSaat = users.reduce((s, u) => s + u.toplamMs, 0) / 3600000;
        const maxMs = users[0]?.toplamMs || 1;
        const medals = ['🥇', '🥈', '🥉'];

        const top10Lines = users.slice(0, 10).map((u, i) => {
            const saat = (u.toplamMs / 3600000).toFixed(1);
            const bar = progressBar(u.toplamMs, maxMs, 10);
            const medal = medals[i] || `\`${i + 1}.\``;
            const durum = u.status === 'in' ? '🟢' : '⚫';
            return `${medal} ${durum} <@${u.userId}> — **${saat}s** • ${u.mesaiSayi} giriş\n> \`${bar}\``;
        });

        const aktivLines = aktivler.slice(0, 5).map(u => `🟢 <@${u.userId}>`);

        return new EmbedBuilder()
            .setColor(THEME.cyan)
            .setAuthor({ name: `${guild.name} — Mesai Dashboard`, iconURL: guild.iconURL({ dynamic: true }) })
            .setTitle('⏰ Mesai İstatistikleri')
            .setDescription([
                ansiHeader('⏰  MESAİ DASHBOARD', '36'),
                '',
                `👥 **Toplam Personel:** \`${users.length}\` • 🟢 **Aktif:** \`${aktivler.length}\` • ⏱️ **Toplam:** \`${toplamSaat.toFixed(0)}s\``,
            ].join('\n'))
            .addFields(
                { name: '🏆 En Çok Mesai (Top 10)', value: top10Lines.join('\n') || '`Veri yok`', inline: false },
                { name: '🟢 Şu Anda Mesaide', value: aktivLines.join(' • ') || '`Kimse mesaide değil`', inline: false }
            )
            .setFooter({ text: `${moment().format('DD.MM.YYYY HH:mm')} • Lyuex Mesai Dashboard` })
            .setTimestamp();
    },

    buildFarmDashboard(guild) {
        const farmData = farmDb.get('farm') || {};

        const users = [];
        let toplamOt = 0, toplamKokain = 0, toplamMeth = 0, toplamKarapara = 0;
        for (const [userId, data] of Object.entries(farmData)) {
            const ot = data.ot || 0, kokain = data.kokain || 0, meth = data.meth || 0, karapara = data.karapara || 0;
            toplamOt += ot; toplamKokain += kokain; toplamMeth += meth; toplamKarapara += karapara;
            users.push({ userId, ot, kokain, meth, karapara, toplam: ot + kokain + meth + karapara });
        }
        users.sort((a, b) => b.toplam - a.toplam);

        const toplamGenel = toplamOt + toplamKokain + toplamMeth + toplamKarapara;
        const maxToplam = users[0]?.toplam || 1;
        const medals = ['🥇', '🥈', '🥉'];

        const top10Lines = users.slice(0, 10).map((u, i) => {
            const medal = medals[i] || `\`${i + 1}.\``;
            const bar = progressBar(u.toplam, maxToplam, 10);
            return `${medal} <@${u.userId}> — **${u.toplam}** toplam\n> 🌿 ${u.ot} • 💊 ${u.kokain} • 🧪 ${u.meth} • 💰 ${u.karapara}\n> \`${bar}\``;
        });

        // Dağılım çubukları
        const maxTur = Math.max(toplamOt, toplamKokain, toplamMeth, toplamKarapara, 1);
        const dagılım = [
            `🌿 **Ot:** ${toplamOt} \`${progressBar(toplamOt, maxTur, 15)}\``,
            `💊 **Kokain:** ${toplamKokain} \`${progressBar(toplamKokain, maxTur, 15)}\``,
            `🧪 **Meth:** ${toplamMeth} \`${progressBar(toplamMeth, maxTur, 15)}\``,
            `💰 **Karapara:** ${toplamKarapara} \`${progressBar(toplamKarapara, maxTur, 15)}\``,
        ];

        return new EmbedBuilder()
            .setColor(THEME.emerald)
            .setAuthor({ name: `${guild.name} — Farm Dashboard`, iconURL: guild.iconURL({ dynamic: true }) })
            .setTitle('🌿 Farm İstatistikleri')
            .setDescription([
                ansiHeader('🌿  FARM DASHBOARD', '32'),
                '',
                `👥 **Toplam Kullanıcı:** \`${users.length}\` • 📦 **Toplam Farm:** \`${toplamGenel}\``,
            ].join('\n'))
            .addFields(
                { name: '📊 Tür Dağılımı', value: dagılım.join('\n'), inline: false },
                { name: '🏆 En Çok Farm (Top 10)', value: top10Lines.join('\n') || '`Veri yok`', inline: false }
            )
            .setFooter({ text: `${moment().format('DD.MM.YYYY HH:mm')} • Lyuex Farm Dashboard` })
            .setTimestamp();
    },

    buildPolisDashboard(guild) {
        const personelRaw = policeDb.get('personel') || {};
        const tutuklamalar = policeDb.get('tutuklamalar') || [];
        const cezalar = policeDb.get('cezalar') || [];
        const devriyeler = policeDb.get('devriyeler') || [];
        const egitimler = policeDb.get('egitimler') || [];
        const raporlar = policeDb.get('olayRaporlari') || [];
        const rutbeler = config.polis?.rutbeler || [];
        const departmanlar = config.polis?.departmanlar || [];
        const paraBirimi = config.polis?.maas?.paraBirimi || '₺';
        const toplamCezaMiktar = cezalar.reduce((s, c) => s + (c.miktar || 0), 0);

        // Rütbe dağılımı
        const rutbeDag = {};
        for (const p of Object.values(personelRaw)) {
            const r = rutbeler.find(rt => rt.seviye === (p.rutbe || 1));
            const isim = r?.isim || 'Polis Memuru';
            rutbeDag[isim] = (rutbeDag[isim] || 0) + 1;
        }
        const rutbeLines = Object.entries(rutbeDag).map(([isim, sayi]) => `> \`${isim}\`: **${sayi}** kişi`);

        // Departman dağılımı
        const depDag = {};
        for (const p of Object.values(personelRaw)) {
            const dep = p.departman || 'Atanmamış';
            depDag[dep] = (depDag[dep] || 0) + 1;
        }
        const depLines = Object.entries(depDag).map(([isim, sayi]) => {
            const d = departmanlar.find(dp => dp.isim === isim);
            return `> ${d?.emoji || '🛡️'} \`${isim}\`: **${sayi}** kişi`;
        });

        // Suç dağılımı (top 5)
        const sucDag = {};
        for (const t of tutuklamalar) {
            sucDag[t.suc] = (sucDag[t.suc] || 0) + 1;
        }
        const sucLines = Object.entries(sucDag).sort((a, b) => b[1] - a[1]).slice(0, 5)
            .map(([suc, sayi]) => `> \`${suc}\`: **${sayi}**`);

        // Top 5 memur
        const memurStats = {};
        for (const t of tutuklamalar) { memurStats[t.memurId] = memurStats[t.memurId] || { t: 0, c: 0, d: 0 }; memurStats[t.memurId].t++; }
        for (const c of cezalar) { memurStats[c.memurId] = memurStats[c.memurId] || { t: 0, c: 0, d: 0 }; memurStats[c.memurId].c++; }
        for (const d of devriyeler) { memurStats[d.memurId] = memurStats[d.memurId] || { t: 0, c: 0, d: 0 }; memurStats[d.memurId].d++; }

        const topMemurlar = Object.entries(memurStats)
            .map(([id, s]) => ({ id, toplam: s.t + s.c + s.d, t: s.t, c: s.c, d: s.d }))
            .sort((a, b) => b.toplam - a.toplam)
            .slice(0, 5);

        const medals = ['🥇', '🥈', '🥉'];
        const memurLines = topMemurlar.map((m, i) => {
            const medal = medals[i] || `\`${i + 1}.\``;
            return `${medal} <@${m.id}> — **${m.toplam}** işlem (🚔${m.t} 📝${m.c} 🚓${m.d})`;
        });

        // Son 7 gün
        const haftalik = [];
        for (let i = 6; i >= 0; i--) {
            const gun = moment().subtract(i, 'days').format('YYYY-MM-DD');
            const gunLabel = moment().subtract(i, 'days').format('DD.MM');
            const tCount = tutuklamalar.filter(t => t.tarih?.startsWith(gun)).length;
            const cCount = cezalar.filter(c => c.tarih?.startsWith(gun)).length;
            const dCount = devriyeler.filter(d => d.tarih?.startsWith(gun)).length;
            haftalik.push(`\`${gunLabel}\` — 🚔${tCount} 📝${cCount} 🚓${dCount}`);
        }

        const mainEmbed = new EmbedBuilder()
            .setColor(THEME.blue)
            .setAuthor({ name: `${guild.name} — Polis Dashboard`, iconURL: guild.iconURL({ dynamic: true }) })
            .setTitle('👮 Polis İstatistikleri')
            .setDescription([
                ansiHeader('👮  POLİS DASHBOARD', '34'),
                '',
                `👮 **Personel:** \`${Object.keys(personelRaw).length}\` • 🚔 **Tutuklama:** \`${tutuklamalar.length}\` • 📝 **Ceza:** \`${cezalar.length}\``,
                `🚓 **Devriye:** \`${devriyeler.length}\` • 📚 **Eğitim:** \`${egitimler.length}\` • 📄 **Rapor:** \`${raporlar.length}\``,
                `💰 **Toplam Ceza Tutarı:** \`${toplamCezaMiktar.toLocaleString('tr-TR')}${paraBirimi}\``,
            ].join('\n'))
            .addFields(
                { name: '⭐ Rütbe Dağılımı', value: rutbeLines.join('\n') || '`Veri yok`', inline: true },
                { name: '🏢 Departman Dağılımı', value: depLines.join('\n') || '`Veri yok`', inline: true },
                { name: '⚖️ En Çok Suç Türü (Top 5)', value: sucLines.join('\n') || '`Veri yok`', inline: false },
                { name: '🏆 En Aktif Memurlar', value: memurLines.join('\n') || '`Veri yok`', inline: false },
                { name: '📅 Son 7 Gün Aktivite', value: haftalik.join('\n'), inline: false }
            )
            .setFooter({ text: `${moment().format('DD.MM.YYYY HH:mm')} • Lyuex Polis Dashboard` })
            .setTimestamp();

        return [mainEmbed];
    }
};
