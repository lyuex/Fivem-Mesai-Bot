﻿const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, PermissionFlagsBits, ActionRowBuilder } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mesai-mesaj')
        .setDescription('⏰ Mesai menüsünü gönderir — Kullanıcı mesai yönetim paneli.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'mesai-mesaj', 30);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const mesaiEmbed = new EmbedBuilder()
            .setColor(THEME.blue)
            .setAuthor({ name: `${interaction.guild.name} — Mesai Yönetim Sistemi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('⏰ Mesai Kontrol Paneli')
            .setDescription([
                ansiHeader('⏰  MESAi KONTROL PANELi', '34'),
                '',
                config.mesai.menuayarlari.mesaj,
                '',
                '📋 **Kullanılabilir İşlemler:**',
                '┣ 🟢 **Mesaiye Gir** — Mesai kaydınızı başlatın',
                '┣ ✅ **Mesai Kontrol** — Aktif mesainizi kontrol edin',
                '┣ 🔴 **Mesai Çıkış** — Mesainizi sonlandırın',
                '┣ 📊 **Tüm Mesailerim** — Geçmiş mesai kayıtlarınız',
                '┗ 🔄 **Sıfırla** — Seçiminizi sıfırlayın',
                '',
                '> ℹ️ *Mesaiye girdikten 2 saat sonra kontrol bildirimi alacaksınız.*'
            ].join('\n'))
            .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 512 }))
            .setImage(config.mesai.ekip.photograph)
            .setFooter({ text: 'Lyuex Mesai Sistemi • Tüm mesailer kayıt altındadır', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const mesaiMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('mesai-olustur')
                .setPlaceholder('⏰ Mesai işlemi seçiniz...')
                .addOptions([
                    { label: config.mesai.menuayarlari.birseceneklabel, emoji: config.mesai.menuayarlari.birsecenekemoji, description: config.mesai.menuayarlari.birsecenekaciklama, value: 'mesaigir' },
                    { label: config.mesai.menuayarlari.ikiseceneklabel, emoji: config.mesai.menuayarlari.ikisecenekemoji, description: config.mesai.menuayarlari.ikisecenekaciklama, value: 'mesaicheck' },
                    { label: config.mesai.menuayarlari.ucseceneklabel, emoji: config.mesai.menuayarlari.ucsecenekemoji, description: config.mesai.menuayarlari.ucsecenekaciklama, value: 'mesaicik' },
                    { label: config.mesai.menuayarlari.dortseceneklabel, emoji: config.mesai.menuayarlari.dortsecenekemoji, description: config.mesai.menuayarlari.dortsecenekaciklama, value: 'mesailerim' },
                    { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
                ])
        );

        await interaction.channel.send({ content: '||@everyone|| & ||@here||', embeds: [mesaiEmbed], components: [mesaiMenu] });

        await interaction.editReply({
            embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ Mesai menüsü başarıyla gönderildi!\n📍 Kanal: <#${interaction.channel.id}>`)]
        });
    }
};
