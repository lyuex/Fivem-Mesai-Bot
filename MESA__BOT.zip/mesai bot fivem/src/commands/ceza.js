const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ceza')
        .setDescription('📝 Trafik/idari ceza kaydı oluştur')
        .addStringOption(opt => opt.setName('kisi').setDescription('Ceza kesilen kişi adı/ID').setRequired(true))
        .addIntegerOption(opt => opt.setName('miktar').setDescription('Ceza miktarı').setRequired(true).setMinValue(1).setMaxValue(999999))
        .addStringOption(opt => opt.setName('tur').setDescription('Ceza türü').setRequired(true)
            .addChoices(
                { name: '🚗 Hız İhlali', value: 'Hız İhlali' },
                { name: '🚦 Kırmızı Işık', value: 'Kırmızı Işık İhlali' },
                { name: '🅿️ Park İhlali', value: 'Park İhlali' },
                { name: '📜 Ehliyetsiz Araç Kullanma', value: 'Ehliyetsiz Araç Kullanma' },
                { name: '🍺 Alkollü Araç Kullanma', value: 'Alkollü Araç Kullanma' },
                { name: '🚧 Tehlikeli Sürüş', value: 'Tehlikeli Sürüş' },
                { name: '📋 Ruhsatsız Silah', value: 'Ruhsatsız Silah Taşıma' },
                { name: '🔊 Gürültü İhlali', value: 'Gürültü İhlali' },
                { name: '📋 Diğer', value: 'Diğer' }
            ))
        .addStringOption(opt => opt.setName('not').setDescription('Ek not').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'ceza', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        await interaction.deferReply();

        const kisi = interaction.options.getString('kisi');
        const miktar = interaction.options.getInteger('miktar');
        const tur = interaction.options.getString('tur');
        const not = interaction.options.getString('not') || 'Belirtilmedi';
        const paraBirimi = config.polis?.maas?.paraBirimi || '₺';

        const cezalar = policeDb.get('cezalar') || [];
        const kayitNo = cezalar.length + 1;

        const yeniKayit = {
            no: kayitNo,
            memurId: interaction.user.id,
            kisi,
            tur,
            miktar,
            not,
            tarih: moment().format('YYYY-MM-DD HH:mm:ss'),
            timestamp: Date.now()
        };

        cezalar.push(yeniKayit);
        policeDb.set('cezalar', cezalar);

        // Memur toplam ceza istatistiği
        const memurCezalar = cezalar.filter(c => c.memurId === interaction.user.id);
        const memurToplamTutar = memurCezalar.reduce((s, c) => s + c.miktar, 0);

        const embed = new EmbedBuilder()
            .setColor(THEME.orange)
            .setAuthor({ name: `${interaction.guild.name} — Ceza Kaydı`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`📝 Ceza #${kayitNo}`)
            .setDescription([
                ansiHeader('📝  CEZA TUTANAĞI', '33'),
                '',
                `👮 **Görevli Memur:** <@${interaction.user.id}>`,
                `👤 **Ceza Kesilen:** \`${kisi}\``,
                `📋 **Ceza Türü:** \`${tur}\``,
                `💰 **Miktar:** \`${miktar.toLocaleString('tr-TR')}${paraBirimi}\``,
                `📝 **Not:** ${not}`,
                `📅 **Tarih:** \`${moment().format('DD.MM.YYYY HH:mm')}\``,
            ].join('\n'))
            .addFields(
                { name: '📊 Memur Ceza İstatistikleri', value: `Toplam **${memurCezalar.length}** ceza — **${memurToplamTutar.toLocaleString('tr-TR')}${paraBirimi}** toplam tutar`, inline: false }
            )
            .setFooter({ text: `Kayıt No: #${kayitNo} • Lyuex Ceza Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        const logChannel = findLogChannel(interaction.guild, 'ceza_log', 'polis_log', 'lyuex_log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor(THEME.orange)
                .setAuthor({ name: 'Ceza Kaydı', iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setDescription(ansiHeader('📝  YENİ CEZA', '33'))
                .addFields(
                    { name: '👮 Memur', value: `<@${interaction.user.id}>`, inline: true },
                    { name: '👤 Kişi', value: `\`${kisi}\``, inline: true },
                    { name: '📋 Tür', value: `\`${tur}\``, inline: true },
                    { name: '💰 Miktar', value: `\`${miktar.toLocaleString('tr-TR')}${paraBirimi}\``, inline: true },
                    { name: '📝 Not', value: not, inline: false }
                )
                .setFooter({ text: `#${kayitNo}` })
                .setTimestamp();
            await logChannel.send({ embeds: [logEmbed] });
        }
    }
};
