const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { THEME, ansiHeader } = require('../utils/theme');

const CATEGORIES = {
    'mesai': {
        label: '⏰ Mesai Sistemi',
        emoji: '⏰',
        commands: ['mesai-mesaj', 'mesai-mesaj-yetkili'],
        desc: 'Mesai giriş/çıkış, kontrol ve yönetim'
    },
    'farm': {
        label: '🌿 Farm Sistemi',
        emoji: '🌿',
        commands: ['farm-mesaj', 'farm-yetkili-mesaj'],
        desc: 'Farm kayıt, kontrol ve yönetim'
    },
    'polis': {
        label: '👮 Polis Sistemi',
        emoji: '👮',
        commands: ['sicil', 'tutuklama', 'ceza', 'devriye', 'rutbe', 'kadro', 'departman', 'olay-raporu', 'egitim', 'maas', 'kod'],
        desc: 'Sicil, tutuklama, ceza, devriye, rütbe, eğitim, maaş'
    },
    'yonetim': {
        label: '⚙️ Yönetim',
        emoji: '⚙️',
        commands: ['sil', 'uyarı', 'isim', 'rolbilgi', 'mesaj', 'izin', 'ticket', 'reload'],
        desc: 'Mesaj silme, uyarı, isim, rol bilgi, izin'
    },
    'bilgi': {
        label: '📊 Bilgi & Araçlar',
        emoji: '📊',
        commands: ['yardim', 'bot', 'aktiflik', 'etkinlik', 'dashboard'],
        desc: 'Yardım, bot panel, aktiflik testi, dashboard'
    }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('yardim')
        .setDescription('📋 Tüm komutları kategorilere göre listeler')
        .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages),

    async execute(interaction) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const commands = interaction.client.commands;
        if (!commands || commands.size === 0) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Kayıtlı komut bulunamadı.')] });
        }

        // Ana embed — özet
        const categoryLines = [];
        const categorized = {};
        let otherCmds = [];

        for (const [name, cmd] of commands) {
            let placed = false;
            for (const [catKey, catData] of Object.entries(CATEGORIES)) {
                if (catData.commands.includes(name)) {
                    if (!categorized[catKey]) categorized[catKey] = [];
                    categorized[catKey].push(cmd);
                    placed = true;
                    break;
                }
            }
            if (!placed) otherCmds.push(cmd);
        }

        for (const [catKey, catData] of Object.entries(CATEGORIES)) {
            const count = (categorized[catKey] || []).length;
            if (count > 0) {
                categoryLines.push(`${catData.emoji} **${catData.label}** — \`${count}\` komut\n> ${catData.desc}`);
            }
        }
        if (otherCmds.length > 0) {
            categoryLines.push(`📁 **Diğer** — \`${otherCmds.length}\` komut`);
        }

        const mainEmbed = new EmbedBuilder()
            .setColor(THEME.primary)
            .setAuthor({ name: `${interaction.guild.name} — Komut Rehberi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('📋 Yardım Menüsü')
            .setDescription([
                ansiHeader('📋  KOMUT REHBERİ', '35'),
                '',
                categoryLines.join('\n\n'),
                '',
                `> 📊 Toplam **${commands.size}** komut yüklü`,
                '> Aşağıdaki menüden kategori seçerek detay görüntüleyin.'
            ].join('\n'))
            .setFooter({ text: 'Lyuex Yardım Sistemi • Kategori seçin ↓' })
            .setTimestamp();

        const options = [];
        for (const [catKey, catData] of Object.entries(CATEGORIES)) {
            if ((categorized[catKey] || []).length > 0) {
                options.push({ label: catData.label, value: catKey, emoji: catData.emoji, description: `${(categorized[catKey] || []).length} komut` });
            }
        }
        if (otherCmds.length > 0) {
            options.push({ label: 'Diğer', value: 'diger', emoji: '📁', description: `${otherCmds.length} komut` });
        }

        const menu = new StringSelectMenuBuilder()
            .setCustomId('yardim_menu')
            .setPlaceholder('📂 Kategori seçin...')
            .addOptions(options);

        const row = new ActionRowBuilder().addComponents(menu);
        const reply = await interaction.editReply({ embeds: [mainEmbed], components: [row] });

        const collector = reply.createMessageComponentCollector({ time: 120_000 });

        collector.on('collect', async (sel) => {
            if (sel.user.id !== interaction.user.id) return sel.reply({ content: '❌ Bu menü size ait değil.', flags: MessageFlags.Ephemeral });

            let cmds;
            let title;
            let emoji;

            if (sel.values[0] === 'diger') {
                cmds = otherCmds;
                title = 'Diğer Komutlar';
                emoji = '📁';
            } else {
                const catData = CATEGORIES[sel.values[0]];
                cmds = categorized[sel.values[0]] || [];
                title = catData.label;
                emoji = catData.emoji;
            }

            const lines = cmds.map(cmd => {
                const sub = cmd.data.options?.filter(o => o.toJSON?.().type === 1) || [];
                if (sub.length > 0) {
                    const subNames = sub.map(s => `\`${s.toJSON().name}\``).join(', ');
                    return `> **/${cmd.data.name}** — ${cmd.data.description}\n>   ↳ Alt komutlar: ${subNames}`;
                }
                return `> **/${cmd.data.name}** — ${cmd.data.description}`;
            });

            const catEmbed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle(`${emoji} ${title}`)
                .setDescription(lines.join('\n\n') || 'Bu kategoride komut yok.')
                .setFooter({ text: `${cmds.length} komut • Lyuex Yardım Sistemi` })
                .setTimestamp();

            await sel.update({ embeds: [catEmbed], components: [row] });
        });

        collector.on('end', () => {
            const disabledMenu = StringSelectMenuBuilder.from(menu).setDisabled(true);
            const disabledRow = new ActionRowBuilder().addComponents(disabledMenu);
            interaction.editReply({ components: [disabledRow] }).catch(() => {});
        });
    },
};
