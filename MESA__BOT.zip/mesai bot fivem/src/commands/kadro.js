const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });
const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kadro')
        .setDescription('📋 Tam personel kadro tablosu')
        .addStringOption(opt => opt.setName('filtre').setDescription('Filtreleme').setRequired(false)
            .addChoices(
                { name: '🟢 Sadece Mesaidekiler', value: 'mesaide' },
                { name: '📊 Rütbeye Göre', value: 'rutbe' },
                { name: '🏢 Departmana Göre', value: 'departman' }
            ))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'kadro', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const filtre = interaction.options.getString('filtre') || 'rutbe';
        const allPersonel = policeDb.get('personel') || {};
        const allMesai = mesaiDb.toJSON() || {};
        const rutbeler = config.polis?.rutbeler || [];
        const departmanlar = config.polis?.departmanlar || [];

        // Personel verilerini birleştir
        const kadroList = [];
        // Hem policeDb'den hem mesaiDb'den kullanıcıları topla
        const allUserIds = new Set([...Object.keys(allPersonel), ...Object.keys(allMesai)]);

        for (const userId of allUserIds) {
            const pData = allPersonel[userId] || {};
            const mData = allMesai[userId] || {};

            // Mesai süresi hesapla
            let toplamMs = 0;
            if (mData.mesailer) {
                for (const m of Object.values(mData.mesailer)) {
                    if (m['giriş'] && m['çıkış']) {
                        const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                        if (diff > 0) toplamMs += diff;
                    }
                }
            }

            kadroList.push({
                userId,
                rutbe: pData.rutbe || 1,
                departman: pData.departman || 'Genel Asayiş',
                mesaiDurum: mData.status === 'in',
                toplamSaat: Math.floor(toplamMs / 3600000),
                mesaiSayi: mData.mesailer ? Object.keys(mData.mesailer).length : 0
            });
        }

        if (kadroList.length === 0) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('ℹ️ Kayıtlı personel bulunamadı.')] });
        }

        // Filtreleme
        let filteredList = kadroList;
        if (filtre === 'mesaide') filteredList = kadroList.filter(p => p.mesaiDurum);

        // Sıralama
        filteredList.sort((a, b) => b.rutbe - a.rutbe || b.toplamSaat - a.toplamSaat);

        // Embed oluştur
        const embeds = [];

        if (filtre === 'departman') {
            // Departmana göre grupla
            const gruplar = {};
            for (const p of filteredList) {
                const dep = p.departman || 'Genel Asayiş';
                if (!gruplar[dep]) gruplar[dep] = [];
                gruplar[dep].push(p);
            }

            const desc = [];
            for (const [depName, members] of Object.entries(gruplar)) {
                const depObj = departmanlar.find(d => d.isim === depName);
                const emoji = depObj?.emoji || '🛡️';
                desc.push(`\n${emoji} **${depName}** (${members.length} kişi)`);
                for (const m of members.slice(0, 10)) {
                    const rutbeObj = rutbeler.find(r => r.seviye === m.rutbe);
                    const durum = m.mesaiDurum ? '🟢' : '⚫';
                    desc.push(`${durum} <@${m.userId}> — \`${rutbeObj?.isim || 'Memur'}\` — ${m.toplamSaat}s`);
                }
                if (members.length > 10) desc.push(`> ... ve ${members.length - 10} kişi daha`);
            }

            embeds.push(new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle('📋 Kadro Tablosu — Departmana Göre')
                .setDescription(desc.join('\n').slice(0, 4096))
                .setFooter({ text: `Toplam ${filteredList.length} personel` })
                .setTimestamp()
            );
        } else {
            // Rütbeye göre veya mesaide filtresi
            const lines = filteredList.slice(0, 25).map((p, i) => {
                const rutbeObj = rutbeler.find(r => r.seviye === p.rutbe);
                const depObj = departmanlar.find(d => d.isim === p.departman);
                const durum = p.mesaiDurum ? '🟢' : '⚫';
                return `${durum} **${i + 1}.** <@${p.userId}> — \`${rutbeObj?.isim || 'Memur'}\` — ${depObj?.emoji || '🛡️'} \`${p.departman}\` — ${p.toplamSaat}s mesai`;
            });

            const title = filtre === 'mesaide' ? '📋 Kadro — Aktif Mesaidekiler' : '📋 Kadro Tablosu — Rütbeye Göre';

            embeds.push(new EmbedBuilder()
                .setColor(THEME.primary)
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle(title)
                .setDescription([
                    ansiHeader('📋  KADRO TABLOSU', '36'),
                    '',
                    ...lines,
                    '',
                    filteredList.length > 25 ? `> ... ve ${filteredList.length - 25} kişi daha` : ''
                ].join('\n').slice(0, 4096))
                .addFields(
                    { name: '📊 Özet', value: `Toplam: **${filteredList.length}** personel | Mesaide: **${filteredList.filter(p => p.mesaiDurum).length}** kişi`, inline: false }
                )
                .setFooter({ text: 'Lyuex Kadro Sistemi' })
                .setTimestamp()
            );
        }

        await interaction.editReply({ embeds });
    }
};
