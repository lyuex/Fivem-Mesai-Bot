const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const path = require('path');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reload')
        .setDescription('Bir komutu veya tüm komutları yeniden yükle')
        .addStringOption(opt =>
            opt.setName('komut')
                .setDescription('Yeniden yüklenecek komut adı (boş = tümü)')
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        const komutAdi = interaction.options.getString('komut');

        if (komutAdi) {
            // Tek komut reload
            const cmd = interaction.client.commands.get(komutAdi);
            if (!cmd) {
                return interaction.reply({ content: `❌ \`${komutAdi}\` komutu bulunamadı.`, ephemeral: true });
            }

            const commandsPath = path.join(__dirname, '..', 'commands');
            const filePath = path.join(commandsPath, `${komutAdi}.js`);

            if (!fs.existsSync(filePath)) {
                return interaction.reply({ content: `❌ \`${komutAdi}.js\` dosyası bulunamadı.`, ephemeral: true });
            }

            delete require.cache[require.resolve(filePath)];
            const newCmd = require(filePath);
            interaction.client.commands.set(newCmd.data.name, newCmd);

            await interaction.reply({ content: `✅ \`/${komutAdi}\` komutu yeniden yüklendi.`, ephemeral: true });
        } else {
            // Tüm komutları reload
            const commandsPath = path.join(__dirname, '..', 'commands');
            const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
            let count = 0;

            for (const file of files) {
                const filePath = path.join(commandsPath, file);
                delete require.cache[require.resolve(filePath)];
                const newCmd = require(filePath);
                if (newCmd.data && newCmd.data.name) {
                    interaction.client.commands.set(newCmd.data.name, newCmd);
                    count++;
                }
            }

            await interaction.reply({ content: `✅ **${count}** komut yeniden yüklendi.`, ephemeral: true });
        }
    },
};
