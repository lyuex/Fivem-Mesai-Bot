﻿const {
    SlashCommandBuilder, ChannelType, PermissionFlagsBits,
    ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder,
    ButtonBuilder, ButtonStyle
} = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, progressBar, checkCooldown } = require('../utils/theme');

const LOG_CHANNELS = [
    { name: 'channel_log', emoji: '📂' },
    { name: 'sticker_log', emoji: '🏷️' },
    { name: 'emoji_log', emoji: '😀' },
    { name: 'guard_log', emoji: '🛡️' },
    { name: 'voice_log', emoji: '🔊' },
    { name: 'invite_log', emoji: '📨' },
    { name: 'role_log', emoji: '🎭' },
    { name: 'message_log', emoji: '💬' },
    { name: 'user_update_log', emoji: '👤' },
    { name: 'ticket_log', emoji: '🎫' },
    { name: 'ban_log', emoji: '🔨' },
    { name: 'whitelist_log', emoji: '📋' },
    { name: 'nick_log', emoji: '✏️' },
    { name: 'lyuex_log', emoji: '⚙️' }
];

const UYARI_ROLLERI = ['1x', '2x', '3x', '4x', '5x', '1 gün wl', '2 gün wl', '3 gün wl', '5 gün wl', '7 gün wl'];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot')
        .setDescription('⚙️ Bot yönetim paneli — Log kurulumu, rol oluşturma & sistem ayarları.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        if (interaction.user.id !== config.reklam.Lyuexdcid) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komut yalnızca bot sahibi tarafından kullanılabilir.')],
                ephemeral: true
            });
        }

        // ─── Ana Panel Embedi ───
        const panelEmbed = new EmbedBuilder()
            .setColor(THEME.primary)
            .setAuthor({ name: `${interaction.guild.name} — Bot Yönetim Paneli`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('⚙️ Sistem Yönetim Merkezi')
            .setDescription([
                ansiHeader('⚙  BOT YÖNETİM PANELİ', '36'),
                '> Aşağıdaki menüden yapmak istediğiniz işlemi seçin.',
                '',
                '📋 **Mevcut İşlemler:**',
                '┣ 🗂️ **Log Kanalları Kur** — Tüm log kanallarını otomatik oluşturur',
                '┣ 🗑️ **Log Kanalları Temizle** — Mevcut log kanallarını siler',
                '┣ 🎭 **Uyarı Rolleri Kur** — Uyarı sisteminin rollerini oluşturur',
                '┣ 📊 **Sunucu Bilgisi** — Detaylı sunucu istatistikleri',
                '┗ 🤖 **Bot Durumu** — Uptime, ping, RAM bilgisi'
            ].join('\n'))
            .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 512 }))
            .setFooter({ text: 'Lyuex Bot Yönetim Sistemi', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const menu = new StringSelectMenuBuilder()
            .setCustomId('bot_panel_menu')
            .setPlaceholder('🔧 İşlem seçiniz...')
            .addOptions([
                { label: 'Log Kanalları Kur', description: 'Tüm log kanallarını oluşturur', emoji: '🗂️', value: 'log_kur' },
                { label: 'Log Kanalları Temizle', description: 'Mevcut log kanallarını siler', emoji: '🗑️', value: 'log_temizle' },
                { label: 'Uyarı Rolleri Kur', description: 'Uyarı rollerini oluşturur', emoji: '🎭', value: 'uyari_kur' },
                { label: 'Sunucu İstatistikleri', description: 'Detaylı sunucu bilgisi', emoji: '📊', value: 'sunucu_bilgi' },
                { label: 'Bot Durumu', description: 'Uptime, ping, RAM kullanımı', emoji: '🤖', value: 'bot_durum' }
            ]);

        const menuRow = new ActionRowBuilder().addComponents(menu);

        const reply = await interaction.reply({ embeds: [panelEmbed], components: [menuRow], ephemeral: true, fetchReply: true });

        const collector = reply.createMessageComponentCollector({ time: 120_000 });

        collector.on('collect', async (sel) => {
            if (sel.user.id !== interaction.user.id) return sel.reply({ content: '❌ Bu panel size ait değil.', ephemeral: true });

            // ─── LOG KURULUMU ───
            if (sel.values?.[0] === 'log_kur') {
                await sel.deferUpdate();
                const progressEmbed = new EmbedBuilder()
                    .setColor(THEME.warning)
                    .setTitle('🗂️ Log Kanalları Kuruluyor...')
                    .setDescription('```\n⏳ İşlem devam ediyor...\n```');

                await interaction.editReply({ embeds: [progressEmbed], components: [] });

                try {
                    const category = await interaction.guild.channels.create({
                        name: '📋 Lyuex Logs',
                        type: ChannelType.GuildCategory,
                        permissionOverwrites: [{
                            id: interaction.guild.roles.everyone.id,
                            deny: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect]
                        }]
                    });

                    const created = [];
                    for (const ch of LOG_CHANNELS) {
                        await interaction.guild.channels.create({ name: ch.name, type: ChannelType.GuildText, parent: category.id });
                        created.push(`${ch.emoji} \`${ch.name}\``);
                    }

                    const doneEmbed = new EmbedBuilder()
                        .setColor(THEME.success)
                        .setTitle('✅ Log Kanalları Başarıyla Kuruldu!')
                        .setDescription([
                            '```ansi',
                            `\u001b[1;32m✓ ${created.length} kanal oluşturuldu!`,
                            '```',
                            '**Oluşturulan Kanallar:**',
                            created.join('\n'),
                            '',
                            `> 📁 Kategori: **📋 Lyuex Logs**`
                        ].join('\n'))
                        .setFooter({ text: 'Lyuex Bot Yönetim Sistemi' })
                        .setTimestamp();

                    await interaction.editReply({ embeds: [doneEmbed], components: [menuRow] });
                } catch (error) {
                    console.error('Log kurulum hatası:', error);
                    await interaction.editReply({
                        embeds: [new EmbedBuilder().setColor(THEME.danger).setTitle('❌ Hata').setDescription(`\`\`\`\n${error.message}\n\`\`\``)],
                        components: [menuRow]
                    });
                }
            }

            // ─── LOG TEMİZLEME ───
            if (sel.values?.[0] === 'log_temizle') {
                await sel.deferUpdate();

                const confirmEmbed = new EmbedBuilder()
                    .setColor(THEME.warning)
                    .setTitle('⚠️ Onay Gerekli')
                    .setDescription('Tüm Lyuex log kanalları ve kategorileri **kalıcı olarak silinecek**.\nDevam etmek istiyor musunuz?');

                const confirmRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('log_temizle_onayla').setLabel('Evet, Sil').setEmoji('🗑️').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('log_temizle_iptal').setLabel('İptal').setEmoji('❌').setStyle(ButtonStyle.Secondary)
                );

                await interaction.editReply({ embeds: [confirmEmbed], components: [confirmRow] });
                return; // Onay butonları ayrı collect'te yakalancak
            }

            // ─── LOG TEMİZLEME ONAYI ───
            if (sel.customId === 'log_temizle_onayla') {
                await sel.deferUpdate();
                try {
                    const categories = interaction.guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes('lyuex'));
                    if (categories.size === 0) {
                        return interaction.editReply({
                            embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('⚠️ Lyuex log kategorisi bulunamadı.')],
                            components: [menuRow]
                        });
                    }

                    let silinen = 0;
                    for (const [, cat] of categories) {
                        for (const [, ch] of cat.children.cache) { await ch.delete(); silinen++; }
                        await cat.delete(); silinen++;
                    }

                    await interaction.editReply({
                        embeds: [new EmbedBuilder().setColor(THEME.success).setTitle('🗑️ Log Kanalları Temizlendi').setDescription(`✅ **${silinen}** kanal/kategori başarıyla silindi.`).setTimestamp()],
                        components: [menuRow]
                    });
                } catch (error) {
                    console.error('Log temizleme hatası:', error);
                    await interaction.editReply({
                        embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ Hata: \`${error.message}\``)],
                        components: [menuRow]
                    });
                }
            }

            // ─── LOG TEMİZLEME İPTAL ───
            if (sel.customId === 'log_temizle_iptal') {
                await sel.deferUpdate();
                await interaction.editReply({ embeds: [panelEmbed], components: [menuRow] });
                return;
            }

            // ─── UYARI ROLLERİ ───
            if (sel.values?.[0] === 'uyari_kur') {
                await sel.deferUpdate();
                try {
                    const oluşturulan = [];
                    for (const rolAdi of UYARI_ROLLERI) {
                        const mevcut = interaction.guild.roles.cache.find(r => r.name === rolAdi);
                        if (!mevcut) {
                            await interaction.guild.roles.create({ name: rolAdi, color: '#ED4245' });
                            oluşturulan.push(`✅ \`${rolAdi}\``);
                        } else {
                            oluşturulan.push(`⏭️ \`${rolAdi}\` (zaten mevcut)`);
                        }
                    }

                    await interaction.editReply({
                        embeds: [new EmbedBuilder().setColor(THEME.success).setTitle('🎭 Uyarı Rolleri').setDescription(['✅ İşlem tamamlandı!', '', ...oluşturulan].join('\n')).setTimestamp()],
                        components: [menuRow]
                    });
                } catch (error) {
                    console.error('Rol oluşturma hatası:', error);
                    await interaction.editReply({
                        embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ Hata: \`${error.message}\``)],
                        components: [menuRow]
                    });
                }
            }

            // ─── SUNUCU BİLGİSİ ───
            if (sel.values?.[0] === 'sunucu_bilgi') {
                await sel.deferUpdate();
                const g = interaction.guild;
                const owner = await g.fetchOwner();
                const boostBar = progressBar(g.premiumSubscriptionCount, 14, 15);

                const bilgiEmbed = new EmbedBuilder()
                    .setColor(THEME.primary)
                    .setAuthor({ name: g.name, iconURL: g.iconURL({ dynamic: true }) })
                    .setTitle('📊 Sunucu İstatistikleri')
                    .setThumbnail(g.iconURL({ dynamic: true, size: 512 }))
                    .setDescription(ansiHeader('📊  SUNUCU BİLGİ PANELİ', '36'))
                    .addFields(
                        { name: '👑 Sunucu Sahibi', value: `> ${owner.user.tag}`, inline: true },
                        { name: '📅 Kuruluş Tarihi', value: `> <t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
                        { name: '🆔 Sunucu ID', value: `> \`${g.id}\``, inline: true },
                        { name: '👥 Üye Sayısı', value: `> \`${g.memberCount}\` kişi`, inline: true },
                        { name: '💬 Kanal Sayısı', value: `> \`${g.channels.cache.size}\` kanal`, inline: true },
                        { name: '🎭 Rol Sayısı', value: `> \`${g.roles.cache.size}\` rol`, inline: true },
                        { name: '🚀 Boost Seviyesi', value: `> Seviye **${g.premiumTier}** — \`${g.premiumSubscriptionCount}\` boost\n> \`${boostBar}\``, inline: false }
                    )
                    .setFooter({ text: 'Lyuex Bot Yönetim Sistemi' })
                    .setTimestamp();

                await interaction.editReply({ embeds: [bilgiEmbed], components: [menuRow] });
            }

            // ─── BOT DURUMU ───
            if (sel.values?.[0] === 'bot_durum') {
                await sel.deferUpdate();
                const uptime = process.uptime();
                const days = Math.floor(uptime / 86400);
                const hours = Math.floor((uptime % 86400) / 3600);
                const mins = Math.floor((uptime % 3600) / 60);
                const secs = Math.floor(uptime % 60);
                const uptimeStr = `${days}g ${hours}s ${mins}dk ${secs}sn`;

                const mem = process.memoryUsage();
                const rss = (mem.rss / 1024 / 1024).toFixed(1);
                const heap = (mem.heapUsed / 1024 / 1024).toFixed(1);
                const heapTotal = (mem.heapTotal / 1024 / 1024).toFixed(1);

                const ping = interaction.client.ws.ping;
                const guildCount = interaction.client.guilds.cache.size;
                const userCount = interaction.client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);

                const durumEmbed = new EmbedBuilder()
                    .setColor(THEME.primary)
                    .setTitle('🤖 Bot Durumu')
                    .setThumbnail(interaction.client.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .addFields(
                        { name: '⏱️ Uptime', value: `> \`${uptimeStr}\``, inline: true },
                        { name: '🏓 Ping', value: `> \`${ping}ms\``, inline: true },
                        { name: '🌐 Sunucu', value: `> \`${guildCount}\` sunucu — \`${userCount}\` kullanıcı`, inline: true },
                        { name: '💾 RAM (RSS)', value: `> \`${rss} MB\``, inline: true },
                        { name: '📦 Heap', value: `> \`${heap} / ${heapTotal} MB\``, inline: true },
                        { name: '🔧 Node.js', value: `> \`${process.version}\``, inline: true },
                    )
                    .setFooter({ text: 'Lyuex Bot Yönetim Sistemi' })
                    .setTimestamp();

                await interaction.editReply({ embeds: [durumEmbed], components: [menuRow] });
            }
        });

        collector.on('end', async () => {
            const disabledMenu = StringSelectMenuBuilder.from(menu).setDisabled(true);
            await interaction.editReply({ components: [new ActionRowBuilder().addComponents(disabledMenu)] }).catch(() => {});
        });
    }
};