﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('isim')
        .setDescription('✏️ Kullanıcı isim değiştirme sistemi — Detaylı log & bildirim.')
        .addUserOption(opt => opt.setName('kullanici').setDescription('İsmi değiştirilecek kullanıcı').setRequired(true))
        .addStringOption(opt => opt.setName('isim').setDescription('Yeni isim').setRequired(true))
        .addStringOption(opt => opt.setName('sebep').setDescription('İsim değişikliği sebebi (opsiyonel)'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'isim', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        const hedef = interaction.options.getMember('kullanici');
        const yeniIsim = interaction.options.getString('isim');
        const sebep = interaction.options.getString('sebep') || 'Belirtilmedi';

        if (!hedef) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Belirtilen kullanıcı sunucuda bulunamadı.')], ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });
        const eskiIsim = hedef.nickname || hedef.user.username;

        try {
            await hedef.setNickname(yeniIsim);

            const başarıEmbed = new EmbedBuilder()
                .setColor(THEME.success)
                .setTitle('✅ İsim Başarıyla Değiştirildi')
                .setDescription([
                    ansiHeader('✏️  İSİM DEĞİŞTİRİLDİ', '32'),
                    '',
                    `👤 **Kullanıcı:** <@${hedef.user.id}>`,
                    `📝 **Eski İsim:** \`${eskiIsim}\``,
                    `✏️ **Yeni İsim:** \`${yeniIsim}\``,
                    `📋 **Sebep:** ${sebep}`
                ].join('\n'))
                .setThumbnail(hedef.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ text: `Lyuex • ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            await interaction.editReply({ embeds: [başarıEmbed] });

            // Detaylı log
            const logChannel = findLogChannel(interaction.guild, 'nick_log', 'lyuex_log');
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(THEME.cyan)
                    .setAuthor({ name: `${interaction.guild.name} — İsim Değişikliği`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setTitle('✏️ İsim Güncellendi')
                    .setDescription(ansiHeader('✏️  İSİM DEĞİŞİKLİĞİ KAYDI', '36'))
                    .addFields(
                        { name: '👮 Yetkili', value: `> <@${interaction.user.id}>\n> \`${interaction.user.id}\``, inline: true },
                        { name: '👤 Kullanıcı', value: `> <@${hedef.user.id}>\n> \`${hedef.user.id}\``, inline: true },
                        { name: '\u200B', value: '\u200B', inline: true },
                        { name: '📝 Eski İsim', value: `> \`${eskiIsim}\``, inline: true },
                        { name: '✏️ Yeni İsim', value: `> \`${yeniIsim}\``, inline: true },
                        { name: '📋 Sebep', value: `> ${sebep}`, inline: true }
                    )
                    .setThumbnail(hedef.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Lyuex İsim Değişikliği Sistemi' })
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('İsim değiştirme hatası:', error);
            await interaction.editReply({
                embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ İsim değiştirilemedi.\n> **Sebep:** ${error.message}`)]
            });
        }
    }
};