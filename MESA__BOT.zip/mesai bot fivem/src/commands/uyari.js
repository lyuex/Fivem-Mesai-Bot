﻿const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel, progressBar } = require('../utils/theme');

const UYARI_HARİTASI = {
    biriks: { name: '1x', emoji: '⚠️', seviye: 1, renk: '#FEE75C' },
    ikiiks: { name: '2x', emoji: '⚠️', seviye: 2, renk: '#FFB347' },
    uciks: { name: '3x', emoji: '🔶', seviye: 3, renk: '#FF8C00' },
    dortiks: { name: '4x', emoji: '🔴', seviye: 4, renk: '#FF4500' },
    besiks: { name: '5x', emoji: '💀', seviye: 5, renk: '#ED4245' },
    birgunwl: { name: '1 gün wl', emoji: '📛', seviye: 6, renk: '#E74C3C' },
    ikigunwl: { name: '2 gün wl', emoji: '📛', seviye: 7, renk: '#C0392B' },
    ucgunwl: { name: '3 gün wl', emoji: '📛', seviye: 8, renk: '#A93226' },
    besgunwl: { name: '5 gün wl', emoji: '🚫', seviye: 9, renk: '#922B21' },
    yedigunwl: { name: '7 gün wl', emoji: '🚫', seviye: 10, renk: '#7B241C' }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uyarı')
        .setDescription('⚠️ Gelişmiş uyarı sistemi — Seviye bazlı, DM bildirimli & log kayıtlı.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addUserOption(opt => opt.setName('kişi').setDescription('Uyarı verilecek kişi').setRequired(true))
        .addStringOption(opt => opt.setName('adet').setDescription('Uyarı seviyesi').setRequired(true)
            .setChoices(
                { name: '⚠️ 1x', value: 'biriks' },
                { name: '⚠️ 2x', value: 'ikiiks' },
                { name: '🔶 3x', value: 'uciks' },
                { name: '🔴 4x', value: 'dortiks' },
                { name: '💀 5x', value: 'besiks' },
                { name: '📛 1 gün WL', value: 'birgunwl' },
                { name: '📛 2 gün WL', value: 'ikigunwl' },
                { name: '📛 3 gün WL', value: 'ucgunwl' },
                { name: '🚫 5 gün WL', value: 'besgunwl' },
                { name: '🚫 7 gün WL', value: 'yedigunwl' }
            ))
        .addStringOption(opt => opt.setName('sebep').setDescription('Uyarı sebebi (opsiyonel)')),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'uyarı', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        const member = interaction.options.getMember('kişi');
        const adet = interaction.options.getString('adet');
        const sebep = interaction.options.getString('sebep') || 'Belirtilmedi';

        if (!member) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Kullanıcı sunucuda bulunamadı.')], ephemeral: true });
        }

        const uyarı = UYARI_HARİTASI[adet];
        const role = interaction.guild.roles.cache.find(r => r.name === uyarı.name);

        if (!role) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ Uyarı rolü bulunamadı: \`${uyarı.name}\`\n> \`/bot\` komutu ile uyarı rollerini oluşturabilirsiniz.`)], ephemeral: true });
        }

        // Mevcut uyarı rollerini kontrol et
        const mevcutUyarılar = member.roles.cache.filter(r => Object.values(UYARI_HARİTASI).some(u => u.name === r.name));
        const uyarıListesi = mevcutUyarılar.map(r => `\`${r.name}\``).join(', ') || 'Yok';

        // Seviye göstergesi
        const seviyeBar = progressBar(uyarı.seviye, 10, 10);

        await interaction.deferReply({ ephemeral: true });

        try {
            await member.roles.add(role);

            const başarıEmbed = new EmbedBuilder()
                .setColor(uyarı.renk)
                .setAuthor({ name: `${interaction.guild.name} — Uyarı Sistemi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle(`${uyarı.emoji} Uyarı Verildi — ${uyarı.name}`)
                .setDescription([
                    ansiHeader(`${uyarı.emoji}  UYARI VERİLDİ`, '31'),
                    '',
                    `👤 **Kullanıcı:** <@${member.user.id}> (\`${member.user.id}\`)`,
                    `👮 **Yetkili:** <@${interaction.user.id}>`,
                    `${uyarı.emoji} **Uyarı:** \`${uyarı.name}\``,
                    `📋 **Sebep:** ${sebep}`,
                    '',
                    `📊 **Ciddiyet Seviyesi:** ${uyarı.seviye}/10`,
                    `\`${seviyeBar}\``,
                    '',
                    `📑 **Önceki Uyarılar:** ${uyarıListesi}`
                ].join('\n'))
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ text: 'Lyuex Uyarı Sistemi', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.editReply({ embeds: [başarıEmbed] });

            // DM bildirimi
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor(uyarı.renk)
                    .setTitle(`${uyarı.emoji} Uyarı Aldınız!`)
                    .setDescription([
                        `**${interaction.guild.name}** sunucusunda uyarı aldınız.`,
                        '',
                        `${uyarı.emoji} **Uyarı:** \`${uyarı.name}\``,
                        `📋 **Sebep:** ${sebep}`,
                        `📊 **Ciddiyet:** \`${seviyeBar}\``,
                        '',
                        '> ⚠️ *Tekrarlayan uyarılar daha ağır yaptırımlara yol açabilir.*'
                    ].join('\n'))
                    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setTimestamp();

                await member.user.send({ embeds: [dmEmbed] });
            } catch {}

            // Log
            const logChannel = findLogChannel(interaction.guild, 'lyuex_log', 'ban_log');
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(uyarı.renk)
                    .setAuthor({ name: `Uyarı Kaydı — ${uyarı.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                    .setDescription(ansiHeader('⚠  UYARI KAYDI', '33'))
                    .addFields(
                        { name: '👤 Kullanıcı', value: `> <@${member.user.id}>\n> \`${member.user.id}\``, inline: true },
                        { name: '👮 Yetkili', value: `> <@${interaction.user.id}>\n> \`${interaction.user.id}\``, inline: true },
                        { name: `${uyarı.emoji} Uyarı`, value: `> \`${uyarı.name}\`\n> Seviye: ${uyarı.seviye}/10`, inline: true },
                        { name: '📋 Sebep', value: `> ${sebep}`, inline: false }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setFooter({ text: 'Lyuex Uyarı Sistemi' })
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('Uyarı hatası:', error);
            await interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ Uyarı verilemedi: \`${error.message}\``)] });
        }
    }
};
