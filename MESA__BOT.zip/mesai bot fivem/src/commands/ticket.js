const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { THEME } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Destek paneli oluştur')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor(THEME.primary)
            .setTitle('🎫 Destek Sistemi')
            .setDescription('Destek almak için aşağıdaki butona tıklayın.\nDestek ekibi en kısa sürede size yardımcı olacaktır.')
            .setFooter({ text: 'Lyuex Destek Sistemi' })
            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_olustur')
                .setLabel('Destek Talebi Oluştur')
                .setEmoji('🎫')
                .setStyle(ButtonStyle.Primary)
        );

        await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: '✅ Destek paneli oluşturuldu.', ephemeral: true });
    },
};
