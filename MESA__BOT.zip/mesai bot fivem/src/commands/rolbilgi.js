﻿const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, progressBar } = require('../utils/theme');

const ITEMS_PER_PAGE = 15;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rolbilgi')
        .setDescription('📋 Belirtilen rol hakkında detaylı bilgi ve üye listesi gösterir.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addRoleOption(option =>
            option.setName('rol')
                .setDescription('Bilgi almak istediğiniz rolü seçin.')
                .setRequired(true)),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'rolbilgi', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Bu komutu kullanma yetkiniz bulunmamaktadır.')],
                ephemeral: true
            });
        }

        await interaction.deferReply();
        const rol = interaction.options.getRole('rol');

        const members = [...rol.members.values()];
        const totalPages = Math.max(1, Math.ceil(members.length / ITEMS_PER_PAGE));
        let currentPage = 0;

        const createdAt = Math.floor(rol.createdTimestamp / 1000);
        const positionBar = progressBar(rol.position, interaction.guild.roles.cache.size, 10);

        function buildEmbed(page) {
            const start = page * ITEMS_PER_PAGE;
            const end = Math.min(start + ITEMS_PER_PAGE, members.length);
            const paginated = members.slice(start, end);

            const memberList = paginated.length > 0
                ? paginated.map((m, i) => `\`${String(start + i + 1).padStart(2, '0')}\` ${m.user.bot ? '🤖' : '👤'} **${m.nickname || m.user.displayName}** — <@${m.id}>`).join('\n')
                : '*Bu rolde henüz kimse yok.*';

            return new EmbedBuilder()
                .setColor(rol.hexColor || THEME.primary)
                .setAuthor({ name: `${interaction.guild.name} — Rol Bilgisi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle(`📋 ${rol.name}`)
                .setDescription(ansiHeader('📋  ROL BİLGİ SİSTEMİ', '34'))
                .addFields(
                    { name: '🆔 Rol ID', value: `\`${rol.id}\``, inline: true },
                    { name: '🎨 Renk', value: `\`${rol.hexColor}\` ${rol.hexColor !== '#000000' ? '●' : '○'}`, inline: true },
                    { name: '👥 Üye Sayısı', value: `\`${members.length}\``, inline: true },
                    { name: '📊 Pozisyon', value: `\`${rol.position}\` / \`${interaction.guild.roles.cache.size}\`\n${positionBar}`, inline: true },
                    { name: '📅 Oluşturulma', value: `<t:${createdAt}:R>`, inline: true },
                    { name: '📌 Etiket', value: `${rol}`, inline: true },
                    { name: '🔔 Etiketlenebilir', value: rol.mentionable ? '✅ Evet' : '❌ Hayır', inline: true },
                    { name: '📍 Ayrı Gösterim', value: rol.hoist ? '✅ Evet' : '❌ Hayır', inline: true },
                    { name: '🤖 Yönetilen', value: rol.managed ? '⚙️ Bot/Entegrasyon' : '👤 Manuel', inline: true },
                    { name: `👥 Üye Listesi — Sayfa ${page + 1}/${totalPages}`, value: memberList, inline: false }
                )
                .setFooter({ text: `Sayfa ${page + 1}/${totalPages} • Toplam ${members.length} üye • Lyuex Rol Sistemi`, iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();
        }

        function buildButtons(page) {
            return new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('rol_first').setEmoji('⏪').setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
                new ButtonBuilder().setCustomId('rol_prev').setEmoji('◀️').setStyle(ButtonStyle.Primary).setDisabled(page === 0),
                new ButtonBuilder().setCustomId('rol_page').setLabel(`${page + 1}/${totalPages}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('rol_next').setEmoji('▶️').setStyle(ButtonStyle.Primary).setDisabled(page >= totalPages - 1),
                new ButtonBuilder().setCustomId('rol_last').setEmoji('⏩').setStyle(ButtonStyle.Secondary).setDisabled(page >= totalPages - 1)
            );
        }

        const msg = await interaction.editReply({
            embeds: [buildEmbed(currentPage)],
            components: totalPages > 1 ? [buildButtons(currentPage)] : []
        });

        if (totalPages <= 1) return;

        const collector = msg.createMessageComponentCollector({ time: 120_000 });

        collector.on('collect', async (btn) => {
            if (btn.user.id !== interaction.user.id) {
                return btn.reply({ content: '❌ Bu paneli yalnızca komutu kullanan kişi kontrol edebilir.', ephemeral: true });
            }

            switch (btn.customId) {
                case 'rol_first': currentPage = 0; break;
                case 'rol_prev': currentPage = Math.max(0, currentPage - 1); break;
                case 'rol_next': currentPage = Math.min(totalPages - 1, currentPage + 1); break;
                case 'rol_last': currentPage = totalPages - 1; break;
            }

            await btn.update({ embeds: [buildEmbed(currentPage)], components: [buildButtons(currentPage)] });
        });

        collector.on('end', async () => {
            const disabledRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('rol_first').setEmoji('⏪').setStyle(ButtonStyle.Secondary).setDisabled(true),
                new ButtonBuilder().setCustomId('rol_prev').setEmoji('◀️').setStyle(ButtonStyle.Primary).setDisabled(true),
                new ButtonBuilder().setCustomId('rol_page').setLabel('Süre Doldu').setStyle(ButtonStyle.Danger).setDisabled(true),
                new ButtonBuilder().setCustomId('rol_next').setEmoji('▶️').setStyle(ButtonStyle.Primary).setDisabled(true),
                new ButtonBuilder().setCustomId('rol_last').setEmoji('⏩').setStyle(ButtonStyle.Secondary).setDisabled(true)
            );
            await interaction.editReply({ components: [disabledRow] }).catch(() => {});
        });
    },
};
