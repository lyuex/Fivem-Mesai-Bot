const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const { THEME } = require('../utils/theme');

const db = new JsonDatabase({ databasePath: "./src/database/fordb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('izin')
        .setDescription('İzin/tatil sistemi')
        .addSubcommand(sub =>
            sub.setName('ver')
                .setDescription('Bir kullanıcıya izin ver')
                .addUserOption(opt => opt.setName('kullanici').setDescription('İzin verilecek kişi').setRequired(true))
                .addStringOption(opt => opt.setName('bitis').setDescription('Bitiş tarihi (GG.AA.YYYY)').setRequired(true))
                .addStringOption(opt => opt.setName('sebep').setDescription('İzin sebebi').setRequired(false))
        )
        .addSubcommand(sub =>
            sub.setName('kaldir')
                .setDescription('Bir kullanıcının iznini kaldır')
                .addUserOption(opt => opt.setName('kullanici').setDescription('İzni kaldırılacak kişi').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('liste')
                .setDescription('İzinli kullanıcıları listele')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
    async execute(interaction) {
        const sub = interaction.options.getSubcommand();

        if (sub === 'ver') {
            const user = interaction.options.getUser('kullanici');
            const bitisStr = interaction.options.getString('bitis');
            const sebep = interaction.options.getString('sebep') || 'Belirtilmedi';

            const bitis = moment(bitisStr, 'DD.MM.YYYY', true);
            if (!bitis.isValid()) {
                return interaction.reply({ content: '❌ Geçersiz tarih formatı! Doğru format: `GG.AA.YYYY`', ephemeral: true });
            }
            if (bitis.isBefore(moment())) {
                return interaction.reply({ content: '❌ Bitiş tarihi geçmişte olamaz!', ephemeral: true });
            }

            db.set(`izin.${user.id}`, {
                baslangic: moment().format('YYYY-MM-DD'),
                bitis: bitis.format('YYYY-MM-DD'),
                sebep,
                veren: interaction.user.id,
            });

            const embed = new EmbedBuilder()
                .setColor(THEME.success)
                .setTitle('✅ İzin Verildi')
                .addFields(
                    { name: 'Kullanıcı', value: `${user}`, inline: true },
                    { name: 'Bitiş', value: bitis.format('DD.MM.YYYY'), inline: true },
                    { name: 'Sebep', value: sebep, inline: false },
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }

        if (sub === 'kaldir') {
            const user = interaction.options.getUser('kullanici');
            const izin = db.get(`izin.${user.id}`);
            if (!izin) {
                return interaction.reply({ content: '❌ Bu kullanıcının aktif izni yok.', ephemeral: true });
            }
            db.delete(`izin.${user.id}`);
            await interaction.reply({
                embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`✅ ${user} kullanıcısının izni kaldırıldı.`).setTimestamp()]
            });
        }

        if (sub === 'liste') {
            const allData = db.toJSON() || {};
            const izinler = [];
            for (const [key, val] of Object.entries(allData)) {
                if (key.startsWith('izin.')) {
                    const userId = key.replace('izin.', '');
                    if (moment(val.bitis).isAfter(moment())) {
                        izinler.push({ userId, ...val });
                    }
                }
            }

            // Fallback: izin objesi olarak kontrol
            if (allData.izin && typeof allData.izin === 'object') {
                for (const [userId, val] of Object.entries(allData.izin)) {
                    if (moment(val.bitis).isAfter(moment()) && !izinler.find(i => i.userId === userId)) {
                        izinler.push({ userId, ...val });
                    }
                }
            }

            if (izinler.length === 0) {
                return interaction.reply({ content: 'ℹ️ Aktif izinli kullanıcı yok.', ephemeral: true });
            }

            const desc = izinler.map((i, idx) =>
                `**${idx + 1}.** <@${i.userId}> — ${moment(i.bitis).format('DD.MM.YYYY')} tarihine kadar\n> Sebep: ${i.sebep || '-'}`
            ).join('\n\n');

            const embed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle('📅 İzinli Kullanıcılar')
                .setDescription(desc)
                .setFooter({ text: `Toplam ${izinler.length} kişi` })
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    },
};
