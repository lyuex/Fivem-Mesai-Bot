﻿const {
    EmbedBuilder, ButtonBuilder, ButtonStyle,
    SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder
} = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, progressBar, checkCooldown, findLogChannel } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aktiflik')
        .setDescription('📋 Gelişmiş aktiflik testi — Canlı sayaç & otomatik yaptırım sistemi.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addIntegerOption(opt =>
            opt.setName('süre').setDescription('Test süresi (saat)').setMinValue(1).setMaxValue(72))
        .addRoleOption(opt =>
            opt.setName('hedef_rol').setDescription('Teste tabi tutulacak rol')),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'aktiflik', 30);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const süre = interaction.options.getInteger('süre') || 24;
        const hedefRol = interaction.options.getRole('hedef_rol');
        const hedefRolId = hedefRol?.id || config.rol.kayıtlı;
        const inaktifRolId = config.rol.inaktif;
        const guild = interaction.guild;
        const bitiş = Date.now() + (süre * 60 * 60 * 1000);
        const aktifler = new Set();

        const buildTestEmbed = (count = 0) => new EmbedBuilder()
            .setColor(THEME.primary)
            .setAuthor({ name: `${guild.name} — Aktiflik Kontrol Sistemi`, iconURL: guild.iconURL({ dynamic: true }) })
            .setTitle('⚡ Aktiflik Testi Başlatıldı')
            .setDescription([
                ansiHeader('⏱  AKTİFLİK TESTİ DEVAM EDİYOR', '37'),
                '> 🔔 **Aktiflik testini geçmek için aşağıdaki butona tıklayın!**',
                '',
                `📌 **Test Detayları:**`,
                `┣ ⏰ Süre: **${süre} saat**`,
                `┣ 📅 Bitiş: <t:${Math.floor(bitiş / 1000)}:R>`,
                `┣ 🎯 Hedef Rol: <@&${hedefRolId}>`,
                `┗ 👤 Aktif Sayısı: \`${count} kişi\``,
                '',
                '> ⚠️ *Süre bitiminde butona basmayan kişilere inaktif rolü verilecektir.*'
            ].join('\n'))
            .setThumbnail(guild.iconURL({ dynamic: true, size: 512 }))
            .setFooter({ text: `Lyuex Aktiflik Sistemi • ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        const aktifBtn = new ButtonBuilder().setCustomId('aktiflik_buton').setLabel('✅ Aktifim!').setStyle(ButtonStyle.Success);
        const bilgiBtn = new ButtonBuilder().setCustomId('aktiflik_bilgi').setLabel('📊 Katılımcılar').setStyle(ButtonStyle.Secondary);
        const row = new ActionRowBuilder().addComponents(aktifBtn, bilgiBtn);

        const msg = await interaction.channel.send({ content: '||@everyone|| & ||@here||', embeds: [buildTestEmbed()], components: [row] });

        await interaction.editReply({
            embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ Aktiflik testi başlatıldı!\n📍 Kanal: <#${interaction.channel.id}>\n⏰ Bitiş: <t:${Math.floor(bitiş / 1000)}:F>`)]
        });

        // Yarı sürede hatırlatma ping'i
        const halfTimer = setTimeout(async () => {
            const kalan = Math.ceil((bitiş - Date.now()) / 3600000);
            const hatırlatma = new EmbedBuilder()
                .setColor(THEME.warning)
                .setDescription(`⏰ **Aktiflik testi bitiyor!** Kalan süre: **~${kalan} saat**\n> Henüz aktifim butonuna basmadıysanız acele edin!\n> 👤 Şu ana kadar **${aktifler.size}** kişi aktif.`)
                .setTimestamp();
            await interaction.channel.send({ content: '||@everyone||', embeds: [hatırlatma] }).catch(() => {});
        }, (süre * 60 * 60 * 1000) / 2);

        const collector = msg.createMessageComponentCollector({ time: süre * 60 * 60 * 1000 });

        collector.on('collect', async (btn) => {
            if (btn.customId === 'aktiflik_bilgi') {
                const liste = aktifler.size > 0
                    ? [...aktifler].map((id, i) => `\`${i + 1}.\` <@${id}>`).slice(0, 25).join('\n')
                    : '*Henüz kimse katılmadı.*';
                return btn.reply({
                    embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📊 Katılımcılar').setDescription(`**Toplam:** \`${aktifler.size}\` kişi\n\n${liste}${aktifler.size > 25 ? `\n*...ve ${aktifler.size - 25} kişi daha.*` : ''}`).setTimestamp()],
                    ephemeral: true
                });
            }

            if (btn.customId === 'aktiflik_buton') {
                if (aktifler.has(btn.user.id)) {
                    return btn.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('⚠️ Zaten aktif olarak işaretlendiniz!')], ephemeral: true });
                }
                aktifler.add(btn.user.id);
                if (btn.member?.roles.cache.has(inaktifRolId)) await btn.member.roles.remove(inaktifRolId).catch(() => {});

                await msg.edit({ embeds: [buildTestEmbed(aktifler.size)] }).catch(() => {});

                return btn.reply({
                    embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ Başarıyla aktif olarak işaretlendiniz!\n🎉 Aktiflik testini geçtiniz! (\`#${aktifler.size}\`)`)],
                    ephemeral: true
                });
            }
        });

        collector.on('end', async () => {
            clearTimeout(halfTimer);

            const devreDışı = new ActionRowBuilder().addComponents(
                ButtonBuilder.from(aktifBtn).setDisabled(true).setLabel('⏹ Test Bitti').setStyle(ButtonStyle.Danger),
                ButtonBuilder.from(bilgiBtn).setDisabled(true)
            );

            let inaktifSayısı = 0;
            const hedefRolObj = guild.roles.cache.get(hedefRolId);
            if (hedefRolObj) {
                for (const [id, member] of hedefRolObj.members) {
                    if (!aktifler.has(id) && !member.user.bot) {
                        await member.roles.add(inaktifRolId).catch(() => {});
                        inaktifSayısı++;
                    }
                }
            }

            const toplam = hedefRolObj?.members.filter(m => !m.user.bot).size || 0;
            const yüzde = toplam > 0 ? ((aktifler.size / toplam) * 100).toFixed(1) : 0;

            const sonuç = new EmbedBuilder()
                .setColor(THEME.gold)
                .setAuthor({ name: `${guild.name} — Aktiflik Test Sonuçları`, iconURL: guild.iconURL({ dynamic: true }) })
                .setTitle('🏁 Aktiflik Testi Tamamlandı!')
                .setDescription([
                    ansiHeader('✓  TEST SONA ERDİ', '33'),
                    `📊 **İstatistikler:**`,
                    `┣ ✅ Aktif: **${aktifler.size}** kişi`,
                    `┣ ❌ İnaktif: **${inaktifSayısı}** kişi`,
                    `┣ 👥 Toplam: **${toplam}** kişi`,
                    `┗ 📈 Katılım: **%${yüzde}**`,
                    '',
                    `\`${progressBar(aktifler.size, toplam)}\` **%${yüzde}**`,
                    '',
                    '> 📌 *İnaktif kişilere otomatik olarak inaktif rolü verildi.*'
                ].join('\n'))
                .setFooter({ text: `Lyuex • Test süresi: ${süre} saat` })
                .setTimestamp();

            await msg.edit({ embeds: [sonuç], components: [devreDışı] }).catch(() => {});

            // Log
            const logCh = findLogChannel(guild, 'lyuex_log');
            if (logCh) {
                logCh.send({ embeds: [new EmbedBuilder()
                    .setColor(THEME.gold)
                    .setTitle('📋 Aktiflik Testi Sonucu')
                    .addFields(
                        { name: '👮 Başlatan', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '✅ Aktif', value: `\`${aktifler.size}\``, inline: true },
                        { name: '❌ İnaktif', value: `\`${inaktifSayısı}\``, inline: true }
                    )
                    .setTimestamp()
                ] });
            }
        });
    }
};
