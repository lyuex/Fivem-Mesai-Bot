﻿const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, EmbedBuilder, Collection, ButtonStyle } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, formatDuration, findLogChannel } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('etkinlik')
        .setDescription('🎉 Gelişmiş etkinlik/çekiliş sistemi — Canlı sayaç & otomatik kazanan seçimi.')
        .addStringOption(opt => opt.setName('etkinlik').setDescription('Etkinlik/ödül adı').setRequired(true))
        .addIntegerOption(opt => opt.setName('kazanan_sayısı').setDescription('Kaç kişi kazanacak?').setMinValue(1).setMaxValue(50).setRequired(true))
        .addStringOption(opt => opt.setName('mesaj').setDescription('Katılımcılara gönderilecek DM mesajı').setRequired(true))
        .addIntegerOption(opt => opt.setName('süre').setDescription('Süre (saniye)').setMinValue(10).setMaxValue(604800).setRequired(true))
        .addStringOption(opt => opt.setName('açıklama').setDescription('Etkinlik açıklaması (opsiyonel)'))
        .addRoleOption(opt => opt.setName('gerekli_rol').setDescription('Katılım için gerekli rol (opsiyonel)')),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'etkinlik', 15);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        const member = interaction.guild.members.cache.get(interaction.user.id);
        if (!member.roles.cache.some(r => config.rol.yonetici.includes(r.id))) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')],
                ephemeral: true
            });
        }

        const ödül = interaction.options.getString('etkinlik');
        const kazananSayısı = interaction.options.getInteger('kazanan_sayısı');
        const süre = interaction.options.getInteger('süre');
        const mesaj = interaction.options.getString('mesaj');
        const açıklama = interaction.options.getString('açıklama');
        const gerekliRol = interaction.options.getRole('gerekli_rol');
        const guildOwner = await interaction.guild.fetchOwner();
        const bitiş = Date.now() + (süre * 1000);

        const participants = new Collection();

        const etkinlikEmbed = new EmbedBuilder()
            .setColor(THEME.party)
            .setAuthor({ name: `${interaction.guild.name} — Etkinlik Sistemi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('🎉 Yeni Etkinlik Başladı!')
            .setDescription([
                ansiHeader('🎊  ETKİNLİK DEVAM EDİYOR', '35'),
                '',
                `🏆 **Ödül:** ${ödül}`,
                açıklama ? `📝 **Açıklama:** ${açıklama}` : '',
                '',
                `📌 **Etkinlik Detayları:**`,
                `┣ ⏰ Süre: **${formatDuration(süre)}**`,
                `┣ 📅 Bitiş: <t:${Math.floor(bitiş / 1000)}:R>`,
                `┣ 🎯 Kazanan Sayısı: **${kazananSayısı}** kişi`,
                gerekliRol ? `┣ 🎭 Gerekli Rol: <@&${gerekliRol.id}>` : '',
                `┗ 👥 Katılımcı: \`0 kişi\``,
                '',
                '> 🔔 **Katılmak için aşağıdaki butona tıklayın!**'
            ].filter(Boolean).join('\n'))
            .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 512 }))
            .setFooter({ text: `Lyuex Etkinlik Sistemi • Başlatan: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp(bitiş);

        const katılBtn = new ButtonBuilder().setCustomId('etkinlik_katil').setLabel('🎉 Katıl').setStyle(ButtonStyle.Success);
        const katılımcıBtn = new ButtonBuilder().setCustomId('etkinlik_liste').setLabel('👥 Katılımcılar').setStyle(ButtonStyle.Secondary);
        const ayrılBtn = new ButtonBuilder().setCustomId('etkinlik_ayril').setLabel('🚪 Ayrıl').setStyle(ButtonStyle.Danger);
        const row = new ActionRowBuilder().addComponents(katılBtn, katılımcıBtn, ayrılBtn);

        const giveawayMessage = await interaction.reply({ content: '||@everyone||', embeds: [etkinlikEmbed], components: [row], fetchReply: true });

        const collector = giveawayMessage.createMessageComponentCollector({ time: süre * 1000 });

        const updateEmbed = async () => {
            const güncel = EmbedBuilder.from(giveawayMessage.embeds[0]).setDescription(
                giveawayMessage.embeds[0].description.replace(/👥 Katılımcı: `\d+ kişi`/, `👥 Katılımcı: \`${participants.size} kişi\``)
            );
            await giveawayMessage.edit({ embeds: [güncel] }).catch(() => {});
        };

        collector.on('collect', async (btn) => {
            // ─── Katılımcı Listesi ───
            if (btn.customId === 'etkinlik_liste') {
                const liste = participants.size > 0
                    ? participants.map((u, id) => `<@${id}>`).slice(0, 30).join(', ')
                    : '*Henüz kimse katılmadı.*';
                return btn.reply({
                    embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('👥 Etkinlik Katılımcıları').setDescription(`**Toplam:** \`${participants.size}\` kişi\n\n${liste}${participants.size > 30 ? `\n\n*...ve ${participants.size - 30} kişi daha.*` : ''}`).setTimestamp()],
                    ephemeral: true
                });
            }

            // ─── Ayrılma ───
            if (btn.customId === 'etkinlik_ayril') {
                if (!participants.has(btn.user.id)) {
                    return btn.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('⚠️ Zaten etkinliğe katılmamışsınız.')], ephemeral: true });
                }
                participants.delete(btn.user.id);
                await updateEmbed();
                return btn.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🚪 Etkinlikten ayrıldınız.')], ephemeral: true });
            }

            // ─── Katılma ───
            if (btn.customId === 'etkinlik_katil') {
                if (participants.has(btn.user.id)) {
                    return btn.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('⚠️ Zaten etkinliğe katıldınız!')], ephemeral: true });
                }
                if (gerekliRol && !btn.member.roles.cache.has(gerekliRol.id)) {
                    return btn.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`🔒 Katılım için <@&${gerekliRol.id}> rolüne sahip olmalısınız.`)], ephemeral: true });
                }

                participants.set(btn.user.id, btn.user);
                await updateEmbed();

                return btn.reply({
                    embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ **Etkinliğe başarıyla katıldınız!**\n\n🏆 Ödül: **${ödül}**\n📅 Bitiş: <t:${Math.floor(bitiş / 1000)}:R>\n🍀 Bol şans!`)],
                    ephemeral: true
                });
            }
        });

        collector.on('end', async () => {
            const devreDışı = new ActionRowBuilder().addComponents(
                ButtonBuilder.from(katılBtn).setDisabled(true).setLabel('⏹ Bitti').setStyle(ButtonStyle.Secondary),
                ButtonBuilder.from(katılımcıBtn).setDisabled(true),
                ButtonBuilder.from(ayrılBtn).setDisabled(true)
            );

            if (participants.size < kazananSayısı) {
                const iptalEmbed = new EmbedBuilder()
                    .setColor(THEME.danger)
                    .setTitle('❌ Etkinlik İptal Edildi')
                    .setDescription([
                        '```ansi',
                        '\u001b[1;31m╔══════════════════════════════════════════════╗',
                        '\u001b[1;31m║  \u001b[1;37m✗  YETERLİ KATILIMCI YOK                   \u001b[1;31m║',
                        '\u001b[1;31m╚══════════════════════════════════════════════╝',
                        '```',
                        `🏆 Ödül: **${ödül}**`,
                        `👥 Katılımcı: **${participants.size}** / minimum **${kazananSayısı}**`,
                        '',
                        '> ❌ *Yeterli katılımcı olmadığı için etkinlik iptal edildi.*'
                    ].join('\n'))
                    .setTimestamp();

                await interaction.editReply({ embeds: [iptalEmbed], components: [devreDışı] });

                const logChannel = interaction.guild.channels.cache.find(c => c.name.includes('lyuex_log') || c.name.includes('lyuex'));
                if (logChannel) logChannel.send({ embeds: [new EmbedBuilder().setColor(THEME.danger).setTitle('📋 Etkinlik Log — İptal').setDescription(`Ödül: **${ödül}**\nBaşlatan: ${interaction.user.tag}\nKatılımcı: ${participants.size}\nSebep: Yetersiz katılım`).setTimestamp()] });
                return;
            }

            // Fisher-Yates shuffle ile adil kazanan seçimi
            const participantArray = Array.from(participants.values());
            for (let i = participantArray.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [participantArray[i], participantArray[j]] = [participantArray[j], participantArray[i]];
            }
            const winners = participantArray.slice(0, kazananSayısı);

            const winnerMentions = winners.map(w => `<@${w.id}>`).join(', ');
            const winnerDetails = winners.map((w, i) => `\`${i + 1}.\` **${w.tag}** — \`${w.id}\``).join('\n');

            const sonuçEmbed = new EmbedBuilder()
                .setColor(THEME.gold)
                .setAuthor({ name: `${interaction.guild.name} — Etkinlik Sonuçları`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle('🏆 Etkinlik Sona Erdi!')
                .setDescription([
                    '```ansi',
                    '\u001b[1;33m╔══════════════════════════════════════════════╗',
                    '\u001b[1;33m║  \u001b[1;32m🏆  KAZANANLAR BELİRLENDİ!                 \u001b[1;33m║',
                    '\u001b[1;33m╚══════════════════════════════════════════════╝',
                    '```',
                    '',
                    `🎉 **Ödül:** ${ödül}`,
                    '',
                    `🥇 **Kazananlar:**`,
                    winnerDetails,
                    '',
                    `📊 **İstatistikler:**`,
                    `┣ 👥 Toplam Katılım: **${participants.size}** kişi`,
                    `┣ 🏅 Kazanan: **${winners.length}** kişi`,
                    `┗ ⏱️ Süre: **${formatDuration(süre)}**`,
                    '',
                    `> 🎊 Tebrikler ${winnerMentions}!`
                ].join('\n'))
                .setFooter({ text: 'Lyuex Etkinlik Sistemi' })
                .setTimestamp();

            await interaction.editReply({ embeds: [sonuçEmbed], components: [devreDışı] });

            // DM gönderimi
            const dmEmbed = new EmbedBuilder()
                .setColor(THEME.gold)
                .setTitle('🎉 Etkinlik Bildirimi')
                .setDescription(mesaj)
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            const kazananDM = new EmbedBuilder()
                .setColor(THEME.gold)
                .setTitle('🏆 TEBRİKLER! Etkinliği Kazandınız!')
                .setDescription(`${mesaj}\n\n**Ödül:** ${ödül}\n**Sunucu:** ${interaction.guild.name}`)
                .setFooter({ text: interaction.guild.name })
                .setTimestamp();

            for (const w of winners) { try { await w.send({ embeds: [kazananDM] }); } catch {} }
            for (const [, p] of participants) { try { await p.send({ embeds: [dmEmbed] }); } catch {} }
            try { await guildOwner.send({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📋 Etkinlik Sonuç Raporu').setDescription(`**Ödül:** ${ödül}\n**Kazananlar:**\n${winnerDetails}\n**Toplam Katılım:** ${participants.size + winners.length}\n**Mesaj:** ${mesaj}`).setTimestamp()] }); } catch {}

            const logChannel = interaction.guild.channels.cache.find(c => c.name.includes('lyuex_log') || c.name.includes('lyuex'));
            if (logChannel) {
                logChannel.send({ embeds: [new EmbedBuilder().setColor(THEME.gold).setTitle('📋 Etkinlik Log — Tamamlandı').setDescription(`**Ödül:** ${ödül}\n**Kazananlar:** ${winnerMentions}\n**Katılım:** ${participants.size + winners.length}\n**Başlatan:** ${interaction.user.tag}`).setTimestamp()] });
            }
        });
    }
};
