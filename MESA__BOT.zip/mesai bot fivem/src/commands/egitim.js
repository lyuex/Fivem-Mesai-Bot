const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel, errorEmbed } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('egitim')
        .setDescription('📚 Eğitim oluştur, katılım ekle veya geçmişi görüntüle')
        .addSubcommand(sub => sub
            .setName('olustur')
            .setDescription('📚 Yeni eğitim oturumu oluştur')
            .addStringOption(opt => opt.setName('konu').setDescription('Eğitim konusu').setRequired(true)
                .addChoices(
                    { name: '🔫 Silah Kullanımı', value: 'Silah Kullanımı' },
                    { name: '🚗 Araç Takip & Durdurma', value: 'Araç Takip & Durdurma' },
                    { name: '📜 Hukuk & Mevzuat', value: 'Hukuk & Mevzuat' },
                    { name: '🗣️ İletişim & Müzakere', value: 'İletişim & Müzakere' },
                    { name: '🥊 Yakın Dövüş & Müdahale', value: 'Yakın Dövüş & Müdahale' },
                    { name: '🔍 Soruşturma Teknikleri', value: 'Soruşturma Teknikleri' },
                    { name: '🚁 Taktik Operasyon', value: 'Taktik Operasyon' },
                    { name: '💉 İlk Yardım', value: 'İlk Yardım' },
                    { name: '📡 Telsiz Kullanımı', value: 'Telsiz Kullanımı' },
                    { name: '📋 Genel Eğitim', value: 'Genel Eğitim' }
                ))
            .addStringOption(opt => opt.setName('aciklama').setDescription('Eğitim açıklaması').setRequired(false))
        )
        .addSubcommand(sub => sub
            .setName('katilimci')
            .setDescription('➕ Eğitime katılımcı ekle')
            .addIntegerOption(opt => opt.setName('egitim-no').setDescription('Eğitim numarası').setRequired(true).setMinValue(1))
            .addUserOption(opt => opt.setName('kisi').setDescription('Katılımcı').setRequired(true))
            .addIntegerOption(opt => opt.setName('puan').setDescription('Katılım puanı (1-100)').setRequired(false).setMinValue(1).setMaxValue(100))
        )
        .addSubcommand(sub => sub
            .setName('bitir')
            .setDescription('✅ Aktif eğitimi sonlandır')
            .addIntegerOption(opt => opt.setName('egitim-no').setDescription('Eğitim numarası').setRequired(true).setMinValue(1))
        )
        .addSubcommand(sub => sub
            .setName('liste')
            .setDescription('📋 Eğitim geçmişini listele')
            .addStringOption(opt => opt.setName('filtre').setDescription('Filtre türü').setRequired(false)
                .addChoices(
                    { name: '📋 Tümü', value: 'tumu' },
                    { name: '🟢 Aktif', value: 'aktif' },
                    { name: '🔴 Tamamlanmış', value: 'tamamlanmis' }
                ))
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'egitim', 5);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [errorEmbed('Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'olustur') return this.olustur(interaction);
        if (sub === 'katilimci') return this.katilimci(interaction);
        if (sub === 'bitir') return this.bitir(interaction);
        if (sub === 'liste') return this.liste(interaction);
    },

    async olustur(interaction) {
        await interaction.deferReply();

        const konu = interaction.options.getString('konu');
        const aciklama = interaction.options.getString('aciklama') || 'Açıklama belirtilmedi.';

        const egitimler = policeDb.get('egitimler') || [];
        const kayitNo = egitimler.length + 1;

        const konuEmojis = {
            'Silah Kullanımı': '🔫', 'Araç Takip & Durdurma': '🚗', 'Hukuk & Mevzuat': '📜',
            'İletişim & Müzakere': '🗣️', 'Yakın Dövüş & Müdahale': '🥊', 'Soruşturma Teknikleri': '🔍',
            'Taktik Operasyon': '🚁', 'İlk Yardım': '💉', 'Telsiz Kullanımı': '📡', 'Genel Eğitim': '📋'
        };

        const yeniEgitim = {
            no: kayitNo,
            egitmenId: interaction.user.id,
            konu,
            aciklama,
            katilimcilar: [],
            durum: 'aktif',
            baslangic: moment().format('YYYY-MM-DD HH:mm:ss'),
            bitis: null,
            timestamp: Date.now()
        };

        egitimler.push(yeniEgitim);
        policeDb.set('egitimler', egitimler);

        const embed = new EmbedBuilder()
            .setColor(THEME.cyan)
            .setAuthor({ name: `${interaction.guild.name} — Eğitim Sistemi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`${konuEmojis[konu] || '📚'} Eğitim #${kayitNo} — ${konu}`)
            .setDescription([
                ansiHeader('📚  YENİ EĞİTİM OTURUMU', '36'),
                '',
                `👨‍🏫 **Eğitmen:** <@${interaction.user.id}>`,
                `📅 **Başlangıç:** \`${moment().format('DD.MM.YYYY HH:mm')}\``,
                `📝 **Açıklama:** ${aciklama}`,
                `🟢 **Durum:** Aktif`,
                '',
                `> Katılımcı eklemek için: \`/egitim katilimci egitim-no:${kayitNo}\``,
                `> Bitirmek için: \`/egitim bitir egitim-no:${kayitNo}\``
            ].join('\n'))
            .setFooter({ text: `Eğitim No: #${kayitNo} • Lyuex Eğitim Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        const logChannel = findLogChannel(interaction.guild, 'egitim_log', 'polis_log', 'lyuex_log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor(THEME.cyan)
                .setTitle(`📚 Yeni Eğitim #${kayitNo} — ${konu}`)
                .setDescription(`👨‍🏫 Eğitmen: <@${interaction.user.id}>\n📝 ${aciklama}`)
                .setFooter({ text: `#${kayitNo}` })
                .setTimestamp();
            await logChannel.send({ embeds: [logEmbed] });
        }
    },

    async katilimci(interaction) {
        await interaction.deferReply();

        const egitimNo = interaction.options.getInteger('egitim-no');
        const kisi = interaction.options.getUser('kisi');
        const puan = interaction.options.getInteger('puan') || 80;

        const egitimler = policeDb.get('egitimler') || [];
        const egitimIndex = egitimler.findIndex(e => e.no === egitimNo);

        if (egitimIndex === -1) {
            return interaction.editReply({ embeds: [errorEmbed(`#${egitimNo} numaralı eğitim bulunamadı.`)] });
        }

        const egitim = egitimler[egitimIndex];

        if (egitim.durum !== 'aktif') {
            return interaction.editReply({ embeds: [errorEmbed('Bu eğitim zaten tamamlanmış.')] });
        }

        if (egitim.katilimcilar.find(k => k.id === kisi.id)) {
            return interaction.editReply({ embeds: [errorEmbed(`<@${kisi.id}> zaten bu eğitime kayıtlı.`)] });
        }

        egitim.katilimcilar.push({
            id: kisi.id,
            puan: puan,
            tarih: moment().format('YYYY-MM-DD HH:mm:ss')
        });

        egitimler[egitimIndex] = egitim;
        policeDb.set('egitimler', egitimler);

        const embed = new EmbedBuilder()
            .setColor(THEME.success)
            .setTitle(`✅ Katılımcı Eklendi — Eğitim #${egitimNo}`)
            .setDescription([
                `👤 **Katılımcı:** <@${kisi.id}>`,
                `📚 **Eğitim:** ${egitim.konu}`,
                `⭐ **Puan:** \`${puan}/100\``,
                `👥 **Toplam Katılımcı:** \`${egitim.katilimcilar.length}\``
            ].join('\n'))
            .setFooter({ text: `Eğitim #${egitimNo} • Lyuex Eğitim Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async bitir(interaction) {
        await interaction.deferReply();

        const egitimNo = interaction.options.getInteger('egitim-no');
        const egitimler = policeDb.get('egitimler') || [];
        const egitimIndex = egitimler.findIndex(e => e.no === egitimNo);

        if (egitimIndex === -1) {
            return interaction.editReply({ embeds: [errorEmbed(`#${egitimNo} numaralı eğitim bulunamadı.`)] });
        }

        const egitim = egitimler[egitimIndex];

        if (egitim.durum !== 'aktif') {
            return interaction.editReply({ embeds: [errorEmbed('Bu eğitim zaten tamamlanmış.')] });
        }

        if (egitim.egitmenId !== interaction.user.id && !checkPermission(interaction, config)) {
            return interaction.editReply({ embeds: [errorEmbed('Sadece eğitmen veya yetkililer eğitimi bitirebilir.')] });
        }

        egitim.durum = 'tamamlandi';
        egitim.bitis = moment().format('YYYY-MM-DD HH:mm:ss');
        egitimler[egitimIndex] = egitim;
        policeDb.set('egitimler', egitimler);

        const sure = moment(egitim.bitis).diff(moment(egitim.baslangic), 'minutes');
        const ortPuan = egitim.katilimcilar.length > 0
            ? Math.round(egitim.katilimcilar.reduce((t, k) => t + k.puan, 0) / egitim.katilimcilar.length)
            : 0;

        const katilimciListesi = egitim.katilimcilar.length > 0
            ? egitim.katilimcilar.map((k, i) => `\`${i + 1}.\` <@${k.id}> — ⭐ ${k.puan}/100`).join('\n')
            : '`Katılımcı yok`';

        const embed = new EmbedBuilder()
            .setColor(THEME.gold)
            .setAuthor({ name: `${interaction.guild.name} — Eğitim Raporu`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`📚 Eğitim #${egitimNo} Tamamlandı — ${egitim.konu}`)
            .setDescription([
                ansiHeader('📚  EĞİTİM RAPORU', '33'),
                '',
                `👨‍🏫 **Eğitmen:** <@${egitim.egitmenId}>`,
                `📅 **Başlangıç:** \`${moment(egitim.baslangic).format('DD.MM.YYYY HH:mm')}\``,
                `🏁 **Bitiş:** \`${moment(egitim.bitis).format('DD.MM.YYYY HH:mm')}\``,
                `⏱️ **Süre:** \`${sure} dakika\``,
                `👥 **Katılımcı Sayısı:** \`${egitim.katilimcilar.length}\``,
                `⭐ **Ortalama Puan:** \`${ortPuan}/100\``,
            ].join('\n'))
            .addFields(
                { name: '👥 Katılımcılar', value: katilimciListesi.length > 1024 ? katilimciListesi.slice(0, 1021) + '...' : katilimciListesi }
            )
            .setFooter({ text: `Eğitim No: #${egitimNo} • Lyuex Eğitim Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        const logChannel = findLogChannel(interaction.guild, 'egitim_log', 'polis_log', 'lyuex_log');
        if (logChannel) {
            await logChannel.send({ embeds: [embed] });
        }
    },

    async liste(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const filtre = interaction.options.getString('filtre') || 'tumu';
        const egitimler = policeDb.get('egitimler') || [];

        if (egitimler.length === 0) {
            return interaction.editReply({ embeds: [errorEmbed('Henüz kayıtlı eğitim bulunmuyor.')] });
        }

        let filtrelenmis = egitimler;
        if (filtre === 'aktif') filtrelenmis = egitimler.filter(e => e.durum === 'aktif');
        if (filtre === 'tamamlanmis') filtrelenmis = egitimler.filter(e => e.durum === 'tamamlandi');

        const filtreBaşlık = { tumu: '📋 Tüm Eğitimler', aktif: '🟢 Aktif Eğitimler', tamamlanmis: '🔴 Tamamlanmış Eğitimler' };

        const son10 = filtrelenmis.slice(-10).reverse();

        const satirlar = son10.map(e => {
            const durumIcon = e.durum === 'aktif' ? '🟢' : '🔴';
            const tarih = moment(e.baslangic).format('DD.MM');
            return `${durumIcon} \`#${e.no}\` **${e.konu}** — 👨‍🏫 <@${e.egitmenId}> • 👥 ${e.katilimcilar.length} kişi • \`${tarih}\``;
        });

        const embed = new EmbedBuilder()
            .setColor(THEME.cyan)
            .setAuthor({ name: `${interaction.guild.name} — Eğitim Sistemi`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(filtreBaşlık[filtre])
            .setDescription([
                ansiHeader('📚  EĞİTİM GEÇMİŞİ', '36'),
                '',
                satirlar.join('\n') || '`Kayıt bulunamadı.`',
                '',
                `📊 **Toplam:** \`${filtrelenmis.length}\` • **Aktif:** \`${egitimler.filter(e => e.durum === 'aktif').length}\` • **Tamamlanmış:** \`${egitimler.filter(e => e.durum === 'tamamlandi').length}\``
            ].join('\n'))
            .setFooter({ text: `Son 10 kayıt gösteriliyor • Lyuex Eğitim Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};
