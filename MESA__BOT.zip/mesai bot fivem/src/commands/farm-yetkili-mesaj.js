﻿const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, PermissionFlagsBits, ActionRowBuilder } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('farm-yetkili-mesaj')
        .setDescription('🛡️ Farm yetkili yönetim menüsünü gönderir — Yönetici paneli.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'farm-yetkili-mesaj', 30);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const yetkiliEmbed = new EmbedBuilder()
            .setColor(THEME.amber)
            .setAuthor({ name: `${interaction.guild.name} — Farm Yönetici Paneli`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('🛡️ Farm Yetkili Kontrol Paneli')
            .setDescription([
                ansiHeader('🛡️  FARM YETKİLİ KONTROL PANELİ', '33'),
                '',
                config.farm.yetkilimenuayarlari.mesaj,
                '',
                '⚙️ **Yetkili İşlemleri:**',
                '┣ ➕ **Farm Ekle** — Kullanıcıya farm kaydı ekleyin',
                '┣ 🔍 **Database Kontrol** — Kişinin farmlarını görüntüleyin',
                '┣ 🗑️ **Farm Sil** — Kişinin farm kaydını silin',
                '┣ 📊 **Tüm Database** — Komple database\'i görüntüleyin',
                '┗ 🔄 **Sıfırla** — Seçiminizi sıfırlayın',
                '',
                '> ⚠️ *Yaptığınız tüm işlemler log\'a kaydedilmektedir.*'
            ].join('\n'))
            .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 512 }))
            .setImage(config.mesai.ekip.photograph)
            .setFooter({ text: 'Lyuex Farm Yönetici Sistemi • Tüm işlemler kayıt altındadır', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const yetkiliMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('farm-yetkili')
                .setPlaceholder('🛡️ Yetkili işlemi seçiniz...')
                .addOptions([
                    { label: config.farm.yetkilimenuayarlari.birseceneklabel, emoji: config.farm.yetkilimenuayarlari.birsecenekemoji, description: config.farm.yetkilimenuayarlari.birsecenekaciklama, value: 'forceekle' },
                    { label: config.farm.yetkilimenuayarlari.ikiseceneklabel, emoji: config.farm.yetkilimenuayarlari.ikisecenekemoji, description: config.farm.yetkilimenuayarlari.ikisecenekaciklama, value: 'forcecheck' },
                    { label: config.farm.yetkilimenuayarlari.ucseceneklabel, emoji: config.farm.yetkilimenuayarlari.ucsecenekemoji, description: config.farm.yetkilimenuayarlari.ucsecenekaciklama, value: 'forcefarmsil' },
                    { label: config.farm.yetkilimenuayarlari.dortseceneklabel, emoji: config.farm.yetkilimenuayarlari.dortsecenekemoji, description: config.farm.yetkilimenuayarlari.dortsecenekaciklama, value: 'database-check' },
                    { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
                ])
        );

        await interaction.channel.send({ content: '||@everyone|| & ||@here||', embeds: [yetkiliEmbed], components: [yetkiliMenu] });

        await interaction.editReply({
            embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ Farm yetkili menüsü başarıyla gönderildi!\n📍 Kanal: <#${interaction.channel.id}>`)]
        });
    }
};
