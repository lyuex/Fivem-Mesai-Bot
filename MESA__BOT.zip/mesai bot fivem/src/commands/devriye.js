const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('devriye')
        .setDescription('🚓 Devriye kaydı oluştur')
        .addStringOption(opt => opt.setName('bolge').setDescription('Devriye bölgesi').setRequired(true)
            .addChoices(
                { name: '🏙️ Şehir Merkezi', value: 'Şehir Merkezi' },
                { name: '🏘️ Konut Bölgesi', value: 'Konut Bölgesi' },
                { name: '🏭 Sanayi Bölgesi', value: 'Sanayi Bölgesi' },
                { name: '🌊 Sahil/Liman', value: 'Sahil/Liman' },
                { name: '🏔️ Kırsal Alan', value: 'Kırsal Alan' },
                { name: '🛣️ Otoban/Karayolu', value: 'Otoban/Karayolu' },
                { name: '🏪 Ticaret Bölgesi', value: 'Ticaret Bölgesi' },
                { name: '🏥 Hastane Çevresi', value: 'Hastane Çevresi' },
                { name: '📋 Diğer', value: 'Diğer' }
            ))
        .addStringOption(opt => opt.setName('durum').setDescription('Devriye durumu').setRequired(true)
            .addChoices(
                { name: '✅ Sorunsuz', value: 'Sorunsuz' },
                { name: '⚠️ Şüpheli Faaliyet', value: 'Şüpheli Faaliyet' },
                { name: '🚨 Olay Müdahalesi', value: 'Olay Müdahalesi' },
                { name: '🔍 Araştırma', value: 'Araştırma' },
                { name: '🚔 Takip', value: 'Takip' }
            ))
        .addStringOption(opt => opt.setName('not').setDescription('Devriye notu / gözlemler').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'devriye', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        await interaction.deferReply();

        const bolge = interaction.options.getString('bolge');
        const durum = interaction.options.getString('durum');
        const not = interaction.options.getString('not') || 'Belirtilmedi';

        const devriyeler = policeDb.get('devriyeler') || [];
        const kayitNo = devriyeler.length + 1;

        const yeniKayit = {
            no: kayitNo,
            memurId: interaction.user.id,
            bolge,
            durum,
            not,
            tarih: moment().format('YYYY-MM-DD HH:mm:ss'),
            timestamp: Date.now()
        };

        devriyeler.push(yeniKayit);
        policeDb.set('devriyeler', devriyeler);

        const durumEmoji = { 'Sorunsuz': '✅', 'Şüpheli Faaliyet': '⚠️', 'Olay Müdahalesi': '🚨', 'Araştırma': '🔍', 'Takip': '🚔' };
        const memurDevriye = devriyeler.filter(d => d.memurId === interaction.user.id).length;

        const embed = new EmbedBuilder()
            .setColor(durum === 'Sorunsuz' ? THEME.success : durum === 'Olay Müdahalesi' ? THEME.danger : THEME.warning)
            .setAuthor({ name: `${interaction.guild.name} — Devriye Kaydı`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`🚓 Devriye #${kayitNo}`)
            .setDescription([
                ansiHeader('🚓  DEVRİYE RAPORU', '36'),
                '',
                `👮 **Görevli Memur:** <@${interaction.user.id}>`,
                `📍 **Bölge:** \`${bolge}\``,
                `${durumEmoji[durum] || '📋'} **Durum:** \`${durum}\``,
                `📝 **Gözlemler:** ${not}`,
                `📅 **Tarih:** \`${moment().format('DD.MM.YYYY HH:mm')}\``,
            ].join('\n'))
            .addFields(
                { name: '📊 Memur Devriye İstatistikleri', value: `Bu memur toplam **${memurDevriye}** devriye tamamlamıştır.`, inline: false }
            )
            .setFooter({ text: `Kayıt No: #${kayitNo} • Lyuex Devriye Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        const logChannel = findLogChannel(interaction.guild, 'devriye_log', 'polis_log', 'lyuex_log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor(durum === 'Sorunsuz' ? THEME.success : THEME.warning)
                .setDescription(ansiHeader('🚓  DEVRİYE KAYDI', '36'))
                .addFields(
                    { name: '👮 Memur', value: `<@${interaction.user.id}>`, inline: true },
                    { name: '📍 Bölge', value: `\`${bolge}\``, inline: true },
                    { name: '📋 Durum', value: `\`${durum}\``, inline: true },
                    { name: '📝 Not', value: not, inline: false }
                )
                .setFooter({ text: `#${kayitNo}` })
                .setTimestamp();
            await logChannel.send({ embeds: [logEmbed] });
        }
    }
};
