const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, progressBar, findLogChannel } = require('../utils/theme');

const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const farmDb = new JsonDatabase({ databasePath: "./src/database/farmdb.json" });
const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sicil')
        .setDescription('👮 Personel sicil kartı — rütbe, mesai, tutuklama, ceza, departman')
        .addUserOption(opt => opt.setName('kisi').setDescription('Sicilini görüntülenecek kişi (boş = kendin)').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'sicil', 5);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const targetUser = interaction.options.getUser('kisi') || interaction.user;
        const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        if (!member) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Kullanıcı sunucuda bulunamadı.')] });

        // Rütbe bilgisi
        const personel = policeDb.get(`personel.${targetUser.id}`) || {};
        const rutbeSeviye = personel.rutbe || 1;
        const departman = personel.departman || 'Atanmamış';
        const rutbeObj = (config.polis.rutbeler || []).find(r => r.seviye === rutbeSeviye);
        const rutbeIsim = rutbeObj ? rutbeObj.isim : 'Polis Memuru';
        const depObj = (config.polis.departmanlar || []).find(d => d.isim === departman);
        const depEmoji = depObj ? depObj.emoji : '🛡️';

        // Mesai verileri
        const mesaiData = mesaiDb.get(targetUser.id) || {};
        const mesailer = mesaiData.mesailer || {};
        const mesaiSayi = Object.keys(mesailer).length;
        let toplamMs = 0;
        let sonMesaiTarih = null;
        for (const m of Object.values(mesailer)) {
            if (m['giriş'] && m['çıkış']) {
                const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                if (diff > 0) toplamMs += diff;
            }
            if (m['giriş']) {
                const t = new Date(m['giriş']);
                if (!sonMesaiTarih || t > sonMesaiTarih) sonMesaiTarih = t;
            }
        }
        const toplamSaat = Math.floor(toplamMs / 3600000);
        const toplamDk = Math.floor((toplamMs % 3600000) / 60000);

        // Tutuklama sayısı
        const tutuklamalar = policeDb.get(`tutuklamalar`) || [];
        const kisiTutuklama = tutuklamalar.filter(t => t.memurId === targetUser.id);

        // Ceza sayısı
        const cezalar = policeDb.get(`cezalar`) || [];
        const kisiCeza = cezalar.filter(c => c.memurId === targetUser.id);
        const toplamCezaTutar = kisiCeza.reduce((s, c) => s + (c.miktar || 0), 0);

        // Devriye sayısı
        const devriyeler = policeDb.get(`devriyeler`) || [];
        const kisiDevriye = devriyeler.filter(d => d.memurId === targetUser.id);

        // Eğitim sayısı
        const egitimler = policeDb.get(`egitimler`) || [];
        const kisiEgitim = egitimler.filter(e => (e.katilimcilar || []).includes(targetUser.id));

        // Uyarı kontrol
        const uyariRolleri = ['1x', '2x', '3x', '4x', '5x', '1 gün wl', '2 gün wl', '3 gün wl', '5 gün wl', '7 gün wl'];
        const aktifUyarilar = member.roles.cache.filter(r => uyariRolleri.includes(r.name)).map(r => `\`${r.name}\``);

        // İzin durumu
        const izinData = mesaiDb.get(`izin.${targetUser.id}`);
        const izinDurum = izinData && moment(izinData.bitis).isAfter(moment())
            ? `📅 ${moment(izinData.bitis).format('DD.MM.YYYY')} tarihine kadar`
            : 'Aktif görevde';

        // Maaş hesap
        const saatlikUcret = config.polis?.maas?.saatlikUcret || 500;
        const paraBirimi = config.polis?.maas?.paraBirimi || '₺';
        const maas = toplamSaat * saatlikUcret;

        // Performans skoru (basit)
        const perfSkor = Math.min(100, Math.round(
            (mesaiSayi * 2) + (kisiTutuklama.length * 5) + (kisiCeza.length * 3) +
            (kisiDevriye.length * 4) + (kisiEgitim.length * 10) - (aktifUyarilar.length * 15)
        ));
        const perfBar = progressBar(Math.max(0, perfSkor), 100, 15);

        const embed = new EmbedBuilder()
            .setColor(perfSkor >= 70 ? THEME.success : perfSkor >= 40 ? THEME.warning : THEME.danger)
            .setAuthor({ name: `${interaction.guild.name} — Personel Sicil Kartı`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`👮 ${member.displayName}`)
            .setDescription([
                ansiHeader('📋  PERSONEl SİCİL KARTI', '36'),
                '',
                `**Rütbe:** \`${rutbeIsim}\` (Seviye ${rutbeSeviye}/6)`,
                `**Departman:** ${depEmoji} \`${departman}\``,
                `**Durum:** ${mesaiData.status === 'in' ? '🟢 Mesaide' : '🔴 Mesai Dışı'}`,
                `**İzin:** ${izinDurum}`,
            ].join('\n'))
            .addFields(
                { name: '🕐 Mesai Bilgileri', value: [
                    `Toplam Giriş: **${mesaiSayi}**`,
                    `Toplam Süre: **${toplamSaat}s ${toplamDk}dk**`,
                    `Son Mesai: **${sonMesaiTarih ? moment(sonMesaiTarih).format('DD.MM.YYYY HH:mm') : 'Yok'}**`,
                ].join('\n'), inline: true },
                { name: '📊 Faaliyet İstatistikleri', value: [
                    `Tutuklama: **${kisiTutuklama.length}**`,
                    `Ceza: **${kisiCeza.length}** (${toplamCezaTutar.toLocaleString('tr-TR')}${paraBirimi})`,
                    `Devriye: **${kisiDevriye.length}**`,
                    `Eğitim: **${kisiEgitim.length}**`,
                ].join('\n'), inline: true },
                { name: `📈 Performans Skoru: ${perfSkor}/100`, value: `\`${perfBar}\``, inline: false },
                { name: '⚠️ Uyarılar', value: aktifUyarilar.length > 0 ? aktifUyarilar.join(', ') : '✅ Temiz sicil', inline: true },
                { name: '💰 Hesaplanan Maaş', value: `**${maas.toLocaleString('tr-TR')}${paraBirimi}**`, inline: true }
            )
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
            .setFooter({ text: `ID: ${targetUser.id} • Lyuex Sicil Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};
