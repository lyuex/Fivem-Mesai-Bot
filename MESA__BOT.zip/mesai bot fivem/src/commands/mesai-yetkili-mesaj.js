﻿const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, PermissionFlagsBits, ActionRowBuilder } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission } = require('../utils/theme');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mesai-mesaj-yetkili')
        .setDescription('🛡️ Mesai yetkili menüsünü gönderir — Memur yönetim paneli.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'mesai-yetkili-mesaj', 30);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

        await interaction.deferReply({ ephemeral: true });

        const yetkiliEmbed = new EmbedBuilder()
            .setColor(THEME.purple)
            .setAuthor({ name: `${interaction.guild.name} — Mesai Yönetici Paneli`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('🛡️ Mesai Yetkili Kontrol Paneli')
            .setDescription([
                ansiHeader('🛡️  MESAi YÖNETİCİ PANELi', '35'),
                '',
                config.mesai.yetkilimenuayarlari.mesaj,
                '',
                '⚙️ **Yetkili İşlemleri:**',
                '┣ ➡️ **Mesaiye Sok** — Memuru zorla mesaiye sokun',
                '┣ 🔍 **Mesai Kontrol** — Memurun mesaisini kontrol edin',
                '┣ ⏏️ **Mesaiden Çıkart** — Memuru mesaiden çıkartın',
                '┣ 👥 **Aktif Mesaidekiler** — Mesaideki tüm memurlar',
                '┣ 📊 **Mesai Geçmişi** — Memurun tüm mesaileri',
                '┗ 🔄 **Sıfırla** — Seçiminizi sıfırlayın',
                '',
                '> ⚠️ *Yaptığınız işlemler kişilerin mesaisini etkiler ve log\'a kaydedilir.*'
            ].join('\n'))
            .setThumbnail(interaction.guild.iconURL({ dynamic: true, size: 512 }))
            .setImage(config.mesai.ekip.photograph)
            .setFooter({ text: 'Lyuex Mesai Yönetici Sistemi • Tüm işlemler log\'a kaydedilir', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const yetkiliMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('mesai-yetkili')
                .setPlaceholder('🛡️ Yetkili işlemi seçiniz...')
                .addOptions([
                    { label: config.mesai.yetkilimenuayarlari.birseceneklabel, emoji: config.mesai.yetkilimenuayarlari.birsecenekemoji, description: config.mesai.yetkilimenuayarlari.birsecenekaciklama, value: 'forcemesaigir' },
                    { label: config.mesai.yetkilimenuayarlari.ikiseceneklabel, emoji: config.mesai.yetkilimenuayarlari.ikisecenekemoji, description: config.mesai.yetkilimenuayarlari.ikisecenekaciklama, value: 'forcemesaicheck' },
                    { label: config.mesai.yetkilimenuayarlari.ucseceneklabel, emoji: config.mesai.yetkilimenuayarlari.ucsecenekemoji, description: config.mesai.yetkilimenuayarlari.ucsecenekaciklama, value: 'forcemesaicik' },
                    { label: config.mesai.yetkilimenuayarlari.dortseceneklabel, emoji: config.mesai.yetkilimenuayarlari.dortsecenekemoji, description: config.mesai.yetkilimenuayarlari.dortsecenekaciklama, value: 'forcemesaidekiler' },
                    { label: config.mesai.yetkilimenuayarlari.besseceneklabel, emoji: config.mesai.yetkilimenuayarlari.bessecenekemoji, description: config.mesai.yetkilimenuayarlari.bessecenekaciklama, value: 'forcemesailer' },
                    { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
                ])
        );

        await interaction.channel.send({ content: '||@everyone|| & ||@here||', embeds: [yetkiliEmbed], components: [yetkiliMenu] });

        await interaction.editReply({
            embeds: [new EmbedBuilder().setColor(THEME.success).setDescription(`✅ Mesai yetkili menüsü başarıyla gönderildi!\n📍 Kanal: <#${interaction.channel.id}>`)]
        });
    }
};
