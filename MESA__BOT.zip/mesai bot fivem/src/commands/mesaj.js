﻿const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionFlagsBits, ChannelType, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission } = require('../utils/theme');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mesaj')
    .setDescription('📨 Bot aracılığıyla profesyonel embed mesajı & menü gönderir.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(option =>
      option.setName('channel').setDescription('Mesajın gönderileceği kanal.').setRequired(true).addChannelTypes(ChannelType.GuildText)
    )
    .addStringOption(option =>
      option.setName('title').setDescription('Embed başlığı.').setRequired(true)
    )
    .addStringOption(option =>
      option.setName('description').setDescription('Embed açıklaması.').setRequired(true)
    )
    .addStringOption(option =>
      option.setName('image').setDescription('Embed resmi (URL).').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('content').setDescription('Embed üstü metin (@everyone / @here).').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('mesaimenusu').setDescription('Memur mesai menüsü ekle.').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('yetkilimesaimenusu').setDescription('Yetkili mesai menüsü ekle.').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('illegalmenu').setDescription('Farm kayıt menüsü ekle.').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('illegalyetkilimenusu').setDescription('Farm yetkili menüsü ekle.').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('basvurubutonu').setDescription('Ekip başvuru butonu ekle.').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('color').setDescription('Embed rengi (HEX).').setRequired(false)
    )
    .addStringOption(option =>
      option.setName('footer').setDescription('Embed alt yazısı.').setRequired(false)
    ),

  async execute(interaction) {
    const cd = checkCooldown(interaction.user.id, 'mesaj', 15);
    if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ Bu komutu **${cd}sn** sonra tekrar kullanabilirsiniz.`)], ephemeral: true });

    await interaction.deferReply({ ephemeral: true });

    try {
      const { guild, options } = interaction;
      const channel = options.getChannel('channel');
      const title = options.getString('title');
      const description = options.getString('description');
      const image = options.getString('image');
      const color = options.getString('color') || THEME.primary;
      const embedfooter = options.getString('footer');
      const content = options.getString('content');
      const mesaimenusu = options.getString('mesaimenusu');
      const yetkilimesaimenusu = options.getString('yetkilimesaimenusu');
      const basvurubutonu = options.getString('basvurubutonu');
      const illegalmenu = options.getString('illegalmenu');
      const yetkiliillegalmenusu = options.getString('illegalyetkilimenusu');

      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setTimestamp();

      if (image) embed.setImage(image);
      if (embedfooter) embed.setFooter({ text: embedfooter, iconURL: interaction.client.user.displayAvatarURL() });

      const components = [];

      if (mesaimenusu) {
        components.push(new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mesai-olustur')
            .setPlaceholder(config.mesai.menuayarlari.menuplaceholder)
            .addOptions([
              { label: config.mesai.menuayarlari.birseceneklabel, emoji: config.mesai.menuayarlari.birsecenekemoji, description: config.mesai.menuayarlari.birsecenekaciklama, value: 'mesaigir' },
              { label: config.mesai.menuayarlari.ikiseceneklabel, emoji: config.mesai.menuayarlari.ikisecenekemoji, description: config.mesai.menuayarlari.ikisecenekaciklama, value: 'mesaicheck' },
              { label: config.mesai.menuayarlari.ucseceneklabel, emoji: config.mesai.menuayarlari.ucsecenekemoji, description: config.mesai.menuayarlari.ucsecenekaciklama, value: 'mesaicik' },
              { label: config.mesai.menuayarlari.dortseceneklabel, emoji: config.mesai.menuayarlari.dortsecenekemoji, description: config.mesai.menuayarlari.dortsecenekaciklama, value: 'mesailerim' },
              { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
            ])
        ));
      }

      if (yetkilimesaimenusu) {
        components.push(new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mesai-yetkili')
            .setPlaceholder(config.mesai.yetkilimenuayarlari.menuplaceholder)
            .addOptions([
              { label: config.mesai.yetkilimenuayarlari.birseceneklabel, emoji: config.mesai.yetkilimenuayarlari.birsecenekemoji, description: config.mesai.yetkilimenuayarlari.birsecenekaciklama, value: 'forcemesaigir' },
              { label: config.mesai.yetkilimenuayarlari.ikiseceneklabel, emoji: config.mesai.yetkilimenuayarlari.ikisecenekemoji, description: config.mesai.yetkilimenuayarlari.ikisecenekaciklama, value: 'forcemesaicheck' },
              { label: config.mesai.yetkilimenuayarlari.ucseceneklabel, emoji: config.mesai.yetkilimenuayarlari.ucsecenekemoji, description: config.mesai.yetkilimenuayarlari.ucsecenekaciklama, value: 'forcemesaicik' },
              { label: config.mesai.yetkilimenuayarlari.dortseceneklabel, emoji: config.mesai.yetkilimenuayarlari.dortsecenekemoji, description: config.mesai.yetkilimenuayarlari.dortsecenekaciklama, value: 'forcemesaidekiler' },
              { label: config.mesai.yetkilimenuayarlari.besseceneklabel, emoji: config.mesai.yetkilimenuayarlari.bessecenekemoji, description: config.mesai.yetkilimenuayarlari.bessecenekaciklama, value: 'forcemesailer' },
              { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
            ])
        ));
      }

      if (basvurubutonu) {
        components.push(new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('Lyuexinmodali')
            .setEmoji(config.mesai.menuayarlari.birsecenekemoji)
            .setLabel('📝 Ekip Başvurusu')
            .setStyle(ButtonStyle.Primary)
        ));
      }

      if (illegalmenu) {
        components.push(new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('farm-olustur')
            .setPlaceholder(config.farm.menuayarlari.menuplaceholder)
            .addOptions([
              { label: config.farm.menuayarlari.birseceneklabel, emoji: config.farm.menuayarlari.birsecenekemoji, description: config.farm.menuayarlari.birsecenekaciklama, value: 'farmkontrol' },
              { label: config.farm.farmlar.Otlabel, emoji: config.farm.farmlar.otemoji, description: config.farm.farmlar.otaciklama, value: 'otekle' },
              { label: config.farm.farmlar.kokainlabel, emoji: config.farm.farmlar.kokainemoji, description: config.farm.farmlar.kokainaciklama, value: 'kokainekle' },
              { label: config.farm.farmlar.methlabel, emoji: config.farm.farmlar.methemoji, description: config.farm.farmlar.methaciklama, value: 'methekle' },
              { label: config.farm.farmlar.karaparalabel, emoji: config.farm.farmlar.karaparaemoji, description: config.farm.farmlar.karaparaaciklama, value: 'karaparaekle' },
              { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
            ])
        ));
      }

      if (yetkiliillegalmenusu) {
        components.push(new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('farm-yetkili')
            .setPlaceholder(config.farm.yetkilimenuayarlari.menuplaceholder)
            .addOptions([
              { label: config.farm.yetkilimenuayarlari.birseceneklabel, emoji: config.farm.yetkilimenuayarlari.birsecenekemoji, description: config.farm.yetkilimenuayarlari.birsecenekaciklama, value: 'forceekle' },
              { label: config.farm.yetkilimenuayarlari.ikiseceneklabel, emoji: config.farm.yetkilimenuayarlari.ikisecenekemoji, description: config.farm.yetkilimenuayarlari.ikisecenekaciklama, value: 'forcecheck' },
              { label: config.farm.yetkilimenuayarlari.ucseceneklabel, emoji: config.farm.yetkilimenuayarlari.ucsecenekemoji, description: config.farm.yetkilimenuayarlari.ucsecenekaciklama, value: 'forcefarmsil' },
              { label: config.farm.yetkilimenuayarlari.dortseceneklabel, emoji: config.farm.yetkilimenuayarlari.dortsecenekemoji, description: config.farm.yetkilimenuayarlari.dortsecenekaciklama, value: 'database-check' },
              { label: '🔄 Seçenek Sıfırla', description: 'Menüdeki seçeneğinizi sıfırlarsınız.', emoji: '1487953387650547773', value: 'sifirla' }
            ])
        ));
      }

      // Önizleme göster
      const addedParts = [
        mesaimenusu && '📋 Mesai Menüsü',
        yetkilimesaimenusu && '🛡️ Yetkili Mesai Menüsü',
        illegalmenu && '🌿 Farm Menüsü',
        yetkiliillegalmenusu && '⚙️ Farm Yetkili Menüsü',
        basvurubutonu && '📝 Başvuru Butonu'
      ].filter(Boolean);

      const previewEmbed = new EmbedBuilder()
        .setColor(THEME.warning)
        .setTitle('👁️ Mesaj Önizleme')
        .setDescription([
          ansiHeader('📨  MESAJ ÖNİZLEME', '33'),
          '',
          `📍 **Hedef Kanal:** <#${channel.id}>`,
          `📝 **Başlık:** ${title}`,
          `📄 **Açıklama:** ${description.length > 100 ? description.substring(0, 100) + '...' : description}`,
          image ? `🖼️ **Resim:** Evet` : '',
          addedParts.length > 0 ? `📦 **Bileşenler:** ${addedParts.join(', ')}` : '',
          '',
          '> Bu mesajı göndermek istiyor musunuz?'
        ].filter(Boolean).join('\n'))
        .setFooter({ text: 'Lyuex Mesaj Sistemi • 30 saniye içinde onaylayın' })
        .setTimestamp();

      const confirmRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('mesaj_gonder').setLabel('Gönder').setEmoji('✅').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('mesaj_iptal').setLabel('İptal').setEmoji('❌').setStyle(ButtonStyle.Secondary)
      );

      await interaction.editReply({ embeds: [previewEmbed], components: [confirmRow] });

      try {
        const btn = await interaction.channel.awaitMessageComponent({
          filter: i => i.user.id === interaction.user.id && ['mesaj_gonder', 'mesaj_iptal'].includes(i.customId),
          time: 30_000
        });
        await btn.deferUpdate();

        if (btn.customId === 'mesaj_iptal') {
          return interaction.editReply({
            embeds: [new EmbedBuilder().setColor(THEME.dark).setDescription('❌ Mesaj gönderimi iptal edildi.')],
            components: []
          });
        }
      } catch {
        return interaction.editReply({
          embeds: [new EmbedBuilder().setColor(THEME.dark).setDescription('⏰ Onay süresi doldu, mesaj gönderilmedi.')],
          components: []
        });
      }

      await channel.send({ content: content || null, embeds: [embed], components });

      await interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor(THEME.success)
          .setDescription([
            `✅ Mesaj başarıyla gönderildi!`,
            `📍 **Kanal:** <#${channel.id}>`,
            addedParts.length > 0 ? `📦 **Bileşenler:** ${addedParts.join(', ')}` : ''
          ].filter(Boolean).join('\n'))
        ],
        components: []
      });
    } catch (err) {
      console.error('[MESAJ HATASI]', err);
      await interaction.editReply({
        embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription(`❌ Mesaj gönderilemedi!\n\`\`\`${err.message}\`\`\``)],
        components: []
      });
    }
  },
};