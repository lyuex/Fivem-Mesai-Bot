const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('departman')
        .setDescription('🏢 Personel departman/birim atama')
        .addSubcommand(sub =>
            sub.setName('ata')
                .setDescription('Personele departman ata')
                .addUserOption(opt => opt.setName('kisi').setDescription('Personel').setRequired(true))
                .addStringOption(opt => opt.setName('birim').setDescription('Departman seçin').setRequired(true)
                    .addChoices(
                        { name: '🛡️ Genel Asayiş', value: 'Genel Asayiş' },
                        { name: '🚔 Trafik', value: 'Trafik' },
                        { name: '💊 Narkotik', value: 'Narkotik' },
                        { name: '🔫 SWAT', value: 'SWAT' },
                        { name: '🔍 Dedektif', value: 'Dedektif' }
                    ))
        )
        .addSubcommand(sub =>
            sub.setName('liste')
                .setDescription('Departman listesini görüntüle')
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();
        const isEphemeral = sub === 'liste';
        await interaction.deferReply({ flags: isEphemeral ? MessageFlags.Ephemeral : undefined });

        const cd = checkCooldown(interaction.user.id, 'departman', 10);
        if (cd) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)] });

        if (sub === 'ata') {
            if (!checkPermission(interaction, config)) {
                return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')] });
            }

            const user = interaction.options.getUser('kisi');
            const birim = interaction.options.getString('birim');
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            if (!member) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('❌ Kullanıcı bulunamadı.')] });

            const personel = policeDb.get(`personel.${user.id}`) || {};
            const eskiDep = personel.departman || 'Atanmamış';
            const departmanlar = config.polis?.departmanlar || [];
            const depObj = departmanlar.find(d => d.isim === birim);

            // Eski departman rolünü kaldır
            for (const d of departmanlar) {
                const role = interaction.guild.roles.cache.get(d.rol);
                if (role && member.roles.cache.has(role.id)) {
                    await member.roles.remove(role).catch(() => {});
                }
            }

            // Yeni departman rolünü ekle
            if (depObj) {
                const newRole = interaction.guild.roles.cache.get(depObj.rol);
                if (newRole) await member.roles.add(newRole).catch(() => {});
            }

            policeDb.set(`personel.${user.id}`, { ...personel, departman: birim });

            const embed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setAuthor({ name: `${interaction.guild.name} — Departman Ataması`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTitle(`${depObj?.emoji || '🏢'} Departman Değişikliği`)
                .setDescription([
                    ansiHeader('🏢  DEPARTMAN ATAMASI', '36'),
                    '',
                    `👤 **Personel:** <@${user.id}>`,
                    `👮 **Yetkili:** <@${interaction.user.id}>`,
                    '',
                    `📉 **Eski Departman:** \`${eskiDep}\``,
                    `📈 **Yeni Departman:** ${depObj?.emoji || '🏢'} \`${birim}\``,
                ].join('\n'))
                .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ text: 'Lyuex Departman Sistemi' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            // Log
            const logChannel = findLogChannel(interaction.guild, 'polis_log', 'lyuex_log');
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setColor(THEME.primary)
                    .setDescription(ansiHeader('🏢  DEPARTMAN DEĞİŞİKLİĞİ', '36'))
                    .addFields(
                        { name: '👤 Personel', value: `<@${user.id}>`, inline: true },
                        { name: '📋 Değişiklik', value: `\`${eskiDep}\` → \`${birim}\``, inline: true },
                        { name: '👮 Yetkili', value: `<@${interaction.user.id}>`, inline: true }
                    )
                    .setTimestamp();
                await logChannel.send({ embeds: [logEmbed] });
            }
        }

        if (sub === 'liste') {
            const allPersonel = policeDb.get('personel') || {};
            const departmanlar = config.polis?.departmanlar || [];
            const rutbeler = config.polis?.rutbeler || [];

            const gruplar = {};
            for (const [userId, data] of Object.entries(allPersonel)) {
                const dep = data.departman || 'Genel Asayiş';
                if (!gruplar[dep]) gruplar[dep] = [];
                gruplar[dep].push({ userId, rutbe: data.rutbe || 1 });
            }

            const desc = departmanlar.map(d => {
                const members = gruplar[d.isim] || [];
                members.sort((a, b) => b.rutbe - a.rutbe);
                const memberStr = members.length > 0
                    ? members.slice(0, 8).map(m => {
                        const r = rutbeler.find(rt => rt.seviye === m.rutbe);
                        return `  <@${m.userId}> — \`${r?.isim || 'Memur'}\``;
                    }).join('\n') + (members.length > 8 ? `\n  > ... +${members.length - 8} kişi` : '')
                    : '  *Personel yok*';
                return `${d.emoji} **${d.isim}** [\`${d.kisa}\`] — ${members.length} kişi\n${memberStr}`;
            }).join('\n\n');

            const embed = new EmbedBuilder()
                .setColor(THEME.primary)
                .setTitle('🏢 Departman Listesi')
                .setDescription(desc || 'Kayıtlı personel yok.')
                .setFooter({ text: `Toplam ${Object.keys(allPersonel).length} personel` })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }
};
