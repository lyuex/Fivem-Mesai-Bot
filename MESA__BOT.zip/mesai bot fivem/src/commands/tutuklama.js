const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { JsonDatabase } = require('for.db');
const moment = require('moment');
const config = require('../../lyuex.json');
const { THEME, ansiHeader, checkCooldown, checkPermission, findLogChannel } = require('../utils/theme');

const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tutuklama')
        .setDescription('🚔 Tutuklama kaydı oluştur')
        .addStringOption(opt => opt.setName('supheli').setDescription('Şüphelinin ismi/ID').setRequired(true))
        .addStringOption(opt => opt.setName('suc').setDescription('İşlenen suç').setRequired(true)
            .addChoices(
                { name: '🔫 Silahlı Saldırı', value: 'Silahlı Saldırı' },
                { name: '💊 Uyuşturucu Bulundurma', value: 'Uyuşturucu Bulundurma' },
                { name: '💰 Uyuşturucu Ticareti', value: 'Uyuşturucu Ticareti' },
                { name: '🚗 Araç Hırsızlığı', value: 'Araç Hırsızlığı' },
                { name: '🏠 Soygun', value: 'Soygun' },
                { name: '👊 Darp', value: 'Darp' },
                { name: '🔪 Tehdit', value: 'Tehdit' },
                { name: '🚔 Memura Mukavemet', value: 'Memura Mukavemet' },
                { name: '🏃 Kaçış', value: 'Polisten Kaçış' },
                { name: '📋 Diğer', value: 'Diğer' }
            ))
        .addStringOption(opt => opt.setName('detay').setDescription('Ek detaylar / kanıt açıklaması').setRequired(false))
        .addStringOption(opt => opt.setName('bolge').setDescription('Olay bölgesi').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const cd = checkCooldown(interaction.user.id, 'tutuklama', 10);
        if (cd) return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription(`⏳ **${cd}sn** bekleyin.`)], ephemeral: true });

        if (!checkPermission(interaction, config)) {
            return interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('🔒 Bu komutu kullanma yetkiniz yok.')], ephemeral: true });
        }

        await interaction.deferReply();

        const supheli = interaction.options.getString('supheli');
        const suc = interaction.options.getString('suc');
        const detay = interaction.options.getString('detay') || 'Belirtilmedi';
        const bolge = interaction.options.getString('bolge') || 'Belirtilmedi';

        const tutuklamalar = policeDb.get('tutuklamalar') || [];
        const kayitNo = tutuklamalar.length + 1;

        const yeniKayit = {
            no: kayitNo,
            memurId: interaction.user.id,
            supheli,
            suc,
            detay,
            bolge,
            tarih: moment().format('YYYY-MM-DD HH:mm:ss'),
            timestamp: Date.now()
        };

        tutuklamalar.push(yeniKayit);
        policeDb.set('tutuklamalar', tutuklamalar);

        const embed = new EmbedBuilder()
            .setColor(THEME.danger)
            .setAuthor({ name: `${interaction.guild.name} — Tutuklama Kaydı`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle(`🚔 Tutuklama #${kayitNo}`)
            .setDescription([
                ansiHeader('🚔  TUTUKLAMA RAPORU', '31'),
                '',
                `👮 **Görevli Memur:** <@${interaction.user.id}>`,
                `👤 **Şüpheli:** \`${supheli}\``,
                `⚖️ **Suç:** \`${suc}\``,
                `📍 **Bölge:** \`${bolge}\``,
                `📋 **Detay:** ${detay}`,
                `📅 **Tarih:** \`${moment().format('DD.MM.YYYY HH:mm')}\``,
            ].join('\n'))
            .addFields(
                { name: '📊 Memur İstatistikleri', value: `Bu memur toplam **${tutuklamalar.filter(t => t.memurId === interaction.user.id).length}** tutuklama yapmıştır.`, inline: false }
            )
            .setFooter({ text: `Kayıt No: #${kayitNo} • Lyuex Tutuklama Sistemi` })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });

        // Log kanalına gönder
        const logChannel = findLogChannel(interaction.guild, 'tutuklama_log', 'polis_log', 'lyuex_log');
        if (logChannel) {
            const logEmbed = new EmbedBuilder()
                .setColor(THEME.danger)
                .setAuthor({ name: 'Tutuklama Kaydı', iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setDescription(ansiHeader('🚔  YENİ TUTUKLAMA', '31'))
                .addFields(
                    { name: '👮 Memur', value: `<@${interaction.user.id}>`, inline: true },
                    { name: '👤 Şüpheli', value: `\`${supheli}\``, inline: true },
                    { name: '⚖️ Suç', value: `\`${suc}\``, inline: true },
                    { name: '📍 Bölge', value: `\`${bolge}\``, inline: true },
                    { name: '📋 Detay', value: detay, inline: false }
                )
                .setFooter({ text: `#${kayitNo}` })
                .setTimestamp();
            await logChannel.send({ embeds: [logEmbed] });
        }
    }
};
