// ═══════════════════════════════════════════════
//  Lyuex Bot — Merkezi Tema & Yardımcı Araçlar
// ═══════════════════════════════════════════════

const { EmbedBuilder } = require('discord.js');

/** Merkezi renk paleti */
const THEME = Object.freeze({
    primary:  '#5865F2',
    success:  '#57F287',
    danger:   '#ED4245',
    warning:  '#FEE75C',
    gold:     '#F1C40F',
    cyan:     '#00BCD4',
    purple:   '#9B59B6',
    emerald:  '#2ECC71',
    amber:    '#FF8C00',
    blue:     '#3498DB',
    party:    '#E91E63',
    dark:     '#2B2D31',
    orange:   '#FF6B35',
});

/** ANSI kutu başlığı oluşturur */
function ansiHeader(text, colorCode = '37') {
    const padded = text.padEnd(42);
    return [
        '```ansi',
        `\u001b[1;${colorCode}m╔══════════════════════════════════════════════╗`,
        `\u001b[1;${colorCode}m║  \u001b[1;37m${padded}\u001b[1;${colorCode}m║`,
        `\u001b[1;${colorCode}m╚══════════════════════════════════════════════╝`,
        '```'
    ].join('\n');
}

/** İlerleme çubuğu oluşturur (0-1 arası) */
function progressBar(value, max, length = 20) {
    const ratio = max > 0 ? value / max : 0;
    const filled = Math.round(ratio * length);
    return '█'.repeat(filled) + '░'.repeat(length - filled);
}

/** Standart hata embedi */
function errorEmbed(message) {
    return new EmbedBuilder()
        .setColor(THEME.danger)
        .setDescription(`❌ ${message}`)
        .setTimestamp();
}

/** Standart başarı embedi */
function successEmbed(message) {
    return new EmbedBuilder()
        .setColor(THEME.success)
        .setDescription(`✅ ${message}`)
        .setTimestamp();
}

/** Yetki kontrolü */
function checkPermission(interaction, config) {
    return interaction.member.roles.cache.some(r => config.rol.yonetici.includes(r.id));
}

/** Süre formatlayıcı (saniye → okunabilir) */
function formatDuration(seconds) {
    if (seconds >= 86400) return `${Math.floor(seconds / 86400)}g ${Math.floor((seconds % 86400) / 3600)}s`;
    if (seconds >= 3600) return `${Math.floor(seconds / 3600)}s ${Math.floor((seconds % 3600) / 60)}dk`;
    if (seconds >= 60) return `${Math.floor(seconds / 60)}dk ${seconds % 60}sn`;
    return `${seconds}sn`;
}

/** Cooldown yöneticisi */
const cooldowns = new Map();

function checkCooldown(userId, commandName, seconds = 5) {
    const key = `${userId}-${commandName}`;
    const now = Date.now();
    const expiry = cooldowns.get(key);
    if (expiry && now < expiry) {
        return Math.ceil((expiry - now) / 1000);
    }
    cooldowns.set(key, now + (seconds * 1000));
    return 0;
}

/** Log kanalı bulucu */
function findLogChannel(guild, ...names) {
    for (const name of names) {
        const ch = guild.channels.cache.find(c => c.name === name);
        if (ch) return ch;
    }
    return null;
}

module.exports = {
    THEME,
    ansiHeader,
    progressBar,
    errorEmbed,
    successEmbed,
    checkPermission,
    formatDuration,
    checkCooldown,
    findLogChannel,
};
