// ═══════════════════════════════════════════════
//  Lyuex Bot — Merkezi Sabit Değerler
// ═══════════════════════════════════════════════

module.exports = Object.freeze({
    EMOJI_ID: '1487953387650547773',
    LEADERBOARD_UPDATE_MS: 900_000,         // 15 dakika
    BACKUP_INTERVAL_MS: 3_600_000,          // 1 saat
    INACTIVITY_DAYS: 7,                     // 7 gün mesaiye girmeyince inaktif
    MAX_FARM_VALUE: 999,
    COLLECTOR_TIMEOUT_MS: 120_000,          // 2 dakika
    FOURTEEN_DAYS_MS: 14 * 24 * 60 * 60 * 1000,
    WEEKLY_REPORT_DAY: 0,                   // 0 = Pazar
    WEEKLY_REPORT_HOUR: 21,                 // 21:00
    VOICE_SAVE_INTERVAL_MS: 300_000,        // 5 dakika
    LEADERBOARD_PAGE_SIZE: 10,
});
