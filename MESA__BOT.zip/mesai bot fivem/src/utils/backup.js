// ═══════════════════════════════════════════════
//  Lyuex Bot — Otomatik Veritabanı Yedekleme
// ═══════════════════════════════════════════════

const fs = require('fs');
const path = require('path');
const { BACKUP_INTERVAL_MS } = require('./constants');

const DB_FILES = [
    './src/database/fordb.json',
    './src/database/farmdb.json',
    './src/database/lyuex_database.json',
];

const BACKUP_DIR = './src/database/backups';

function createBackup() {
    try {
        if (!fs.existsSync(BACKUP_DIR)) {
            fs.mkdirSync(BACKUP_DIR, { recursive: true });
        }

        const now = new Date();
        const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}`;
        let backed = 0;

        for (const file of DB_FILES) {
            if (!fs.existsSync(file)) continue;
            const name = path.basename(file, '.json');
            const dest = path.join(BACKUP_DIR, `${name}_${timestamp}.json`);
            fs.copyFileSync(file, dest);
            backed++;
        }

        cleanOldBackups(7);
        console.log(`[Backup] ${backed} veritabanı yedeklendi.`);
    } catch (error) {
        console.error('[Backup] Yedekleme hatası:', error.message);
    }
}

function cleanOldBackups(days) {
    if (!fs.existsSync(BACKUP_DIR)) return;
    const now = Date.now();
    const maxAge = days * 24 * 60 * 60 * 1000;

    for (const file of fs.readdirSync(BACKUP_DIR)) {
        const filePath = path.join(BACKUP_DIR, file);
        const stat = fs.statSync(filePath);
        if (now - stat.mtimeMs > maxAge) {
            fs.unlinkSync(filePath);
        }
    }
}

function startAutoBackup() {
    createBackup();
    setInterval(createBackup, BACKUP_INTERVAL_MS);
    console.log(`[Backup] Otomatik yedekleme aktif (her ${BACKUP_INTERVAL_MS / 60000} dakikada bir)`);
}

module.exports = { createBackup, cleanOldBackups, startAutoBackup };
