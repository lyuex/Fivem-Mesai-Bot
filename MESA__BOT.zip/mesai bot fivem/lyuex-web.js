﻿require('dotenv').config();
const { Partials, Client, GatewayIntentBits } = require("discord.js");
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { JsonDatabase } = require('for.db');
const Lyuex = require("./lyuex.json");

const farmDb = new JsonDatabase({ databasePath: "./src/database/farmdb.json" });
const mesaiDb = new JsonDatabase({ databasePath: "./src/database/fordb.json" });
const policeDb = new JsonDatabase({ databasePath: "./src/database/policedb.json" });

const app = express();
const port = 8080;
const botStartTime = Date.now();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageTyping
    ],
    partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});
client.login(process.env.BOT_TOKEN || Lyuex.botSettings.token);

app.use(express.json());
app.use(cors());
app.use('/assets', express.static(path.join(__dirname, 'src/views/assets')));

// ══════════════════════════════════════
//  API — Genel İstatistikler
// ══════════════════════════════════════
app.get('/api/stats', (req, res) => {
    const farmData = farmDb.get('farm') || {};
    const mesaiRaw = mesaiDb.toJSON() || {};

    const farmUserCount = Object.keys(farmData).length;
    const mesaiUserCount = Object.keys(mesaiRaw).length;
    const activeMesai = Object.values(mesaiRaw).filter(u => u.status === 'in').length;

    let totalOt = 0, totalKokain = 0, totalMeth = 0, totalKarapara = 0;
    for (const u of Object.values(farmData)) {
        totalOt += u.ot || 0;
        totalKokain += u.kokain || 0;
        totalMeth += u.meth || 0;
        totalKarapara += u.karapara || 0;
    }

    let totalMesaiSure = 0, totalMesaiSayi = 0;
    for (const u of Object.values(mesaiRaw)) {
        if (u.mesailer) {
            for (const m of Object.values(u.mesailer)) {
                totalMesaiSayi++;
                if (m['giriş'] && m['çıkış']) {
                    const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                    if (diff > 0) totalMesaiSure += diff;
                }
            }
        }
    }

    const guild = client.guilds.cache.get(Lyuex.botSettings.ServerID);

    res.json({
        bot: {
            uptime: Date.now() - botStartTime,
            ping: client.ws.ping,
            serverName: guild?.name || 'Bilinmiyor',
            memberCount: guild?.memberCount || 0,
            channelCount: guild?.channels.cache.size || 0,
            status: client.ws.status === 0 ? 'online' : 'offline'
        },
        farm: {
            userCount: farmUserCount,
            totalOt, totalKokain, totalMeth, totalKarapara
        },
        mesai: {
            userCount: mesaiUserCount,
            activeMesai,
            totalMesaiSayi,
            totalMesaiSure
        }
    });
});

// ══════════════════════════════════════
//  API — Dashboard (Tüm Veriler)
// ══════════════════════════════════════
app.get('/api/dashboard', (req, res) => {
    const guild = client.guilds.cache.get(Lyuex.botSettings.ServerID);
    const farmData = farmDb.get('farm') || {};
    const mesaiRaw = mesaiDb.toJSON() || {};
    const personelRaw = policeDb.get('personel') || {};
    const tutuklamalar = policeDb.get('tutuklamalar') || [];
    const cezalar = policeDb.get('cezalar') || [];
    const devriyeler = policeDb.get('devriyeler') || [];
    const egitimler = policeDb.get('egitimler') || [];
    const raporlar = policeDb.get('olayRaporlari') || [];
    const rutbeler = Lyuex.polis?.rutbeler || [];
    const departmanlar = Lyuex.polis?.departmanlar || [];
    const maasConfig = Lyuex.polis?.maas || { saatlikUcret: 500, paraBirimi: '₺' };

    // ── Bot ──
    const bot = {
        uptime: Date.now() - botStartTime,
        ping: client.ws.ping,
        serverName: guild?.name || 'Bilinmiyor',
        memberCount: guild?.memberCount || 0,
        channelCount: guild?.channels.cache.size || 0,
        roleCount: guild?.roles.cache.size || 0,
        status: client.ws.status === 0 ? 'online' : 'offline'
    };

    // ── Mesai ──
    let mesaiKullanici = 0, aktivMesai = 0, toplamMesaiMs = 0, toplamMesaiGiris = 0;
    const mesaiTop = [];
    const aktivPersonel = [];
    for (const [userId, userData] of Object.entries(mesaiRaw)) {
        if (userId.length < 15) continue;
        mesaiKullanici++;
        if (userData.status === 'in') { aktivMesai++; aktivPersonel.push(userId); }
        let userMs = 0, userGiris = 0;
        if (userData.mesailer) {
            for (const m of Object.values(userData.mesailer)) {
                userGiris++;
                toplamMesaiGiris++;
                if (m['giriş'] && m['çıkış']) {
                    const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                    if (diff > 0) { toplamMesaiMs += diff; userMs += diff; }
                }
            }
        }
        if (userMs > 0) mesaiTop.push({ userId, saat: +(userMs / 3600000).toFixed(1), giris: userGiris, status: userData.status || 'out' });
    }
    mesaiTop.sort((a, b) => b.saat - a.saat);

    // ── Farm ──
    let totalOt = 0, totalKokain = 0, totalMeth = 0, totalKarapara = 0;
    const farmTop = [];
    for (const [userId, u] of Object.entries(farmData)) {
        const ot = u.ot || 0, kokain = u.kokain || 0, meth = u.meth || 0, karapara = u.karapara || 0;
        totalOt += ot; totalKokain += kokain; totalMeth += meth; totalKarapara += karapara;
        farmTop.push({ userId, ot, kokain, meth, karapara, toplam: ot + kokain + meth + karapara });
    }
    farmTop.sort((a, b) => b.toplam - a.toplam);

    // ── Polis ──
    const toplamCezaMiktar = cezalar.reduce((s, c) => s + (c.miktar || 0), 0);

    // Rütbe dağılımı
    const rutbeDag = {};
    for (const p of Object.values(personelRaw)) {
        const r = rutbeler.find(rt => rt.seviye === (p.rutbe || 1));
        const isim = r?.isim || 'Polis Memuru';
        rutbeDag[isim] = (rutbeDag[isim] || 0) + 1;
    }

    // Departman dağılımı
    const depDag = {};
    for (const p of Object.values(personelRaw)) {
        const dep = p.departman || 'Atanmamış';
        depDag[dep] = (depDag[dep] || 0) + 1;
    }

    // Suç dağılımı
    const sucDag = {};
    for (const t of tutuklamalar) sucDag[t.suc] = (sucDag[t.suc] || 0) + 1;

    // Top memurlar
    const memurStats = {};
    for (const t of tutuklamalar) { memurStats[t.memurId] = memurStats[t.memurId] || { t: 0, c: 0, d: 0 }; memurStats[t.memurId].t++; }
    for (const c of cezalar) { memurStats[c.memurId] = memurStats[c.memurId] || { t: 0, c: 0, d: 0 }; memurStats[c.memurId].c++; }
    for (const d of devriyeler) { memurStats[d.memurId] = memurStats[d.memurId] || { t: 0, c: 0, d: 0 }; memurStats[d.memurId].d++; }
    const topMemurlar = Object.entries(memurStats)
        .map(([id, s]) => ({ userId: id, tutuklama: s.t, ceza: s.c, devriye: s.d, toplam: s.t + s.c + s.d }))
        .sort((a, b) => b.toplam - a.toplam).slice(0, 10);

    // Son 7 gün
    const gunlukAktivite = [];
    for (let i = 6; i >= 0; i--) {
        const gun = new Date(); gun.setDate(gun.getDate() - i);
        const gunStr = gun.toISOString().slice(0, 10);
        gunlukAktivite.push({
            tarih: gunStr,
            tutuklama: tutuklamalar.filter(t => t.tarih?.startsWith(gunStr)).length,
            ceza: cezalar.filter(c => c.tarih?.startsWith(gunStr)).length,
            devriye: devriyeler.filter(d => d.tarih?.startsWith(gunStr)).length
        });
    }

    // Son işlemler (tüm kayıtlardan son 10)
    const sonIslemler = [
        ...tutuklamalar.slice(-5).reverse().map(t => ({ tip: 'tutuklama', tarih: t.tarih, detay: `${t.supheli} — ${t.suc}`, memur: t.memurId })),
        ...cezalar.slice(-5).reverse().map(c => ({ tip: 'ceza', tarih: c.tarih, detay: `${c.kisi} — ${c.tur} (${c.miktar}${maasConfig.paraBirimi})`, memur: c.memurId })),
        ...devriyeler.slice(-5).reverse().map(d => ({ tip: 'devriye', tarih: d.tarih, detay: `${d.bolge} — ${d.durum}`, memur: d.memurId })),
    ].sort((a, b) => new Date(b.tarih) - new Date(a.tarih)).slice(0, 10);

    res.json({
        bot,
        mesai: {
            kullanici: mesaiKullanici,
            aktif: aktivMesai,
            aktivPersonel: aktivPersonel.slice(0, 10),
            toplamGiris: toplamMesaiGiris,
            toplamSaat: +(toplamMesaiMs / 3600000).toFixed(1),
            top10: mesaiTop.slice(0, 10)
        },
        farm: {
            kullanici: Object.keys(farmData).length,
            toplamOt: totalOt, toplamKokain: totalKokain, toplamMeth: totalMeth, toplamKarapara: totalKarapara,
            genel: totalOt + totalKokain + totalMeth + totalKarapara,
            top10: farmTop.slice(0, 10)
        },
        polis: {
            personelSayisi: Object.keys(personelRaw).length,
            toplamTutuklama: tutuklamalar.length,
            toplamCeza: cezalar.length,
            toplamCezaMiktar,
            toplamDevriye: devriyeler.length,
            toplamEgitim: egitimler.length,
            toplamRapor: raporlar.length,
            paraBirimi: maasConfig.paraBirimi,
            rutbeDagilimi: rutbeDag,
            departmanDagilimi: depDag,
            sucDagilimi: sucDag,
            topMemurlar,
            gunlukAktivite,
            sonIslemler
        }
    });
});

// ══════════════════════════════════════
//  API — Farm Leaderboard
// ══════════════════════════════════════
app.get('/api/farm', (req, res) => {
    const allData = farmDb.get('farm') || {};
    const userTotals = [];

    for (const [userId, userData] of Object.entries(allData)) {
        const toplam = (userData.ot || 0) + (userData.kokain || 0) + (userData.meth || 0) + (userData.karapara || 0);
        userTotals.push({
            userId,
            ot: userData.ot || 0,
            kokain: userData.kokain || 0,
            meth: userData.meth || 0,
            karapara: userData.karapara || 0,
            toplam,
            eklemeTarihi: userData.eklemeTarihi
        });
    }

    userTotals.sort((a, b) => b.toplam - a.toplam);
    res.json(userTotals);
});

// Eski endpoint uyumluluğu
app.get('/api/leaderboard', (req, res) => {
    res.redirect('/api/farm');
});

// ══════════════════════════════════════
//  API — Mesai Leaderboard
// ══════════════════════════════════════
app.get('/api/mesai', (req, res) => {
    const mesaiRaw = mesaiDb.toJSON() || {};
    const users = [];

    for (const [userId, userData] of Object.entries(mesaiRaw)) {
        let toplamSure = 0;
        let mesaiSayi = 0;

        if (userData.mesailer) {
            for (const m of Object.values(userData.mesailer)) {
                mesaiSayi++;
                if (m['giriş'] && m['çıkış']) {
                    const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                    if (diff > 0) toplamSure += diff;
                }
            }
        }

        users.push({
            userId,
            status: userData.status || 'out',
            mesaiSayi,
            toplamSure,
            toplamSureStr: formatMs(toplamSure)
        });
    }

    users.sort((a, b) => b.toplamSure - a.toplamSure);
    res.json(users);
});

function formatMs(ms) {
    const saat = Math.floor(ms / 3600000);
    const dakika = Math.floor((ms % 3600000) / 60000);
    const saniye = Math.floor((ms % 60000) / 1000);
    if (saat > 0) return `${saat}s ${dakika}dk`;
    if (dakika > 0) return `${dakika}dk ${saniye}sn`;
    return `${saniye}sn`;
}

// ══════════════════════════════════════
//  Sayfa Yönlendirmeleri
// ══════════════════════════════════════
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/anasayfa.html'));
});

app.get('/anasayfa', (req, res) => {
    res.redirect('/');
});

app.get('/mesai', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/mesai.html'));
});

app.get('/farm', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/farm.html'));
});

// Eski leaderboard yönlendirmesi
app.get('/leaderboard', (req, res) => {
    res.redirect('/farm');
});

// ══════════════════════════════════════
//  API — Polis Kadro
// ══════════════════════════════════════
app.get('/api/kadro', (req, res) => {
    const allMesai = mesaiDb.toJSON() || {};
    const rutbeler = Lyuex.polis?.rutbeler || [];
    const departmanlar = Lyuex.polis?.departmanlar || [];
    const personelList = [];

    // policeDb'den tüm personeli al
    const personelRaw = policeDb.get('personel') || {};

    for (const [userId, data] of Object.entries(personelRaw)) {
        const rutbeSeviye = data.rutbe || 1;
        const rutbeObj = rutbeler.find(r => r.seviye === rutbeSeviye);
        const depObj = departmanlar.find(d => d.isim === data.departman);

        const mesaiData = allMesai[userId] || {};
        const mesailer = mesaiData.mesailer || {};
        let toplamMs = 0;
        let mesaiSayi = Object.keys(mesailer).length;
        for (const m of Object.values(mesailer)) {
            if (m['giriş'] && m['çıkış']) {
                const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                if (diff > 0) toplamMs += diff;
            }
        }

        personelList.push({
            userId,
            rutbe: rutbeObj?.isim || 'Polis Memuru',
            rutbeSeviye,
            departman: data.departman || 'Atanmamış',
            departmanKisa: depObj?.kisa || '—',
            departmanEmoji: depObj?.emoji || '🛡️',
            mesaiSaat: +(toplamMs / 3600000).toFixed(1),
            mesaiSayi,
            status: mesaiData.status || 'out'
        });
    }

    // mesaiDb'den policeDb'de olmayanları da al
    for (const [userId, mesaiData] of Object.entries(allMesai)) {
        if (personelRaw[userId]) continue;
        const mesailer = mesaiData.mesailer || {};
        let toplamMs = 0;
        for (const m of Object.values(mesailer)) {
            if (m['giriş'] && m['çıkış']) {
                const diff = new Date(m['çıkış']) - new Date(m['giriş']);
                if (diff > 0) toplamMs += diff;
            }
        }
        if (toplamMs > 0) {
            personelList.push({
                userId,
                rutbe: 'Polis Memuru',
                rutbeSeviye: 1,
                departman: 'Atanmamış',
                departmanKisa: '—',
                departmanEmoji: '🛡️',
                mesaiSaat: +(toplamMs / 3600000).toFixed(1),
                mesaiSayi: Object.keys(mesailer).length,
                status: mesaiData.status || 'out'
            });
        }
    }

    personelList.sort((a, b) => b.rutbeSeviye - a.rutbeSeviye || b.mesaiSaat - a.mesaiSaat);
    res.json({ personel: personelList, rutbeler, departmanlar });
});

// ══════════════════════════════════════
//  API — Tutuklamalar & Cezalar & Devriyeler
// ══════════════════════════════════════
app.get('/api/tutuklamalar', (req, res) => {
    const tutuklamalar = (policeDb.get('tutuklamalar') || []).slice().reverse().slice(0, 100);
    const cezalar = (policeDb.get('cezalar') || []).slice().reverse().slice(0, 100);
    const devriyeler = (policeDb.get('devriyeler') || []).slice().reverse().slice(0, 100);
    res.json({ tutuklamalar, cezalar, devriyeler });
});

// ══════════════════════════════════════
//  API — Polis İstatistik
// ══════════════════════════════════════
app.get('/api/polis-istatistik', (req, res) => {
    const tutuklamalar = policeDb.get('tutuklamalar') || [];
    const cezalar = policeDb.get('cezalar') || [];
    const devriyeler = policeDb.get('devriyeler') || [];
    const egitimler = policeDb.get('egitimler') || [];
    const raporlar = policeDb.get('olayRaporlari') || [];
    const personelRaw = policeDb.get('personel') || {};
    const mesaiRaw = mesaiDb.toJSON() || {};
    const maasConfig = Lyuex.polis?.maas || { saatlikUcret: 500, paraBirimi: '₺' };

    // Genel sayılar
    const toplamPersonel = Object.keys(personelRaw).length;

    // Suç dağılımı
    const sucDagilimi = {};
    for (const t of tutuklamalar) {
        sucDagilimi[t.suc] = (sucDagilimi[t.suc] || 0) + 1;
    }

    // Ceza türü dağılımı
    const cezaDagilimi = {};
    let toplamCezaMiktar = 0;
    for (const c of cezalar) {
        cezaDagilimi[c.tur] = (cezaDagilimi[c.tur] || 0) + 1;
        toplamCezaMiktar += c.miktar || 0;
    }

    // Devriye bölge dağılımı
    const bolgeDagilimi = {};
    for (const d of devriyeler) {
        bolgeDagilimi[d.bolge] = (bolgeDagilimi[d.bolge] || 0) + 1;
    }

    // Son 7 gün günlük aktivite
    const gunlukAktivite = [];
    for (let i = 6; i >= 0; i--) {
        const gun = new Date();
        gun.setDate(gun.getDate() - i);
        const gunStr = gun.toISOString().slice(0, 10);
        gunlukAktivite.push({
            tarih: gunStr,
            tutuklama: tutuklamalar.filter(t => t.tarih?.startsWith(gunStr)).length,
            ceza: cezalar.filter(c => c.tarih?.startsWith(gunStr)).length,
            devriye: devriyeler.filter(d => d.tarih?.startsWith(gunStr)).length
        });
    }

    // Top 5 memur (en çok aktivite)
    const memurStats = {};
    for (const t of tutuklamalar) { memurStats[t.memurId] = memurStats[t.memurId] || { t: 0, c: 0, d: 0 }; memurStats[t.memurId].t++; }
    for (const c of cezalar) { memurStats[c.memurId] = memurStats[c.memurId] || { t: 0, c: 0, d: 0 }; memurStats[c.memurId].c++; }
    for (const d of devriyeler) { memurStats[d.memurId] = memurStats[d.memurId] || { t: 0, c: 0, d: 0 }; memurStats[d.memurId].d++; }

    const topMemurlar = Object.entries(memurStats)
        .map(([id, s]) => ({ userId: id, tutuklama: s.t, ceza: s.c, devriye: s.d, toplam: s.t + s.c + s.d }))
        .sort((a, b) => b.toplam - a.toplam)
        .slice(0, 5);

    res.json({
        genel: {
            toplamPersonel,
            toplamTutuklama: tutuklamalar.length,
            toplamCeza: cezalar.length,
            toplamCezaMiktar,
            toplamDevriye: devriyeler.length,
            toplamEgitim: egitimler.length,
            toplamRapor: raporlar.length,
            paraBirimi: maasConfig.paraBirimi
        },
        sucDagilimi,
        cezaDagilimi,
        bolgeDagilimi,
        gunlukAktivite,
        topMemurlar
    });
});

// ══════════════════════════════════════
//  Polis Sayfaları
// ══════════════════════════════════════
app.get('/kadro', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/kadro.html'));
});

app.get('/tutuklamalar', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/tutuklamalar.html'));
});

app.get('/istatistik', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/istatistik.html'));
});

app.listen(port, () => {
    console.log(`[Web Panel] http://localhost:${port} adresinde çalışıyor`);
});